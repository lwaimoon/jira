# -*- coding:utf8 -*-
import datetime
import json
import os
import requests
import time
# from bs4 import BeautifulSoup
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait


# csv_file = os.path.join(os.path.dirname(__file__), "changelog_" + time.strftime("%Y-%m-%d_%H-%M") + ".csv")
# file = open(csv_file, "w")
# file.close()


def launch_gerrit(user, password, branch, page=0):
    _gerrit_url = "http://gerrit.pt.miui.com/#/q/status:merged+project:platform/packages/apps/SideKick+branch:" + branch + "," + str(
        25 * page)
    '''
    ubuntu 安装 phantomjs
    sudo apt-get install phantomjs  
    sudo apt-get install nodejs  
    sudo apt-get install nodejs-legacy  
    sudo apt-get install npm  
    sudo npm -g install phantomjs-prebuilt  
    '''
    opt = webdriver.ChromeOptions()
    opt.set_headless()
    driver = webdriver.Chrome(options=opt)
    # driver = webdriver.Chrome()
    # driver = webdriver.PhantomJS(shell=True, executable_path=os.path.abspath(os.path.join(".", "phantomjs", "bin", "phantomjs.exe")))
    driver.get(_gerrit_url)

    time.sleep(2)
    is_disappeared = WebDriverWait(driver, 60, 0.5, ignored_exceptions=TimeoutException).until(
        lambda x: x.find_element_by_link_text("Sign In").is_displayed())

    if is_disappeared:
        driver.find_element_by_link_text("Sign In").click()
        driver.find_element_by_id("f_user").send_keys(user)
        pwd = driver.find_element_by_id("f_pass")
        pwd.send_keys(password)
        pwd.send_keys(Keys.ENTER)
    time.sleep(10)
    return driver


def get_changelog(user, password, branch, start_time="", stop_time="", page=0):
    driver = launch_gerrit(user, password, branch, page=page)
    time.sleep(5)
    content = driver.page_source
    # print(content)
    soup = BeautifulSoup(content, "html.parser")
    tr_list = soup.find_all("tr")[7:-2]
    msg_lst = []
    mon_dic = {
        "Jan": "01", "Feb": "02", "Mar": "03", "Apr": "04", "May": "05", "Jun": "06", "Jul": "07", "Aug": "08",
        "Sep": "09", "Oct": "10", "Nov": "11", "Dec": "12"
    }
    for tr in tr_list:
        td = tr.find_all("td")
        # print(td)
        # print(len(td))
        d_lst = []
        for d in td:
            # print(d.a)
            if len(d.text) > 0:
                d_lst.append(d.text.replace(",", "."))
                # print(d["class"])
        detail_page = "http://gerrit.pt.miui.com/" + str(d_lst[0])
        driver.get(detail_page)
        time.sleep(3)
        detail_content = BeautifulSoup(driver.page_source, "html.parser")

        jira_id = detail_content.find("div",
                                      class_="com-google-gerrit-client-change-CommitBox_BinderImpl_GenCss_style-text").find(
            "a")["href"]
        # with open(csv_file, "a") as f:
        #     if jira_id != "http://jira.n.xiaomi.com/browse/KETA-1600":
        # print(",".join(d_lst)+","+jira_id + "\n")
        # f.write(",".join(d_lst)+","+jira_id + "\n")
        if jira_id != "http://jira.n.xiaomi.com/browse/KETA-1600":
            creat_time = d_lst[-1]

            if ":" in creat_time:
                creat_time = datetime.datetime.now().strftime("%Y-%m-%d")
            else:
                if "," in creat_time:
                    y = d_lst[-1].split(",")[-1]
                    m, d = tuple(d_lst[-1].split(",")[0])
                    if int(d) < 10:
                        d = "0"+str(d)
                    creat_time = "-".join([y, mon_dic[m], d])
                else:
                    m, d = tuple(d_lst[-1].split(" "))
                    if int(d) < 10:
                        d = "0"+str(d)
                    creat_time = "-".join([datetime.datetime.now().strftime("%Y"), mon_dic[m], d])
            if start_time == "":
                start_time = "2018-01-01"
            if stop_time == "":
                stop_time = "2088-12-31"
            # start_time = time.mktime(time.strptime(str(start_time), "%Y-%m-%d"))
            # stop_time = time.mktime(time.strptime(str(stop_time), "%Y-%m-%d"))
            # creat_time = time.mktime(time.strptime(str(creat_time), "%Y-%m-%d"))

            if start_time <= creat_time <= stop_time:
                msg_lst.append(d_lst[1] + "," + jira_id)
            else:
                break
    if creat_time > start_time:
        page += 1
        get_changelog(user, password, branch, start_time="", stop_time="", page=page)
    print(msg_lst)
    driver.quit()
    return msg_lst

#
# import time
#
#
# def spider_changelog(user, password, branch, start_time="", stop_time=""):
#     # 初始化文件
#     with open(os.path.join(os.path.dirname(__file__), "changelog_" + time.strftime("%Y-%m-%d_%H-%M") + ".csv"),
#               "w") as f:
#         pass
#     _page_url = "http://gerrit.pt.miui.com/changes/?q=status:merged+project:platform/packages/apps/SideKick+branch:" + branch + "&n=50&O=81"
#     driver = launch_gerrit(user, password, branch)
#     list_cookies = driver.get_cookies()
#     cookies = {}
#     for co in list_cookies:
#         cookies[co["name"]] = co["value"]
#     # print(cookies)
#     wbdata = requests.get(_page_url, cookies=cookies).text.replace(")]}\'", "")
#     print(wbdata)
#     data = json.loads(wbdata)
#     # driver.quit()
#     for item in data:
#         print(item)
#         creat_time = item["created"].split(" ")[0]
#         if start_time == "":
#             start_time = "2018-01-01"
#         if stop_time == "":
#             stop_time = "2088-12-31"
#         if start_time <= creat_time <= stop_time:
#             _branch = item["branch"]
#             _number = str(item["_number"])
#             subject = item["subject"].replace(",", ".")
#             owner = item["owner"]["name"]
#             email = item["owner"]["email"]
#
#             # jira_id = detail_page.find("div", class_="com-google-gerrit-client-change-CommitBox_BinderImpl_GenCss_style-text").find("a")["href"]
#             with open(os.path.join(os.path.dirname(__file__), "changelog_" + time.strftime("%Y-%m-%d_%H-%M") + ".csv"),
#                       "a") as f:
#                 print(",".join([_branch, subject, creat_time, owner, email]) + "\n")
#                 # f.write(",".join([_branch, subject, creat_time, owner, email]) + "\n")
#         driver.quit()
def get_gitlog(branch="v10-alpha", start_time="2018-06-28",stop_time="2018-07-06"):
    log = os.popen("cd /home/yanglikai/androidproject/xiaoai/SideKick && git checkout %s && git pull && git log --before=\"%s\" --after=\"%s\"" % (branch, stop_time, start_time))
    # print(log.read())
    # return
    # time_a = time.mktime(time.strptime(start_time, "%Y-%m-%d"))
    # time_b = time.mktime(time.strptime(stop_time, "%Y-%m-%d"))
    # print(time_a,time_b)
    commit_lst = log.read().split("commit")
    # print(commit_lst)
    result = []
    for commit in commit_lst:
        commit_info = commit.split("\n")
        # print(commit_info)
        commit_detail = {}
        for i, item in enumerate(commit_info):
            item = item.strip()
            if len(item) > 0:

                if "Author:" in item:
                    commit_detail["Author:"] = item.replace("Author:", "").strip()
                elif "Date:" in item:
                    commit_detail["Date"] = item.replace("Date:", "").replace("+0800", "").strip()
                    m = i+1
                    while len(commit_info[m]) <= 10:
                        m += 1
                    commit_detail["desc"] = commit_info[m].strip()
                # elif "MIUI-" in item or "VOICEASSITANT-" in item:

                elif item.split("-")[-1].isdigit():
                    commit_detail["JiraId"] = item.strip()
        result.append(commit_detail)

        # if "Date" in commit_detail.keys() and "JiraId" in commit_detail.keys():
        #     time_c = time.mktime(time.strptime(commit_detail["Date"], "%a %b %d %H:%M:%S %Y"))
            # if time_a <= time_c <= time_b:
            #     result.append(commit_detail)
    print(result)
    return result

if __name__ == "__main__":
    get_gitlog("v10-alpha","2018-07-10","2018-07-14")
    # branch = input("输入你要抓取的分支(例如：v10-dev):")
    # user = input("输入你的账号：")
    # password = input("输入密码：")
    # get_changelog(user, password, branch, start_time="2018-06-06",stop_time="2018-06-06")
