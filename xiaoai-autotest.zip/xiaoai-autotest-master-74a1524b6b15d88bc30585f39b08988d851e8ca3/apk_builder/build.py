#!/usr/bin/env python
# -*- coding: utf-8 -*-

# 依赖 sudo pip install jenkinsapi
import getopt
import json

import subprocess
import traceback

import requests
from exchangelib import Credentials, Account, DELEGATE, Message, HTMLBody, Mailbox
from jenkinsapi.jenkins import Jenkins
import datetime
import re
import os, sys
import tarfile
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait
import changelog

if sys.version_info.major == 2:
    import urllib
elif sys.version_info.major == 3:
    import urllib.request


def load_config():
    with open(os.path.join(os.path.dirname(__file__), "config.json"), "r") as f:
        return json.load(f)


def change_config(A, B):
    f = open(os.path.join(os.path.dirname(__file__), "config.json"), "r")
    s = f.read()
    s = s.replace(A, B)
    f.close()
    p = open(os.path.join(os.path.dirname(__file__), "config.json"), "w+")
    p.write(s)
    p.close()


# config = load_config()


def get_server_instance():
    jenkins_url = 'http://c3.rom.pt.xiaomi.com'
    # 用户名和密码改成自己的，需要先到c3.rom.pt.xiaomi.com注册，然后找liangbo加权限
    try:
        server = Jenkins(jenkins_url, username=load_config()["user"], password=load_config()["password"])
    except Exception as e:
        server = Jenkins(jenkins_url, username="yanglikai", password="52513b2b6ed663aa1172eca42da79ccd")
    return server


def trigger_tiny_build(server, tag="v10-alpha", change=""):
    job = server.get_job("tiny_build_api")
    build_params = dict()
    # 这些参数是传给tiny build任务的。
    # 可以在编译平台的网站触发一次任务，然后点击任务连接，可以复制它的参数过来粘贴
    # 比如任务id是4293,可以访问http://c3.rom.pt.xiaomi.com/view/builder/job/tiny_build12/4293/parameters/看到所有参数
    # build_params["BUILD_PROJECT_INFO"] = "platform/packages/apps/SideKick|packages/apps/SideKick|v8-alpha|miui"
    # 这个是任务的创建者，任务结束会收到邮件通知
    build_params["BUILD_USER"] = load_config()["user"]
    if change != "" and change.isdigit():
        build_params["CHANGES"] = "cherry-pick_8088_" + change
    build_params["BUILD_SIGN"] = "true"

    # build_params["RELATIVE_PATH"] = "RELATIVE_PATH"
    build_params["CERTIFICATE_METHOD"] = "PLATFORM"
    build_params["GRADLE_BUILD"] = "true"
    today = datetime.date.today()
    version_string = today.strftime("%Y%m%d")
    if "alpha" == tag:
        build_params["BUILD_PROJECT_INFO"] = load_config()["BUILD_PROJECT_INFO_alpha"]
        note_tag = build_params["BUILD_PROJECT_INFO"].split("|")[2]
        print(note_tag)
        build_params["BUILD_LABEL"] = "小爱同学体验版(" + note_tag + ")-%s" % version_string
    elif "dev" == tag:
        build_params["BUILD_PROJECT_INFO"] = load_config()["BUILD_PROJECT_INFO_dev"]
        note_tag = build_params["BUILD_PROJECT_INFO"].split("|")[2]
        print(note_tag)
        build_params["BUILD_LABEL"] = "小爱同学开发版(" + note_tag + ")-%s" % version_string
    elif "beta" == tag:
        build_params["BUILD_PROJECT_INFO"] = load_config()["BUILD_PROJECT_INFO_beta"]
        note_tag = build_params["BUILD_PROJECT_INFO"].split("|")[2]
        print(note_tag)
        build_params["BUILD_LABEL"] = "小爱同学beta版(" + note_tag + ")-%s" % version_string
    elif "online" == tag:
        build_params["BUILD_PROJECT_INFO"] = load_config()["BUILD_PROJECT_INFO_onlinemiai"]
        note_tag = build_params["BUILD_PROJECT_INFO"].split("|")[2]
        print(note_tag)
        build_params["BUILD_LABEL"] = "小爱同学online版(" + note_tag + ")-%s" % version_string
    elif "evaluate" == tag:
        build_params["BUILD_PROJECT_INFO"] = load_config()["BUILD_PROJECT_INFO_evaluate"]
        note_tag = build_params["BUILD_PROJECT_INFO"].split("|")[2]
        print(note_tag)
        build_params["BUILD_LABEL"] = "小爱同学evaluate版(" + note_tag + ")-%s" % version_string

    elif "Lite" in tag:  #  build xiaoai-lite app
        _branch = tag.split("-")[-1]
        os.popen(
            "cd /home/yanglikai/androidproject/lite/XiaoAiLite && git checkout %s && git reset --hard HEAD^" % _branch).read()
        if change != "" and "/" in change:

            _change = change[1:] if change.startswith("/") else change
            _subject = "小爱同学%s-%s change: %s" % (tag, version_string, _change)
            res = os.popen(
                "cd /home/yanglikai/androidproject/lite/XiaoAiLite && git checkout %s && git pull --rebase&& git fetch ssh://yanglikai@git.mioffice.cn:29418/platform/packages/apps/XiaoAiLite refs/changes/%s && git cherry-pick FETCH_HEAD&& ./gradlew build -x lint" % (_branch, _change)).read()

            res2 = os.popen("cd /home/yanglikai/androidproject/lite/XiaoAiLite && git checkout %s && git reset --hard HEAD^" % _branch).read()
            print(res)
            print(res2)
        else:
            _subject = "小爱同学%s-%s" % (tag, version_string)
            res = os.popen("cd /home/yanglikai/androidproject/lite/XiaoAiLite && git checkout %s&& git pull --rebase&& ./gradlew build -x lint" %_branch).read()
            print(res)
            time.sleep(1)
        release_apk = "/home/yanglikai/androidproject/lite/XiaoAiLite/app/build/outputs/apk/upgrade/release/app-upgrade-release.apk"
        debug_apk = "/home/yanglikai/androidproject/lite/XiaoAiLite/app/build/outputs/apk/upgrade/debug/app-upgrade-debug.apk"
        autotest_apk = "/home/yanglikai/androidproject/lite/XiaoAiLite/app/build/outputs/apk/autotest/debug/app-autotest-debug.apk"
        result_url = upload_file("lite-"+_branch, release_apk)
        result_url2 = upload_file("lite-"+_branch, debug_apk)
        result_url3 = upload_file("lite-"+_branch, autotest_apk)
        os.remove(release_apk)
        os.remove(debug_apk)
        os.remove(autotest_apk)

        print("小爱"+tag+"：" + result_url)
        send_to = []
        for person in load_config()["email"].split(","):
            send_to.append(person + "@xiaomi.com")
        _body = "下载地址：\n" + result_url+"\n"+result_url2+"\n"+result_url3
        send_mail(send_to, _subject, _body)
        return result_url3

    else:
        build_params[
            "BUILD_PROJECT_INFO"] = "platform/packages/apps/SideKick|packages/apps/SideKick|%s|miui,miui/decouple_res|miui/decouple_res|dev|miui" % tag
        build_params["BUILD_LABEL"] = "小爱同学(\"%s\")版本-%s" % (tag, version_string)
    build_params["JDK_VERSION"] = "jdk8"
    # 别人如果也想要邮件，可以填EMAILS字段，逗号分隔的邮箱前缀。
    # build_params["EMAILS"] = "fengxiaochuan,hanwei,yangrui5,chensenhua,yinsonghua,hupei1,v-zhangting,v-liyu3,ai-service"
    build_params["EMAILS"] = load_config()["email"]
    build_params["ENV_VAR"] = ""
    # 需要拷贝的文件，多个文件间用逗号","隔开。支持拷贝单个文件或文件夹。
    build_params["INPUT_FILES"] = "packages/apps/SideKick/build/outputs/mapping/miui/release/mapping.txt"
    queue_item = job.invoke(build_params=build_params, delay=0)
    queue_item.block_until_building()
    build = queue_item.get_build()
    print("start to build. build number is %s" % build.get_number())
    build.block_until_complete(delay=60)
    build.poll()
    result_url = build.get_description()

    if not result_url.startswith("http://"):
        result_url = "http://%s" % result_url
    print(result_url)
    return result_url


def parse_tgz_data(result_url, tag="alpha"):
    """
    这个函数用来解析tar.gz包里面哪些文件是要推送maven的，patterns_dict是规则，key是分辨率，value里面是文件名的正则表达式
    :param result_url:
    :return:
    """
    tag = "onlinemiai" if tag == "online" else tag  # 对 online 做适配融合云bucket名处理
    resource_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "resource"))
    if not os.path.exists(resource_path):
        os.makedirs(resource_path)
    if not os.path.exists(os.path.join(resource_path, tag + ".tar.gz")):
        _tmp = open(os.path.join(resource_path, tag + ".tar.gz"), "w")
        _tmp.close()
    if sys.version_info.major == 2:
        local_file, dummy = urllib.urlretrieve(result_url, os.path.join(resource_path, tag + ".tar.gz"))
    elif sys.version_info.major == 3:
        local_file, dummy = urllib.request.urlretrieve(result_url, os.path.join(resource_path, tag + ".tar.gz"))
    tgz_object = tarfile.open(name=local_file)
    unzipdir = os.path.join(resource_path, tag)
    if not os.path.exists(unzipdir):
        os.makedirs(unzipdir)
    # 删除旧文件
    delList = os.listdir(unzipdir)
    for file in delList:
        filePath = os.path.join(unzipdir, file)
        os.remove(filePath)

    # 解压缩包文件
    tgz_object.extractall(path=unzipdir)
    patterns_dict = dict()
    path_dic = dict()
    # 正则表达式需要业务组根据情况修改
    patterns_dict["autotest"] = re.compile(r"signed_PLATFORM_.*_SideKick-autotest-release-unsigned.apk")
    patterns_dict["miui"] = re.compile(r"signed_PLATFORM_.*_SideKick-miui-release-unsigned.apk")
    # patterns_dict["demo"] = re.compile(r"signed_PLATFORM_.*_SideKick-demo-release-unsigned.apk")
    patterns_dict["upgrade"] = re.compile(r"signed_PLATFORM_.*_SideKick-upgrade-release-unsigned.apk")
    tar_path = os.path.join(unzipdir, tag + "_" + time.strftime("%Y-%m-%d_%H-%M-%S") + ".tar.gz")
    tar = tarfile.open(tar_path, "w:gz")
    for name in tgz_object.getnames():
        for pattern in patterns_dict:
            if patterns_dict[pattern].match(name):
                re_name = "xiaoai_" + tag + "_" + pattern + ".apk"
                os.rename(os.path.join(unzipdir, name), os.path.join(unzipdir, re_name))  # 重命名文件
                path_dic[pattern] = os.path.join(unzipdir, re_name)
                tar.add(path_dic[pattern], arcname=re_name)
    path_dic["mapping"] = os.path.join(unzipdir, "mapping.txt")
    tar.add(path_dic["mapping"])
    tar.close()
    try:
        upload_file("xiaoai-" + tag, path_dic["upgrade"])  # 上传到融合云
        #upload_file("xiaoai-" + tag, path_dic["demo"])
        upload_file("xiaoai-" + tag, path_dic["miui"])
        upload_file("xiaoai-" + tag, path_dic["autotest"])
        upload_file("xiaoai-" + tag, path_dic["mapping"])
        upload_file("xiaoai-" + tag, tar_path)
    except Exception as e:
        pass
    return path_dic


def _parse_tgz_data(result_url, tag="alpha"):
    """
    这个函数用来解析tar.gz包里面哪些文件是要推送maven的，patterns_dict是规则，key是分辨率，value里面是文件名的正则表达式
    :param result_url:
    :return:
    """
    # resource_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir, "resource"))
    resource_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "resource"))
    if not os.path.exists(resource_path):
        os.makedirs(resource_path)
    if not os.path.exists(os.path.join(resource_path, tag + ".tar.gz")):
        _tmp = open(os.path.join(resource_path, tag + ".tar.gz"), "w")
        _tmp.close()
    if sys.version_info.major == 2:
        local_file, dummy = urllib.urlretrieve(result_url, os.path.join(resource_path, tag + ".tar.gz"))
    elif sys.version_info.major == 3:
        local_file, dummy = urllib.request.urlretrieve(result_url, os.path.join(resource_path, tag + ".tar.gz"))
    tgz_object = tarfile.open(name=local_file)
    # unzipdir = os.path.join(resource_path, tag)
    # # 删除旧文件
    # delList = os.listdir(unzipdir)
    # for file in delList:
    #     filePath = os.path.join(unzipdir, file)
    #     os.remove(filePath)
    #
    # # 解压缩包文件
    # tgz_object.extractall(path=unzipdir)
    patterns_dict = dict()
    # 正则表达式需要业务组根据情况修改
    patterns_dict["universal"] = re.compile(
        r"signed_PLATFORM_.*_SideKick-miui-release-unsigned.apk")  # re.compile(r".*universal.*.apk")
    # patterns_dict["xhdpi"] = re.compile(
    #     r"signed_PLATFORM_.*_SideKick-miui-xhdpi-release-unsigned.apk")  # re.compile(r".*xhdpi.*.apk")
    # patterns_dict["xxhdpi"] = re.compile(
    #     r"signed_PLATFORM_.*_SideKick-miui-xxhdpi-release-unsigned.apk")  # re.compile(r".*xxhdpi.*.apk")
    # patterns_dict["xxxhdpi"] = re.compile(
    #     r"signed_PLATFORM_.*_SideKick-miui-xxxhdpi-release-unsigned.apk")  # re.compile(r".*xxxhdpi.*.apk")
    # patterns_dict["nxhdpi"] = re.compile(
    #     r"signed_PLATFORM_.*_SideKick-miui-nxhdpi-release-unsigned.apk")  # re.compile(r".*nxhdpi.*.apk")

    files_list = []
    for name in tgz_object.getnames():
        for dpi in patterns_dict:
            pattern = patterns_dict[dpi]
            if pattern.match(name):
                one_file = (name, dpi)
                files_list.append(one_file)
    return files_list


def post_data(result_url):
    # 提供调用接口的参数信息
    if not result_url.startswith("http://"):
        result_url = "http://%s" % result_url
    today = datetime.date.today()
    version_string = today.strftime("%Y%m%d")
    files_list = _parse_tgz_data(result_url)
    data = {}
    # tar包路径
    data["targetUrl"] = result_url
    # groupId需要修改
    data["groupId"] = "com.miui"
    # artifactId需要修改
    # packageName需要修改
    data["packageName"] = "com.miui.voiceassist"
    # managerName需要修改(具有邮箱组限制)
    data["managerName"] = load_config()["PUSH_MAVEN"]["managerName"]
    # apkRegion适用地区需要修改
    data["apkRegion"] = "cn"
    # 这个是任务的创建者，任务结束会收到邮件通知
    data["buildUser"] = load_config()["user"]
    # readMe.txt信息说明
    data["readMe"] = "Test"
    # 文件类型参数
    files = {
        "reportFile": "",
        "androidMKFile": open(os.path.join(os.path.dirname(__file__), "resource", "Android.mk"), "rb").read()
    }
    # artifact id需要修改
    data["artifactId"] = "voiceassist"
    data["version"] = "1.0.0.9-%s-SNAPSHOT" % version_string
    data["versionName"] = "1.0.0.9"

    # localPrivilegedModule需要修改
    # data["localPrivilegedModule"] = "true"
    # filterSo裁剪So需要修改
    # data["filterSo"] = "true"
    # buildRegion地区需要修改
    # data["buildRegion"] = "all"

    # mavenFiles(该参数由result_url和正则表达式影响)
    for i in range(len(files_list)):
        data["mavenFiles[%d].fileName" % i] = files_list[i][0]
        # print(data["mavenFiles[%d].fileName" % i])
        data["mavenFiles[%d].classifier" % i] = files_list[i][1]
        # print(data["mavenFiles[%d].classifier" % i])
        data["mavenFiles[%d].checkBox" % i] = "true"

    # 调用接口地址
    url = 'http://husky.pt.miui.com/api/maven/save'
    # 推送数据
    result = requests.post(url, data, files=files)
    print(result.text)


def send_mail(to, subject, body):
    credentials = Credentials(
        username=load_config()["user"] + '@xiaomi.com',  # Or myusername@example.com for O365
        password=load_config()["password"]
    )
    account = Account(
        primary_smtp_address=load_config()["user"] + '@xiaomi.com',
        credentials=credentials,
        autodiscover=True,
        access_type=DELEGATE
    )
    m = Message(
        account=account,
        subject=subject,
        body=body,
        # body=HTMLBody(body),
        to_recipients=to
        # to_recipients=[Mailbox(email_address=to)]
    )
    print(to)
    m.send()


def email_tc(branch="v10-alpha", start_time="", stop_time=""):  # 提测邮件
    _body = ""
    _subject = "【changelog】小爱同学%s分支" % branch + start_time + "至" + stop_time + "的changelog（此邮件自动发送）"
    # msg_lst = changelog.get_changelog(load_config()["user"], load_config()["password"], branch, start_time=start_time, stop_time=stop_time)
    msg_lst = changelog.get_gitlog(branch=branch, start_time=start_time, stop_time=stop_time)
    for msg in msg_lst:
        if len(msg) > 0:
            if "JiraId" not in msg.keys():
                msg["JiraId"] = "无"
            if "desc" not in msg.keys():
                msg["desc"] = "无"
            _body += '''【%s】问题：%s -> jira id : %s \n''' % (msg["Date"], msg["desc"], msg["JiraId"])
    send_to = []
    for person in load_config()["email"].split(","):
        send_to.append(person + "@xiaomi.com")
    send_mail(send_to, _subject, _body)

def email_online(branch="onlinemiai", start_time="", stop_time="", resulturl=""):  # 提测邮件
    _subject = "V3.8.0 自升级--%s号提测" % stop_time
    _body = '''Hi,\n v3.8 onlinemiai分支新进了以下change, 现提测, 麻烦验证.
 apk链接: %s 
 Changelog:\n''' % resulturl
    msg_lst = changelog.get_gitlog(branch=branch, start_time=start_time, stop_time=stop_time)
    for msg in msg_lst:
        if len(msg) > 0:
            if "JiraId" not in msg.keys():
                msg["JiraId"] = "无"
            if "desc" not in msg.keys():
                msg["desc"] = "无"
            _body += '''【%s】问题：%s -> jira id : %s \n''' % (msg["Date"], msg["desc"], msg["JiraId"])
    send_to = []
    for person in load_config()["email"].split(","):
        send_to.append(person + "@xiaomi.com")
    send_to.append("liuzhi1@xiaomi.com")  # 添加刘值到邮件收件人
    print(_body)
    send_mail(send_to, _subject, _body)


def alpha_build(change=""):
    # 新建和jenkins的连接
    server = get_server_instance()
    # 调用接口触发tiny build，得到的result url是这个包的下载链接
    # 如果用别的方法编译，就不需要掉这个函数了，可以本地实现编译步骤
    result_url = trigger_tiny_build(server, tag="alpha", change=change)
    if result_url is None:
        print("FATAL: tiny build failed!")
        sys.exit(1)
    # 调用推送maven的接口
    if change == "" or change == "none":
        post_data(result_url)
    return server, result_url


def dev_build(change=""):
    # 新建和jenkins的连接
    server = get_server_instance()
    # 调用接口触发tiny build，得到的result url是这个包的下载链接
    # 如果用别的方法编译，就不需要掉这个函数了，可以本地实现编译步骤
    result_url = trigger_tiny_build(server, tag="dev", change=change)
    if result_url is None:
        print("FATAL: tiny build failed!")
        sys.exit(1)

    return server, result_url


def evaluate_build(change=""):
    # 新建和jenkins的连接
    server = get_server_instance()
    # 调用接口触发tiny build，得到的result url是这个包的下载链接
    # 如果用别的方法编译，就不需要掉这个函数了，可以本地实现编译步骤
    result_url = trigger_tiny_build(server, tag="evaluate", change=change)
    if result_url is None:
        print("FATAL: tiny build failed!")
        sys.exit(1)

    return server, result_url


def online_build():
    # 新建和jenkins的连接
    server = get_server_instance()
    # 调用接口触发tiny build，得到的result url是这个包的下载链接
    # 如果用别的方法编译，就不需要掉这个函数了，可以本地实现编译步骤
    result_url = trigger_tiny_build(server, tag="onlinemiai")
    if result_url is None:
        print("FATAL: tiny build failed!")
        sys.exit(1)

    return server, result_url


def beta_build(change=""):
    # 新建和jenkins的连接
    server = get_server_instance()
    # 调用接口触发tiny build，得到的result url是这个包的下载链接
    # 如果用别的方法编译，就不需要掉这个函数了，可以本地实现编译步骤
    result_url = trigger_tiny_build(server, tag="beta", change=change)
    if result_url is None:
        print("FATAL: tiny build failed!")
        sys.exit(1)

    return server, result_url


from fds import GalaxyFDSClient, GalaxyFDSClientException
import os

XIAOMI_ACCESS_KEY_ID = "AKB5EQRQHBDVGUP7B7"
XIAOMI_SECRET_ACCESS_KEY = "3PClVJ8ooSAtCOHYkWTjRH/brLdfc2f65xy4oJ9k"


def upload_file(bucket_name, png_file, branch=""):
    client = GalaxyFDSClient(XIAOMI_ACCESS_KEY_ID, XIAOMI_SECRET_ACCESS_KEY)
    if os.path.isfile(png_file):
        print(png_file.split('/')[-1])
        with open(png_file, 'rb') as f:
            data = f.read()
        path_to = branch+png_file.split('/')[-1]
        res = client.put_object(bucket_name, path_to, data)
        print('Put Object: ', res.signature, res.expires)
        client.set_public(bucket_name, path_to)
        print('Set public', path_to)
        dl_url = client.generate_download_object_uri(bucket_name, path_to)
        return dl_url.replace("https", "http")

def launch_web_page(url):
    _url = url  # "http://husky.pt.miui.com/tool/maven/upload"
    # driver = webdriver.Firefox()
    opt = webdriver.ChromeOptions()
    opt.set_headless()
    driver = webdriver.Chrome(options=opt)
    driver.get(_url)
    # 判断页面是否加载完成
    is_disappeared = WebDriverWait(driver, 60, 0.5, ignored_exceptions=TimeoutException).until(
        lambda x: x.find_element_by_id("input-username").is_displayed())
    # 输入账号，密码登录
    if is_disappeared:
        if load_config()["password"] == "":
            pass_word = ""  # 输入你的密码
        else:
            pass_word = load_config()["password"]
        driver.find_element_by_id("input-username").send_keys(load_config()["user"])
        pwd = driver.find_element_by_id("password")
        pwd.send_keys(pass_word)
        pwd.send_keys(Keys.ENTER)
        if WebDriverWait(driver, 20, 0.5, ignored_exceptions=TimeoutException).until(
                lambda x: x.find_element_by_id("targetUrl").is_displayed()):
            return driver
        else:
            print("请检查网络状态")
    else:
        print("请检查网络状态")


def trigger_dev_maven_build(package_url, report_url, version, readme_content, delay_report=False, label=""):
    driver = launch_web_page("http://husky.pt.miui.com/tool/maven/upload")
    resource_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "resource"))
    if driver:
        # packageFile = os.path.abspath(os.path.join(resource_path, "dev", packageFile))

        # submit = driver.find_element_by_id("packageFile")
        # submit.send_keys(packageFile)
        button = driver.find_element_by_id("targetUrl")
        button.send_keys(package_url)
        button.send_keys(Keys.ENTER)

        if WebDriverWait(driver, 300, 0.5, ignored_exceptions=TimeoutException).until(
                lambda x: x.find_element_by_id("groupId").is_displayed()):
            driver.find_element_by_id("groupId").send_keys(load_config()["PUSH_MAVEN"]["groupId"])
            driver.find_element_by_id("artifactId").send_keys(load_config()["PUSH_MAVEN"]["artifactId"])
            today = datetime.date.today()
            if label:
                version_string = today.strftime("%Y%m%d")
                driver.find_element_by_id("version").send_keys("1.0.0.0-" + version_string + label)
            else:
                version_string = today.strftime("%Y%m%d")
                driver.find_element_by_id("version").send_keys(
                    load_config()["PUSH_MAVEN"]["version"] + "-" + version_string)
            driver.find_element_by_id("versionName").send_keys(version)
            driver.find_element_by_id("packageName").send_keys(load_config()["PUSH_MAVEN"]["packageName"])

            # report_path = os.path.abspath(
            #     os.path.join(os.path.dirname(__file__), "resource", load_config()["PUSH_MAVEN"]["reportFile"]))
            # driver.find_element_by_xpath("//label[@for='omitReport']").click() if delay_report else driver.find_element_by_id("reportFile").send_keys(report_path)
            # driver.find_element_by_xpath("//button[@class='close']").click()
            # driver.find_element_by_id("reportFile").send_keys(report_path)
            driver.find_element_by_id("managerName").send_keys(load_config()["PUSH_MAVEN"]["managerName"])
            Select(driver.find_element_by_id("gerritBranch")).select_by_value(
                load_config()["PUSH_MAVEN"]["gerritBranch"])  # config.json 中配置
            Select(driver.find_element_by_id("apkRegion")).select_by_value(load_config()["PUSH_MAVEN"]["apkRegion"])
            # driver.find_element_by_id("localModule").send_keys(load_config()["PUSH_MAVEN"]["localModule"])
            # driver.find_element_by_id("localCertificate").send_keys(load_config()["PUSH_MAVEN"]["localCertificate"])
            # mkfile_path = os.path.abspath(
            #     os.path.join(os.path.dirname(__file__), "resource",
            #                  load_config()["PUSH_MAVEN"]["androidMKFile"]))
            # driver.find_element_by_id("androidMKFile").send_keys(mkfile_path)
            # Select(driver.find_element_by_id("buildRegion")).select_by_value(load_config()["PUSH_MAVEN"]["buildRegion"])
            # 添加read me
            try:
                js = 'document.getElementsByTagName("textarea")[0].value= "%s"' % str(readme_content)
                driver.execute_script(js)
            except Exception as e:
                js = 'document.getElementsByTagName("textarea")[0].value= "质量提升,申请进开发版"'
                driver.execute_script(js)
            # 处理报告方法
            if delay_report:
                driver.find_element_by_xpath("//label[@for='omitReport']").click()
                time.sleep(3)
                driver.find_element_by_class_name("close").click()
            else:
                if report_url.startswith("http"):

                    report_file, dummy = urllib.request.urlretrieve(report_url,
                                                                        os.path.join(os.path.dirname(__file__),
                                                                                     "app_release.xlsx"))
                    driver.find_element_by_id("reportFile").send_keys(report_file)

            time.sleep(2)
            driver.find_element_by_id("startBuild").click()
            print("已提交审批: http://husky.pt.miui.com/admission/app/list")
            driver.quit()


def main(argv):
    change = ""
    user = ""
    tag = ""
    date = ""
    sn = ""
    parms = ""
    label = ""
    account = ""
    password = ""
    try:
        opts, args = getopt.getopt(argv, "hs:t:d:p:c:a:l:")
    except getopt.GetoptError:
        print(
            'usage:python run.py -s <device serial> -t <alpha or dev branch> -d <获取changelog的时间段，参数如下：2018-05-21,2018-05-22> -c <change number> -a <account, password>')
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print('run.py -s <device serial> -t <alpha or dev branch> -d <2018-05-20, 2018-05-21>')
            sys.exit()
        elif opt == "-s":
            sn = arg
        elif opt == "-t":
            tag = arg
        elif opt == "-d":
            date = arg
        elif opt == "-p":
            parms = arg
        elif opt == "-c":
            change = arg
        elif opt == "-a":
            user = arg
            if "," in user:
                account, password = user.split(",")[0], user.split(",")[1]
        elif opt == "-l":
            label = arg

    if len(account) and len(password):
        change_config("\"user\":\"" + load_config()["user"] + "\"", "\"user\":\"" + account + "\"")
        change_config("\"password\":\"" + load_config()["password"] + "\"", "\"password\":\"" + password + "\"")
        print("执行人：" + account)
        # push maven
        _parms = parms.split(",")
        apk_url, report_url, apk_version = _parms[0], _parms[1], _parms[2]
        read_me = ",".join(_parms[3:]) if len(_parms[2:]) > 1 else _parms[3]
        if "http" in apk_url:
            if "http" in report_url:
                trigger_dev_maven_build(apk_url, report_url, apk_version, read_me)  # 开发版push maven
            elif report_url == "none":
                if label:
                    trigger_dev_maven_build(apk_url, report_url, apk_version, read_me, delay_report=True,
                                            label=label)  # 暂缓提交测试报告
                else:
                    print("暂缓提交测试报告需填写LABEL")
            elif report_url == "":
                post_data(apk_url)  # 体验版push maven
                print("体验版PUSH maven")
            return

    # 抓取changelog
    if "," in date and sn == "none":
        start_date, stop_date = date.split(",")[0], date.split(",")[-1]
        if tag == "none" or tag == "":
            print("请填写分支BRANCH,才能生成changelog")
        else:
            branch_dic = {
                "alpha": "v10-alpha",
                "dev": "v10-dev",
                "beta": "v10-beta"
            }
            #if "onlinemiai" != tag:
            email_tc(branch=branch_dic.get(tag, tag), start_time=start_date, stop_time=stop_date)
            if len(account) == 0:
                return

    # 打包
    if tag:
        server = get_server_instance()
        result_url = trigger_tiny_build(server, tag=tag, change=change)
        if result_url is None:
            print("FATAL: tiny build failed!")
            sys.exit(1)
        # 调用推送maven的接口
        # if change == "" or change == "none" and tag:
        #     post_data(result_url)

        if "Lite" in tag and len(result_url) != 0:
            autotest_apk_path = result_url
            print("AUTO:" + autotest_apk_path)

        elif sn != "none" and sn != "all" and sn != "" and len(result_url) != 0:
            autotest_apk_path = parse_tgz_data(result_url, tag=tag)["autotest"]
            print("AUTO:" + autotest_apk_path)
            for s in sn.split(","):
                res = subprocess.Popen("adb -s " + s + " install -r " + autotest_apk_path, shell=True,
                                       stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE).communicate(timeout=120)[0].decode("utf8")
                print(sn + ":" + res)

        elif sn == "all" and len(result_url) != 0:
            autotest_apk_path = parse_tgz_data(result_url, tag=tag)["autotest"]
            print("AUTO:" + autotest_apk_path)
            # res = os.popen("adb devices").read()
            # dev_lst = res.strip().split("\n")[1:]
            # dev_status = {}
            # for dev in dev_lst:
            #     dev_info = dev.split("\t")
            #     if len(dev_info) == 2 and dev_info[1] == "device" and dev_info[0] not in load_config()["blacklist"]:
            #         sn = dev_info[0]
            #         try:
            #             res2 = subprocess.Popen("adb -s " + sn + " install -r " + autotest_apk_path, shell=True,
            #                                     stdout=subprocess.PIPE,
            #                                     stderr=subprocess.PIPE).communicate(timeout=300)[0].decode("utf8")
            #             print(sn + ":" + res2 + "\n")
            #         except Exception as e:
            #             print(str(e))

        elif sn == "" and tag == "onlinemiai":
            parse_tgz_data(result_url, tag=tag)
            if "," in date:
                start_date, stop_date = date.split(",")[0], date.split(",")[-1]

                email_online(branch=tag, start_time=start_date, stop_time=stop_date, resulturl=result_url)

        if len(account) == 0:
            return

if __name__ == "__main__":
    main(sys.argv[1:])
#"email":"xiaoaitest,renxinyi,ai-service-dev-client",