 #!/bin/sh
cd /home/yanglikai/androidproject/lite/XiaoAiLite
git pull
./gradlew build -x lint
