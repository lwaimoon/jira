# -*- coding: utf-8 -*-
import getopt
import json
import sys
import os
import subprocess

import time
import urllib.request
import re

from jenkinsapi.jenkins import Jenkins
# from app_monitor import AppMonitor
import CONST

with open(os.path.join(os.path.abspath(os.path.dirname(__file__)), "project.json"), "r") as f:
    config = json.load(f)

def get_server_instance():
    jenkins_url = 'http://jenkins.cc.d.xiaomi.net'
    server = Jenkins(jenkins_url, username="zhaorikai", password="b77fad59f6a96d86cb0a68e5e2d6c0d4")
    return server

def triger_test(SN, LOOP, FILTER, ENV, POST, MSG, BRANCH):
    '''
    构建jenkins任务
    :param SN: 设备SN号
    :param LOOP: 测试轮数
    :param FILTER: 选择测试的用例集
    :param ENV: 测试环境选择，指的是小爱运行环境：production or staging
    :return:
    '''
    server = get_server_instance()
    job = server.get_job("ST_Client_Lite_Test")
    build_params = dict()
    # build_params["PROJECT_NAME"] = PROJECT_NAME
    build_params["SN"] = SN
    build_params["LOOP"] = LOOP
    build_params["FILTER"] = FILTER
    build_params["ENVIRONMENT"] = ENV
    build_params["POST"] = POST
    build_params["MESSAGE"] = MSG
    build_params["BRANCH"] = BRANCH
    queue_item = job.invoke(build_params=build_params, delay=0)
    queue_item.block_until_building()
    build = queue_item.get_build()
    print("start to build. build number is %s" % build.get_number())
    time.sleep(5)
    # build.block_until_complete(delay=10)
    # build.poll()

def triger_apk_build(SN, BRANCH):
    '''
        构建jenkins任务
        :param SN: 设备SN号,"all" 为全部连接设备
        :param BRANCH: 需要打包的分支
        :return:
        '''
    server = get_server_instance()
    job = server.get_job("ST_client_apk_autotest")
    build_params = dict()
    # build_params["PROJECT_NAME"] = PROJECT_NAME
    build_params["SN"] = SN
    build_params["BRANCH"] = BRANCH
    queue_item = job.invoke(build_params=build_params, delay=0)
    queue_item.block_until_building()
    build = queue_item.get_build()
    print("start to build. build number is %s" % build.get_number())
    build.block_until_complete(delay=10)
    build.poll()
    print(build.get_description)
    return build.get_description()

def download_apk(requestUrl):
    '''
    从云端下载apk文件到本地
    :param requestUrl: apk链接
    :return: apk路径
    '''
    path = "/home/zhaorikai/jenkins/app/"
    apk_file = os.path.join(path, "lite-autotest.apk")
    requestUrl = re.sub(r'[^\x00-\x7f]', '', requestUrl)

    if os.path.exists(path):
        requestUrl = requestUrl.split('"')[1]
        print(requestUrl)
        l,p = urllib.request.urlretrieve(requestUrl, apk_file)
        print("apk_path: " + l)
        if os.path.isfile(apk_file):
            return apk_file
        else:
            print("文件下载失败")
    else:
        os.mkdir(path)
        l, p = urllib.request.urlretrieve(requestUrl, apk_file)
        print("apk_path: " + l)
        if os.path.isfile(apk_file):
            return apk_file
        else:
            print("文件下载失败")

def main(argv):
    with open(CONST.ALARM_FILE, "w") as f:  # 初始化报警过滤文件
        f.write("")
    _loop = "1"
    _apk_file = ""
    _sn = ""
    _env = "production"
    _post = "no"
    _msg = ""
    _branch = ""
    flag = True
    try:
        opts, args = getopt.getopt(argv, "hs:l:e:p:f:m:b:")
    except getopt.GetoptError:
        sys.exit(2)
    for opt, arg in opts:
        if opt == "-l":
            _loop = arg
        elif opt == "-s":
            _sn = arg
        elif opt == "-f":
            _apk_file = arg.strip()
            if _apk_file.startswith("http://"):
                local_file, dummy = urllib.request.urlretrieve(_apk_file, os.path.join(os.path.dirname(__file__), _apk_file.split("/")[-1]))
                _apk_file = local_file
        elif opt == "-e":
            _env = arg
        elif opt == "-p":
            _post = arg
        elif opt == "-m":
            _msg = arg
        elif opt == "-b":
            _branch = arg
        elif opt == "-h":
            print("Usage : python run_triger_jenkins.py -s [device sn number | 'all' mean all devices connected] -l [test loop ] -e [production or staging, default production]")
    if _sn == "all":  # 对服务器上连接的所有手机进行自动化测试
        res = os.popen("adb devices").read()
        dev_lst = res.strip().split("\n")[1:]
        if len(_apk_file) < 4:
            flag = False
            request_url = triger_apk_build(_sn, _branch) # 触发apk打包并返回云端地址
            _apk_file = download_apk(request_url)  # 下载apk

        for dev in dev_lst:
            dev_info = dev.split("\t")
            if all([len(dev_info) == 2, dev_info[1] == "device", dev_info[0] not in config["blacklist"]]):
                sn = dev_info[0]
                res = subprocess.Popen("adb -s %s shell getprop ro.build.product" %sn, shell=True,
                                       stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE).communicate()  # 获取设备名，设备名对应相应的测试用例集
                _filter = res[0].decode("utf8").strip() if "not found" not in res[0].decode("utf8") else "monitor" # 如果获取设备名失败则为监控用例
                print(sn + " : " + _filter)
                if len(_apk_file) > 4 and flag:
                    subprocess.Popen("adb -s %s uninstall com.xiaomi.xiaoailite" % sn, shell=True,
                                     stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE).communicate()  # 先卸载小爱lite，避免低版本无法安装

                if os.path.isfile(_apk_file):
                    res = subprocess.Popen("adb -s %s install -r \"%s\"" % (sn, _apk_file), shell=True,
                                           stdout=subprocess.PIPE,
                                           stderr=subprocess.PIPE).communicate()  # 安装相应的apk

                    if "Success" in res[0].decode("utf8").strip():
                        triger_test(sn, _loop, _filter, _env, _post, _msg, _branch)
                        print(sn + ": " + "Success")
                        print("--------------------------------------------------")
                    else:
                        print("adb install filed:")
                        print(res)
                else:
                    print("apk file 无效，请检查！")
                    return

    else:
        sn_lst = _sn.split(",")  # 对指定sn的设备进行自动化测试
        for sn in sn_lst:
            res = subprocess.Popen("adb -s %s shell getprop ro.build.product" % sn, shell=True,
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE).communicate()
            _filter = res[0].decode("utf8") if "not found" not in res[0].decode("utf8") else "monitor"
            print(sn + " : " + _filter)
            triger_test(sn, _loop, _filter, _env, _post, _msg, _branch)


if __name__ == "__main__":
    main(sys.argv[1:])