#!/usr/bin/env python
# -*- coding: utf-8 -*-
import datetime
import urllib.request
import urllib.parse
import requests
import re

import subprocess
from bs4 import BeautifulSoup


import json, socket, itertools, sys, os
import time
from socketpool.pool import ConnectionPool
from socketpool.conn import TcpConnector

apks_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "apks"))
json_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "apk.json"))

if not os.path.exists(apks_path):
    os.makedirs(apks_path)

# sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), "/../../../"))

class FalconCli(object):

    def __init__(self):
        self.id_counter = itertools.count()
        self.buf_size = 1000
        if not hasattr(FalconCli, 'pool'):
            self.pool = FalconCli.create_pool()
        self._connection = FalconCli.pool.connection()

    @staticmethod
    def create_pool():
        options = {'host': 'transfer.falcon.miliao.srv', 'port': 8433}
        try:
            FalconCli.pool = ConnectionPool(factory=TcpConnector, options=options)
        except Exception as e:
            raise Exception('FalconCli_conn_fail(%s)' % str(e))

    def call(self, name, *params):
        request = dict(id=next(self.id_counter),
                       params=params,
                       method=name)
        payload = json.dumps(request).encode()
        response = '{}'

        with self._connection as conn:
            sent = conn.send(payload)
            response = conn.recv(1024)
        print(payload.decode("utf8"))
        print(response.decode("utf8"))

        # env.logger.debug(payload)
        # env.logger.debug(response)
        response = json.loads(response.decode("utf8"))
        if response.get('error') is not None:
            raise Exception(response.get('error'))
        return response.get('result')

    def send(self, lines):
        s = 0
        resp = []

        while True:
            buf = lines[s:s + self.buf_size]
            s = s + self.buf_size
            if len(buf) == 0:
                break
            r = self.call("Transfer.Update", buf)
            resp.append(r)

        return resp

    def release(self):
        if hasattr(FalconCli, 'pool'):
            FalconCli.pool.release_all()

    def send_alarm(self, tag):
        ts = int(time.time())
        payload = [
            {
                "endpoint": "production",
                "metric": "my_test",#App_Update
                "timestamp": ts,
                "step": 60,
                "value": 1,
                "counterType": "GAUGE",
                "tags": tag,
            }
        ]
        # App_Update
        self.send(payload)
#sys_func_monitor

    def send_message(self, tag):
        ts = int(time.time())
        payload = [
            {
                "endpoint": "production",
                "metric": "my_test",
                "timestamp": ts,
                "step": 60,
                "value": 1,
                "counterType": "GAUGE",
                "tags": tag,
            }
        ]
        self.send(payload)

    def __del__(self):
        try:
            self.release()
        except Exception as e:
            print(e)


class AppMonitor(object):


    def __init__(self):
        global apk_info
        with open(json_path, "r", encoding="utf8") as f:
            apk_info = json.load(f)
        self.latestMailDate = apk_info["last_mail_date"]
        self.latestWechatVersion = apk_info["last_mm_version"]
        self.newApkList = []

    def mailOfUpdate(self):
        from exchangelib import Credentials, Account, DELEGATE
        credentials = Credentials(
            username='yanglikai@xiaomi.com',  # Or myusername@example.com for O365
            password='Kevin_456'
        )
        account = Account(
            primary_smtp_address='yanglikai@xiaomi.com',
            credentials=credentials,
            autodiscover=True,
            access_type=DELEGATE
        )
        # Print first 100 inbox messages in reverse order
        # print(account.version)
        My_Folder = account.inbox
        # print(My_Folder.glob("miuirobot"))
        # items = account.inbox.filter('Subject:小爱应用更新监控(2018-03-14)').order_by('-datetime_received')
        # print(items)
        # print(items.subject)
        for item in My_Folder.glob("miuirobot"):
            for mail in item.all().order_by('-datetime_received')[:1]:
                # 解析邮件标题
                newMailDate = mail.subject.split("(")[-1].strip(")")
                # time_delta = datetime.datetime.strptime(newMailDate, '%Y-%m-%d') - datetime.datetime.strptime(self.latestMailDate, '%Y-%m-%d')
                # if "-" not in str(time_delta):
                if datetime.datetime.strptime(newMailDate, '%Y-%m-%d') > datetime.datetime.strptime(self.latestMailDate, '%Y-%m-%d'):
                    # self.latestMailDate = newMailDate

                    # 解析邮件内容
                    soup = BeautifulSoup(mail.body, "html.parser")
                    table = soup.body.find_all("tr")
                    for td in table[1:]:
                        # print("-----------------------")
                        app_info = td.text.strip().split("\n")
                        app_name = app_info[0]
                        app_pkgname = app_info[1]
                        app_versioncode = app_info[2]
                        app_dlurl = app_info[3]
                        update_date = app_info[4]
                        # tag = "domain=smartApp,App=" + app_name + ",VersionCode=" + app_versioncode + ",download_url="+app_dlurl
                        # FalconCli().send_alarm(tag)
                        local_file, dummy = urllib.request.urlretrieve(app_dlurl,
                                                                       os.path.join(apks_path, app_pkgname + ".apk"))
                        # print(local_file)
                        self._replace(self.latestMailDate, newMailDate)  # 更新apk.json文件
                        self.newApkList.append(local_file)
                    return self.newApkList

    def update_wechat_version(self):
        url = "http://dldir1.qq.com/weixin/android/weixin_android_alpha_config.json"
        try:
            resp = requests.get(url, timeout=10)
            return re.findall(u"versionName:\"([\d\.]+)\"", resp.text)[0]
        except Exception as why:
            print("MMVersion Fetch Err: %s" % why)
            return "NULL"

    def wechat_download_url(self):
        latest_wechat_version = self.update_wechat_version()
        if latest_wechat_version > self.latestWechatVersion:
            # self.latestWechatVersion = self.update_wechat_version()

            _url = "http://support.weixin.qq.com/cgi-bin/mmsupport-bin/readtemplate?t=page/android_exp__index&clientversion=&from=groupmessage&isappinstalled=0"
            header = {'User-agent': 'MicroMessenger '}
            request = urllib.request.Request(_url, headers=header)
            reponse = urllib.request.urlopen(request).read()
            soup = BeautifulSoup(reponse, "html.parser")
            mm_dl_url = ''
            # print(soup.find_all("a"))
            for a in soup.find_all("a"):
                if a.string == "下载最新版微信":
                    mm_dl_url = a["href"]

                    local_file, dummy = urllib.request.urlretrieve(mm_dl_url,
                                                                   os.path.join(apks_path, "com.tencent.mm_" + latest_wechat_version + ".apk"))
                    # self.newApkList.append(local_file)
            # tag = "domain=smartApp,App=微信,Version=" + latest_wechat_version+","+mm_dl_url
            # FalconCli().send_alarm(tag)
            self._replace(self.latestWechatVersion, latest_wechat_version)
            # print("wechat")
            # return self.newApkList
            # print(reponse.decode("utf8"))

    # 爬取豌豆夹上的应用更新
    def spider_wd(self):
        _root_url = "http://www.wandoujia.com/apps/"
        # print(apk_info["app_list"])
        for app in apk_info["app_list"]:
            # print(app["app"])

            wbdata = requests.get(_root_url+app["app"]).text
            soup = BeautifulSoup(wbdata, "html.parser")
            now_version = soup.find("dt", text="版本").find_next("dd").text.strip()
            # print(app["app"] + ":" + now_version)

            if now_version > app["version"]:
                print(app["name"]+"从"+app["version"]+"升级到->"+now_version)
                self._replace(app["version"], now_version)
                self._replace('"version_code":"%s"' % app["version_code"], '"version_code":"%s"' % version_code)
                # tag = "domain=smartApp,App="+app["name"]+",Version=" + app["version"]+"升级到" + now_version
                # FalconCli().send_alarm(tag)
                # local_file, dummy = urllib.request.urlretrieve(dl_url,
                #                                                os.path.join(apks_path,
                #                                                             app["app"] + now_version + ".apk"))
                # self.newApkList.append(local_file)
        # return self.newApkList

    # 爬取360应用市场更新
    def spider_360(self):
        for app in apk_info["app_list"]:
            app_name = app["name"]
            _root_url = "http://zhushou.360.cn/search/index/?kw="+urllib.parse.quote(app_name)

            wbdata = requests.get(_root_url).text
            soup = BeautifulSoup(wbdata, "html.parser")
            app_url = soup.find("a", title=app_name)["href"].split("?")[0]
            soft_id = app_url.split("/")[-1]
            # print(soft_id)
            app_url = "http://zhushou.360.cn"+app_url
            # print(app_url)
            app_soup = BeautifulSoup(requests.get(app_url).text, "html.parser")
            now_version = app_soup.find(text="版本：").find_previous("td").text.replace("版本：", "")
            dl_url = app_soup.find("a", text="立即安装")["href"].split("url=")[-1]
            version_code = dl_url.split("_")[-1].split(".")[0]
            print(app["app"] + ":" + now_version)

            if now_version > app["version"] or version_code > app["version_code"]:
                print(app["name"] + "从" + app["version"] + "-versioncode:"+app["version_code"]+"升级到->" + now_version+"-versioncode:"+version_code)
                self._replace(app["version"], now_version)
                self._replace('"version_code":"%s"' %app["version_code"], '"version_code":"%s"' %version_code)
                tag = "domain=smartApp,App=" + app["name"] + ",Version=" + app["version"]+"升级到" + now_version+",VersionCode=" + app["version_code"]+"升级到" + version_code+",download="+dl_url
                FalconCli().send_alarm(tag)
                local_file, dummy = urllib.request.urlretrieve(dl_url,
                                                               os.path.join(apks_path,
                                                                            app["app"] + now_version + ".apk"))

                self.newApkList.append(local_file)
            # print("wandoujia")

        return self.newApkList

    def _replace(self, A, B):
        f = open(json_path, "r", encoding="utf8")
        s = f.read()
        s = s.replace(A, B)
        f.close()
        p = open(json_path, "w+", encoding="utf8")
        p.write(s)
        p.close()

    # def local_path(self):
    #     # self.mailOfUpdate()
    #     self.wechat_download_url()
    #     self.spider_wd()
    #     return self.newApkList

    def install_all_update(self):
        try:
            print("--------------------------------" + time.strftime("%Y-%m-%d %H-%M-%S") + "--------------------------------")
            self.wechat_download_url()
            self.spider_360()
            # self.spider_wd()
            # AM.mailOfUpdate()
        except Exception as e:
            print("error :")
            print(e)
        finally:
            if len(self.newApkList) > 0:
                res = os.popen("adb devices").read()
                # print(res)
                dev_lst = res.strip().split("\n")[1:]
                sn_lst = []
                for dev in dev_lst:
                    dev_info = dev.split("\t")
                    if len(dev_info) == 2 and dev_info[1] == "device":
                        sn_lst.append(dev_info[0])
                for apk in self.newApkList:
                    for sn in sn_lst:
                        if sn:
                            res = subprocess.Popen("adb -s " + sn + " install -r " + apk, shell=True,
                                                   stdout=subprocess.PIPE,
                                                   stderr=subprocess.PIPE).communicate(timeout=120)[0].decode("utf8")
                        print(" : ".join([res, sn, apk]))



#
# class IpMonitor(object):
#
#     def __init__(self):
#         with open(json_path, "r", encoding="utf8") as f:
#             data = json.load(f)
#         self.ip = data["ip"]
#         ip_now = subprocess.Popen("ifconfig enp0s31f6 | grep \"inet addr\" | awk '{ print $2}' | awk -F: '{print $2}'", shell=True,
#                              stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0].decode("utf8").strip()
#         if ip_now != self.ip and ip_now !="":
#             tag = "domain=smartApp,ip_changed="+ip_now
#             FalconCli().send_message(tag)
#             AppMonitor()._replace(self.ip, ip_now)
#             print(ip_now)


if __name__ == "__main__":
    AM = AppMonitor()
    try:
        print("--------------------------------"+time.strftime("%Y-%m-%d %H-%M-%S")+"--------------------------------")
        AM.wechat_download_url()
        # AM.spider_360()
        AM.spider_wd()
        # AM.mailOfUpdate()
    except Exception as e:
        print("error :")
        print(e)
    finally:
        if len(AM.newApkList) > 0:
            res = os.popen("adb devices").read()
            # print(res)
            dev_lst = res.strip().split("\n")[1:]
            sn_lst = []
            for dev in dev_lst:
                dev_info = dev.split("\t")
                if len(dev_info) == 2 and dev_info[1] == "device":
                    sn_lst.append(dev_info[0])
            for apk in AM.newApkList:
                for sn in sn_lst:
                    if sn:
                        try:
                            res = subprocess.Popen("adb -s " + sn + " install -r " + apk, shell=True,
                                               stdout=subprocess.PIPE,
                                               stderr=subprocess.PIPE).communicate(timeout=300)[0].decode("utf8")
                        except Exception as e:
                            res = "安装失败"
                    print(" : ".join([res, sn, apk]))
#     # print(AM.newApkList)