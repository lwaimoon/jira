# -*- coding:utf-8 -*-
from test import *

with open(os.path.join(os.path.dirname(__file__), "testcase.json"), "r", encoding="utf-8") as f:
    test_cases = json.load(f)  # 解析testcase.json


class TestScript(BaseTestCase):  # 继承BaseTestCase, 在test.__init__.py 下定义

    def setUp(self):
        super(TestScript, self).setUp()
        self.domain = __file__.replace("\\", ".").replace("/", ".").split('.')[-3]  # 命令文件夹名为domain名
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        Common(DUT).switch_card_window_focus(True)  # 开启卡片聚焦状态，模拟点击相关query须关闭False，否则模拟点击会失效

    def test_miot_1(self):
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MiuiVoiceSettingActivity")
        # Common(DUT).click_element(text="更多")
        Checkpoint(DUT).switch_button(text="智能家庭控制授权", nex=2, expected={"checked": "true"})
        Common(DUT).click_element(text="确认授权")
        Checkpoint(DUT).check_element_status(text="智能家庭控制授权", nex=2, expected={"checked": "true"}, refresh=True)


    @parameterized.expand([(test_case["id"], test_case["case"], test_case["check_point"]) for test_case in test_cases])  # 测试用例参数化
    def test_smartMiot(self, name, steps, check_point):
        self.steps = steps
        self.query = steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX  # 尝试次数，默认3次
        while retry_time:
            # common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT),
            #                                            retry_time)  # 执行query

            self.result = True#common_result if not Checkpoint(DUT).check_to_speak("不在线") else True
            if self.result != False:
                break
            else:
                retry_time -= 1
        else:

            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))  # 判断测试结果并发出报警

    def tearDown(self):
        Common(DUT).switch_card_window_focus(False)  # 关闭卡片聚焦状态，模拟点击相关query须关闭False，否则模拟点击会失效
        super(TestScript, self).tearDown()


if __name__ == "__main__":
    unittest.main()
