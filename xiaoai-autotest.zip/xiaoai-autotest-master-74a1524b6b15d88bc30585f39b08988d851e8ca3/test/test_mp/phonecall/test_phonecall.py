#!/usr/bin/env python
# -*- coding:utf-8 -*-
from aw import *
#from alarm import FalconCli
from test import *
import os
import unittest
import json

with open(os.path.join(os.path.dirname(__file__), "testcase.json"), "r", encoding="utf-8") as f:
    test_cases = json.load(f)

class TestScript(BaseTestCase):
    def setUp(self):
        super(TestScript, self).setUp()
        self.domain = __file__.replace("\\", ".").replace("/", ".").split('.')[-3]  # the dirname is domain name
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        Common(DUT).switch_card_window_focus(flag=True)

    @parameterized.expand([(test_case["id"], test_case["case"], test_case["check_point"]) for test_case in test_cases])
    def test_phonecall(self, name, steps, check_point):
        self.steps = steps
        self.query = steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT),
                                                       retry_time)
            self.result = common_result
            if self.result != False:
                break
            else:
                Common(DUT).clearRecentApp()
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))
        Common(DUT).end_call()

    def test_phonecall_2(self):
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MiuiVoiceSettingActivity")
        Common(DUT).click_element(text="更多")
        Common(DUT).click_element(text="解锁设置")
        Common(DUT).switch_button(text="打电话", nex=2, expected={"checked": "false"}, refresh=True)
        if Checkpoint(DUT).check_element_status(text="打电话", nex=2, expected={"checked": "false"}, refresh=True):
            self.steps = {"feature":"打电话","action":"锁屏打电话","setup":"小爱解锁设置-打电话-关闭", "query":[{"lock":""},"打电话给小爱"],"wait_time":[2]}
            self.NodeId = "C3352800"
            check_point = {"to_speak":"解锁"}
            self.query = self.steps["query"]
            wait_time = self.steps["wait_time"]
            retry_time = CONST.RETRY_MAX
            while retry_time:
                common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT),
                                                           Checkpoint(DUT),
                                                           retry_time)
                self.result = common_result
                if self.result != False:
                    break
                else:
                    Common(DUT).end_call()
                    Common(DUT).clearRecentApp()
                    retry_time -= 1
            else:
                Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))
        time.sleep(5)
        # Common(DUT).killXA()
        Common(DUT).unlockScreen(CONST.LOCKPW)
        # Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MiuiVoiceSettingActivity")
        # Common(DUT).click_element(text="更多")
        # Common(DUT).click_element(text="解锁设置")
        Common(DUT).switch_button(text="打电话", nex=2, expected={"checked": "true"}, refresh=True)

    def test_phonecall_3(self):
        '''
        为了实现对phonecall离线在线融合功能的自动化验证，保证离线结果可以在每个版本中生效，并加入例行自动化评测流程:
        测试输入为音频文件，以及每个音频对应的通讯录联系人．检查输出中结果中的字段isUseOnlineResult == false时，即为离在线融合时使用了离线结果，为预期输出．isUseOnlineResult == ture时则应报错．
        '''

        self.steps = {"feature": "打电话", "action": "打电话", "query": ["[离线在线融合功能验证]"],
                      "wait_time": [2]}
        results = []
        Common(DUT).shell("rm -rf /sdcard/autotest/")
        Common(DUT).adbCmd("push " + os.path.join(CONST.RESOURCE_PATH, "phonecall") + " /sdcard/autotest/phonecall/")

        Common(DUT).shell("am startservice -n com.miui.voiceassist/com.xiaomi.voiceassistant.VoiceService -a com.xiaomi.voiceassistant.ACTION_EVALUATE_PHONE")
        time.sleep(30)
        res = Common(DUT).shell("cat /sdcard/autotest/*.txt")[0].decode("utf-8")

        # print(res)
        for line in res.strip().split("\n")[:-1]:
            li = line.split("\t")[1].split("@@")[1]
            print(li)
            if li == "false":
                results.append(True)
            else:
                results.append(False)

        self.result = any(results)

    def tearDown(self):
        super(TestScript, self).tearDown()
        Common(DUT).clearRecentApp()


if __name__ == "__main__":
    TestScript().test_phonecall_3()
    # unittest.main()