from test import *
import os
import json
import unittest
import re

with open(os.path.join(os.path.dirname(__file__), "testcase.json"), "r", encoding="utf-8") as f:
    test_cases = json.load(f)

class TestScript(BaseTestCase):
    def setUp(self):
        super(TestScript, self).setUp()
        self.domain = __file__.replace("\\", ".").replace("/", ".").split('.')[-3]  # the dirname is domain name
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        # Common(DUT).switch_card_window_focus(flag=True)

    @parameterized.expand([(test_case["id"], test_case["case"], test_case["check_point"]) for test_case in test_cases])
    def test_internal_platform(self, name, steps, check_point):
        self.steps = steps
        self.query = steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT),
                                                       retry_time)
            self.result = common_result
            if self.result != False:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))

    @parameterized.expand([
        ("charge", {"feature": "录制屏幕", "query": ["开始录屏", "停止录屏"], "wait_time": [10, 2]},
         {})
    ])
    def test_record_screen(self, name, steps, check_point):
        '''
        Suite Name: Record Scre
        URL: http://intervention.pt.ai.xiaomi.com/skill/75
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        p = re.compile(r'Screenrecorder.*\.mp4')

        while retry_time:
            res1 = Common(DUT).shell("ls /storage/emulated/0/DCIM/ScreenRecorder")[0]
            num_1 = len(p.findall(res1.decode("utf8")))
            time.sleep(2)
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT),
                                                       retry_time)
            res2 = Common(DUT).shell("ls /storage/emulated/0/DCIM/ScreenRecorder")[0]
            num_2 = len(p.findall(res2.decode("utf8")))
            self.result = common_result and (num_2 - num_1) == 1
            time.sleep(2)
            print("after {}\tres: {}, \nbefore {}\tres: {}".format(num_2, res2, num_1, res1))
            if self.result != False:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))

    @parameterized.expand([
        ("start_recorder", {"feature": "录音", "query": ["开始录音"], "wait_time": [7]},
         {"activity": "com.android.soundrecorder/.SoundRecorder"}),
    ])
    def test_recorder(self, name, steps, check_point):
        '''
        Suite Name: Record
        URL: http://intervention.pt.ai.xiaomi.com/skill/71
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT),
                                                       retry_time)
            self.result = common_result
            if self.result != False:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))
        Common(DUT).killApp("com.android.soundrecorder")

    @parameterized.expand([
        ("charge", {"feature": "截屏|截图", "query": ["截屏"], "wait_time": [10]},
         {})
    ])
    def test_screenshot(self, name, steps, check_point):
        '''
        Suite Name: Screen Sh
        URL: http://intervention.pt.ai.xiaomi.com/skill/73
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        p = re.compile(r'Screenshot_.*\.png')

        while retry_time:
            res1 = Common(DUT).shell("ls /storage/emulated/0/DCIM/Screenshots")[0]
            num_1 = len(p.findall(res1.decode("utf8")))
            time.sleep(2)
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT),
                                                       retry_time)
            res2 = Common(DUT).shell("ls /storage/emulated/0/DCIM/Screenshots")[0]
            num_2 = len(p.findall(res2.decode("utf8")))
            self.result = common_result and (num_2 - num_1) == 1

            print("after {}\tres: {}, \nbefore {}\tres: {}".format(num_2, res2, num_1, res1))
            if self.result != False:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))


    def tearDown(self):
        super(TestScript, self).tearDown()
        # Common(DUT).switch_card_window_focus(flag=False)

if __name__ == "__main__":
    unittest.main()
