# -*- coding:utf-8 -*-
from test import *

with open(os.path.join(os.path.dirname(__file__), "testcase.json"), "r", encoding="utf-8") as f:
    test_cases = json.load(f)


class TestScript(BaseTestCase):
    def setUp(self):
        super(TestScript, self).setUp()
        self.domain = __file__.replace("\\", ".").replace("/", ".").split('.')[-3]  # the dirname is domain name
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        Common(DUT).switch_card_window_focus(True)

    @parameterized.expand([(test_case["id"], test_case["case"], test_case["check_point"]) for test_case in test_cases])
    def test_michat(self, name, steps, check_point):
        self.steps = steps
        self.query = steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT),
                                                       retry_time)
            self.result = common_result
            if self.result != False:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))
        Common(DUT).switch_card_window_focus(False)


if __name__ == "__main__":
    unittest.main()
