from test import *
import os
import json
import unittest

with open(os.path.join(os.path.dirname(__file__), "testcase.json"), "r", encoding="utf-8") as f:
    test_cases = json.load(f)

def skip_condition():
    Common(DUT).execute_xa("打开微博")
    time.sleep(8)
    if Checkpoint(DUT).checkIfExist(text="登录") or not Checkpoint(DUT).compare_activity(target_act="com.sina.weibo"):
        print("微博未登录/安装, skip 测试")
        return True

@unittest.skipIf(skip_condition(), "微信未登录/安装")
class TestScript(BaseTestCase):
    def setUp(self):
        super(TestScript, self).setUp()
        self.domain = "smartApp" # the dirname is domain name
        # self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]

    @parameterized.expand([(test_case["id"], test_case["case"], test_case["check_point"]) for test_case in test_cases])
    def test_weibo(self, name, steps, check_point):
        self.steps = steps
        self.query = steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT),
                                                       retry_time)
            self.result = common_result
            if self.result != False:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))

    def tearDown(self):
        super(TestScript, self).tearDown()

if __name__ == "__main__":
    unittest.main()
