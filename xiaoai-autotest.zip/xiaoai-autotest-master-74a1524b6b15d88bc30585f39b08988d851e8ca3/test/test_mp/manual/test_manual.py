# -*- coding:utf-8 -*-
from test import *


class TestScript(BaseTestCase):
    # def setUp(self):
    #     super(TestScript, self).setUp()
    #     self.domain = __file__.replace("\\", ".").replace("/", ".").split('.')[-3]  # 命令文件夹名为domain名
    #     self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]

    def test_manual_001(self):
        result = []
        self.steps = {"cid": "C3284699|C3333669", "feature": "功能测试", "action": "首次Home键唤醒弹出CTA->取消"}
        Common(DUT).clearUserData("com.miui.voiceassist")
        Common(DUT).goBackHome()
        Common(DUT).click_element(text="小爱同学")
        Checkpoint(DUT).checkIfExist(text="同意并继续")
        Common(DUT).click_element(text="取消")
        time.sleep(5)
        result.append(Checkpoint(DUT).compare_activity(target_act="com.miui.home"))
        self.result = all(result)

    def test_manual_002(self):
        result = []
        self.steps = {"cid": "C3284698", "feature": "功能测试", "action": "首次Home键唤醒弹出CTA->同意"}
        Common(DUT).clearUserData("com.miui.voiceassist")
        Common(DUT).goBackHome()
        Common(DUT).click_element(text="小爱同学")
        result.append(Checkpoint(DUT).checkIfExist(text="同意并继续"))
        Common(DUT).click_element(text="同意并继续")
        # Common(DUT).killXA()
        # Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        result.append(Checkpoint(DUT).checkIfExist(text="快速唤醒小爱"))
        Common(DUT).click_element(text="快速唤醒小爱")
        result.append(Checkpoint(DUT).checkIfExist(text="我知道了"))
        Common(DUT).click_element(text="我知道了")
        self.result = all(result)

    def test_manual_003(self):
        result = []
        self.steps = {"cid": "C3333679", "feature": "功能测试", "action": "设置页面"}
        Common(DUT).goBackHome()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MiuiVoiceSettingActivity")
        # 电源键唤醒
        if Checkpoint(DUT).check_element_status(id="android:id/checkbox", expected={"checked":"true"}):
            Common(DUT).click_element(id="android:id/checkbox", index=0)
            result.append(Checkpoint(DUT).check_element_status(id="android:id/checkbox", expected={"checked":"false"}))
        else:
            Common(DUT).click_element(id="android:id/checkbox", index=0)
            Common(DUT).click_element(text="学会了，开始使用")
            result.append(Checkpoint(DUT).check_element_status(id="android:id/checkbox", expected={"checked": "true"}))
        # 语音唤醒
        Common(DUT).click_element(text="语音唤醒")
        Common(DUT).click_element(id="android:id/checkbox", index=0)
        Common(DUT).click_element(text="开始录入")
        result.append(Checkpoint(DUT).checkIfExist(text="请在安静环境下对手机说|我没听清"))
        Common(DUT).goBackHome()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MiuiVoiceSettingActivity")
        # 智能家庭控制
        Common(DUT).switch_button(text="智能家庭控制授权", nex=2, expected={"checked": "true"})
        Common(DUT).click_element(text="确认授权")
        result.append(Checkpoint(DUT).check_element_status(text="智能家庭控制授权", nex=2, expected={"checked": "true"}, refresh=True))

        self.result = all(result)

    def test_manual_004(self):
        result = []
        self.steps = {"cid": "C3333671", "feature": "功能测试", "action": "全部技能"}
        Common(DUT).goBackHome()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MiuiVoiceSettingActivity")
        Common(DUT).click_element(content="全部技能")
        result.append(Checkpoint(DUT).checkIfExist(text="全部技能"))
        result.append(Checkpoint(DUT).checkIfExist(text="推荐"))

        self.result = all(result)

    def test_manual_005(self):
        result = []
        self.steps = {"cid": "C3333672", "feature": "功能测试", "action": "全部技能—训练计划"}
        Common(DUT).goBackHome()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MiuiVoiceSettingActivity")
        Common(DUT).click_element(content="全部技能")
        Common(DUT).click_element(content="训练计划")
        result.append(Checkpoint(DUT).checkIfExist(text="我的训练"))

        self.result = all(result)

    def test_manual_006(self):
        result = []
        self.steps = {"cid": "C3333673|C3333674|C3333675", "feature": "功能测试", "action": "技能详情页"}
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        res_lst = Common(DUT).get_elements("content-desc")
        for i, res in enumerate(res_lst):

            if "“" in res.get("content-desc"):
                print(res.get("content-desc"))
                _content = res_lst[i - 1].get("content-desc")
                print(_content)
                Common(DUT).click_element(content=_content)
                result.append(Checkpoint(DUT).checkIfExist(text=_content))
                result.append(Checkpoint(DUT).checkIfNotExist(text="个人中心"))
                Common(DUT).goBack()
        self.result = all(result)

    def test_manual_007(self):
        result = []
        self.steps = {"cid": "C3333683|C3333684", "feature": "功能测试", "action": "点击示例query直接执行-纯文本的 "}
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        Common(DUT).click_element(content="全部技能")
        Common(DUT).click_element(content="系统")
        res_lst = Common(DUT).get_elements("content-desc")
        for i, res in enumerate(res_lst):

            if "“" in res.get("content-desc"):
                print(res.get("content-desc"))
                _content = res_lst[i - 1].get("content-desc")
                print(_content)
                Common(DUT).click_element(content=_content)
                result.append(Checkpoint(DUT).checkIfExist(text=_content))
                result.append(Checkpoint(DUT).checkIfNotExist(text="全部技能"))
                break
        res_lst_2 = Common(DUT).get_elements("content-desc")
        for i, res in enumerate(res_lst_2):

            if "“" in res.get("content-desc"):
                print(res.get("content-desc"))
                _content = res_lst_2[i].get("content-desc")
                print(_content)
                Common(DUT).click_element(content=_content)
                result.append(Checkpoint(DUT).checkIfNotExist(text=_content))
                break

        Common(DUT).switch_card_window_focus(False)
        self.result = all(result)

    def test_manual_008(self):
        result = []
        self.steps = {"cid": "C3333685", "feature": "功能测试", "action": "点击示例query直接执行-跳出app"}
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        Common(DUT).click_element(content="全部技能")
        Common(DUT).click_element(content="微信")
        Common(DUT).click_element(content='“查看微信”')
        time.sleep(8)
        result.append(Checkpoint(DUT).compare_activity(target_act="com.tencent.mm"))
        self.result = all(result)

    def test_manual_009(self):
        result = []
        self.steps = {"cid": "C3333698", "feature": "功能测试", "action": "进入新建技能界面-已登录"}
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="我的训练")
        Common(DUT).click_element(text='新建训练')
        time.sleep(1)
        result.append(Checkpoint(DUT).compare_activity(target_act="com.miui.voiceassist/com.xiaomi.voiceassistant.skills.ui.CreateCommandActivity"))
        result.append(Checkpoint(DUT).checkIfExist(text="请添加一种说法"))
        self.result = all(result)

    def test_manual_010(self):
        result = []
        self.steps = {"cid": "", "feature": "唤醒测试", "action": "语音唤醒小爱"}
        result.append(Common(DUT).voice_wakeup())
        self.result = all(result)

    def test_manual_011(self):
        result = []
        self.steps = {"cid": "C3374567|C3374570", "feature": "功能测试", "action": "手动开启智能调音-取消"}
        Common(DUT).goBackHome()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MiuiVoiceSettingActivity")
        Common(DUT).click_element(text="小爱实验室")  # 1. 高级设置模块下有“小爱实验室”入口
        result.append(Checkpoint(DUT).checkIfExist(text="根据环境和人声，智能调节小爱回复的音量"))
        Common(DUT).click_element(text="智能调音")
        result.append(Checkpoint(DUT).checkIfExist(text="取消"))  # 3.弹出CTA弹窗提示，文案下方有“不再提示”选项，默认为未勾选，左边为“取消”，右边为“同意并继续”
        result.append(Checkpoint(DUT).checkIfExist(text="同意并继续"))
        result.append(Checkpoint(DUT).checkIfExist(text="不再提示"))
        Common(DUT).click_element(text="不再提示")
        result.append(Checkpoint(DUT).check_element_status(id="android:id/checkbox", expected={"checked": "true"}))
        Common(DUT).click_element(text="取消")
        result.append(Checkpoint(DUT).checkIfExist(text="方言识别"))  # 4.弹窗消失

        self.result = all(result)

    def test_manual_012(self):
        result = []
        self.steps = {"cid": "C3374568", "feature": "功能测试", "action": "手动开启智能调音-同意"}
        Common(DUT).goBackHome()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MiuiVoiceSettingActivity")
        Common(DUT).click_element(text="小爱实验室")  # 1. 高级设置模块下有“小爱实验室”入口
        result.append(Checkpoint(DUT).checkIfExist(text="根据环境和人声，智能调节小爱回复的音量"))
        Common(DUT).click_element(text="智能调音")
        result.append(Checkpoint(DUT).checkIfExist(text="取消"))  # 3.弹出CTA弹窗提示，文案下方有“不再提示”选项，默认为未勾选，左边为“取消”，右边为“同意并继续”
        result.append(Checkpoint(DUT).checkIfExist(text="同意并继续"))
        result.append(Checkpoint(DUT).checkIfExist(text="不再提示"))
        Common(DUT).click_element(text="同意并继续")
        result.append(Checkpoint(DUT).check_element_status(id="android:id/checkbox", expected={"checked": "true"}))  # 4.智能调音开关打开，
        self.result = all(result)
    # 个人中心
    def test_manual_013(self):
        '''
        对话记录-查看个人中心详情页的UI界面显示
        '''
        result = []
        self.steps = {"cid": "C3383463|C3383465", "feature": "功能测试", "action": "个人中心详情页"}
        Common(DUT).goBackHome()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        Common(DUT).click_element(text="个人中心")
        result.append(Checkpoint(DUT).checkIfExist(text="我的训练"))
        result.append(Checkpoint(DUT).checkIfExist(text="对话记录", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(text="个人资料", refresh=False))
        Common(DUT).click_element(text="我的训练")
        result.append(Checkpoint(DUT).checkIfExist(text="新建训练"))
        Common(DUT).goBack()
        Common(DUT).click_element(text="对话记录")
        result.append(Checkpoint(DUT).checkIfExist(text="报错"))
        result.append(Checkpoint(DUT).checkIfExist(text="教教我", refresh=False))
        Common(DUT).goBack()
        Common(DUT).click_element(text="个人资料")
        time.sleep(2)
        result.append(Checkpoint(DUT).checkIfExist(text="公司"))
        Common(DUT).goBack()
        self.result = all(result)

    def test_manual_014(self):
        '''
        对话记录-点击报错按钮
        '''
        result = []
        self.steps = {"cid": "C3383466", "feature": "功能测试", "action": "对话记录-点击报错按钮 "}
        Common(DUT).goBackHome()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        Common(DUT).click_element(text="个人中心")
        Common(DUT).click_element(text="对话记录")
        Common(DUT).click_element(text="报错")
        result.append(Checkpoint(DUT).checkIfExist(text="提交"))
        self.result = all(result)

    def test_manual_015(self):
        '''
        对话记录-点击对话记录卡片上的教教我
        '''
        result = []
        self.steps = {"cid": "C3383479", "feature": "功能测试", "action": "对话记录-点击教教我 "}
        Common(DUT).goBackHome()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        Common(DUT).click_element(text="个人中心")
        Common(DUT).click_element(text="对话记录")
        Common(DUT).click_element(text="教教我")
        result.append(Checkpoint(DUT).checkIfExist(text="新建训练"))
        self.result = all(result)

    def test_manual_016(self):
        '''
        对话记录-在对话记录页面断网
        点击小爱icon-个人中心-对话记录-点击其中一条对话记录中的query
        '''
        Common(DUT).switch_card_window_focus(True)
        query = "打开飞行模式"
        Common(DUT).execute_xa(query)
        result = []
        self.steps = {"cid": "C3383480", "feature": "功能测试", "action": "点击其中一条对话记录"}
        Common(DUT).goBackHome()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        Common(DUT).click_element(text="个人中心")
        Common(DUT).click_element(text="对话记录")
        Common(DUT).click_element(text=query)
        time.sleep(5)
        result.append(Checkpoint(DUT).checkIfExist(text="网络不太好"))
        time.sleep(15)
        result.append(Checkpoint(DUT).checkIfNotExist(text="网络不太好"))  # 15秒后小球消失
        Common(DUT).switch_card_window_focus(False)
        self.result = all(result)
        Common(DUT).execute_xa("关闭飞行模式")

    def test_manual_017(self):
        '''
         Steps
        1.点击小爱icon-个人中心-对话记录-点击对话记录“今天天气”气泡
        2.点击非气泡区域或三秒不操作
        3.点击卡片
        4.在步骤3后点击back键
        Expected Result
        1.界面蒙层，同时唤醒小爱，文字气泡展示相应内容并进行语音播报且出现卡片
        2.卡片消失
        3.跳转至天气详情页内
        4.返回到对话记录页面

        '''
        Common(DUT).switch_card_window_focus(True)
        query = "今天天气"
        Common(DUT).execute_xa(query)
        result = []
        self.steps = {"cid": "C3383488", "feature": "功能测试", "action": "话记录-点击对话记录“今天天气”气泡"}
        Common(DUT).goBackHome()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        Common(DUT).click_element(text="个人中心")
        Common(DUT).click_element(text="对话记录")
        Common(DUT).click_element(text=query)
        time.sleep(5)
        result.append(Checkpoint(DUT).checkIfExist(text="小米天气"))
        Common(DUT).click_element(text="小米天气")
        time.sleep(4)
        result.append(Checkpoint(DUT).compare_activity(target_act="com.miui.weather2"))  # 天气卡片
        Common(DUT).goBack()
        result.append(Checkpoint(DUT).checkIfExist(text="教教我"))  # 天气卡片
        Common(DUT).switch_card_window_focus(False)
        self.result = all(result)

    def test_manual_018(self):
        '''
         Steps
        1.点击小爱icon-个人中心-对话记录-点击对话记录“打开微信”气泡
        Expected Result\
        1.界面蒙层，同时唤醒小爱，文字气泡展示相应内容并进行语音播报且打开微信，执行完之后TTS回复：已打开。且不回到对话记录页面

        '''
        query = "打开相机"
        Common(DUT).execute_xa(query)
        result = []
        self.steps = {"cid": "C3383489", "feature": "功能测试", "action": "点击对话记录“打开微信”气泡"}
        Common(DUT).goBackHome()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        Common(DUT).click_element(text="个人中心")
        Common(DUT).click_element(text="对话记录")
        Common(DUT).click_element(text=query)
        time.sleep(5)

        result.append(Checkpoint(DUT).compare_activity(target_act="camera"))  # 进入相机
        Common(DUT).goBack()
        result.append(Checkpoint(DUT).checkIfExist(text="教教我"))  # 天气卡片
        self.result = all(result)

    def test_manual_019(self):
        '''
          Steps

        1.点击小爱icon-个人中心-对话记录-点击对话记录“用微信发消息”气泡
        Expected Result

        1.界面蒙层，同时唤醒小爱，文字气泡展示相应内容并进行语音播报且打开微信执行多轮对话，完成之后，不会回到对话记录页面，对话记录页面显示为：记录多轮询问的query

        '''
        query = "用微信发消息"
        Common(DUT).execute_xa(query)
        result = []
        self.steps = {"cid": "C3383493", "feature": "功能测试", "action": "点击对话记录“用微信发消息”气泡"}
        Common(DUT).goBackHome()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        Common(DUT).click_element(text="个人中心")
        Common(DUT).click_element(text="对话记录")
        Common(DUT).click_element(text=query)
        time.sleep(5)

        result.append(Checkpoint(DUT).check_to_speak("发给谁呢"))  # 进入多轮
        query2 = "小爱"
        Common(DUT).execute_xa(query2)
        Common(DUT).goBackHome()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        Common(DUT).click_element(text="个人中心")
        Common(DUT).click_element(text="对话记录")
        result.append(Checkpoint(DUT).checkIfExist(text=query2))

        self.result = all(result)

    #  query编辑
    def test_manual_020(self):
        '''
         Steps
        1.唤醒小爱录入query：今天天气
        2.点击query文字或文字末尾的编辑符号
        3.修改query为“明天天气”，点击【确定】
        Expected Result
        1.给出今天天气的TTS回复和对应卡片，TTS气泡第一行引号内展示录入的query“今天天气”，query文字末尾附有一个编辑的符号
        2.弹出query编辑页面，出现黑色蒙层，页面正中间文本框内显示query，文本框最右端为【确定】键，同时底部弹出输入法框
        3.该界面消失，自动录入query“明天天气”，并给出明天天气的TTS回复和对应卡片


        '''
        Common(DUT).switch_card_window_focus(True)
        query = "今天天气"
        Common(DUT).execute_xa(query)
        result = []
        self.steps = {"cid": "C3388567", "feature": "功能测试", "action": "既定query再次编辑 "}

        Common(DUT).click_element(id="com.miui.voiceassist:id/txv_query")
        result.append(Checkpoint(DUT).checkIfExist(text=query))
        query2 = "明天天气"
        Common(DUT).inputText(query2)
        result.append(Checkpoint(DUT).checkIfExist(text="确定"))
        Common(DUT).click_element(text="确定")
        time.sleep(5)

        result.append(Checkpoint(DUT).checkIfExist(text=query2))
        result.append(Checkpoint(DUT).checkIfExist(text="小米天气"))

        self.result = all(result)

    def test_manual_021(self):
        '''
         Steps

        1.唤醒小爱录入query：刘德华
        2.点击query文字或文字末尾的编辑符号
        3.删除文本框内所有内容
        4.点击【取消】键
        Expected Result

        1.给出刘德华的人物卡片和TTS回复，TTS气泡第一行引号内展示录入的query“刘德华”，query文字末尾附有一个编辑的符号
        2.弹出query编辑页面，出现黑色蒙层，页面正中间文本框内显示query，文本框最右端为【确定】键，同时底部弹出输入法框
        3.文本框最右端的【确定】键变为【取消】键
        4.该界面消失


        '''
        Common(DUT).switch_card_window_focus(True)
        query = "刘德华"
        Common(DUT).execute_xa(query)
        result = []
        self.steps = {"cid": "C3388568", "feature": "功能测试", "action": "清空query内容"}

        Common(DUT).click_element(id="com.miui.voiceassist:id/txv_query")
        result.append(Checkpoint(DUT).checkIfExist(text=query))
        Common(DUT).inputText("")
        result.append(Checkpoint(DUT).checkIfExist(text="取消"))
        Common(DUT).click_element(text="取消")
        time.sleep(5)

        result.append(Checkpoint(DUT).checkIfExist(text="人物"))

        self.result = all(result)

    def test_manual_022(self):
        '''
         Steps
        1.唤醒小爱录入query：1加1等于几
        2.点击query文字或文字末尾的编辑符号
        3.点击除文本框和输入法框外的其他区域
        4.在步骤2之后点击back键
        5.再次点击back键
        Expected Result
        1.TTS回复1加1的结果并给出对应卡片，TTS气泡第一行引号内展示录入的query“1加1等于几”，query文字末尾附有一个编辑的符号
        2.弹出query编辑页面，出现黑色蒙层，页面正中间文本框内显示query，文本框最右端为【确定】键，同时底部弹出输入法框
        3.该界面消失
        4.输入法框消失
        5.该界面消失

        '''
        Common(DUT).switch_card_window_focus(True)
        query = "1加1等于几"
        Common(DUT).execute_xa(query)
        result = []
        self.steps = {"cid": "C3388568", "feature": "功能测试", "action": "退出query编辑页面"}

        Common(DUT).click_element(id="com.miui.voiceassist:id/txv_query")
        result.append(Checkpoint(DUT).checkIfExist(text=query))
        Common(DUT).inputText("")
        result.append(Checkpoint(DUT).checkIfExist(text="取消"))
        Common(DUT).click_element(text="取消")
        time.sleep(5)

        result.append(Checkpoint(DUT).checkIfExist(text="人物"))

        self.result = all(result)





    def tearDown(self):
        super(TestScript, self).tearDown()
        Common(DUT).clearRecentApp()



if __name__ == "__main__":
    TestScript().test_manual_007()
    # unittest.main()