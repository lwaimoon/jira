from test import *


class TestScript(unittest.TestCase):
    def setUp(self):
        super(TestScript, self).setUp()
        self.domain = __file__.replace("\\", ".").replace("/", ".").split('.')[-3]  # 命令文件夹名为domain名
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]

    def test_manual_000(self):
        result = []
        self.id = "C3443348"
        self.steps = {"action": "AI按键双击唤醒小爱"}
        Common(DUT).clearUserData("com.miui.voiceassist")
        Common(DUT).goBackHome()
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).AIkey("double", " ")
        time.sleep(5)
        self.assertEqual(all(result), True)

    def test_manual_001(self):
        result = []
        self.steps = {"action": "AI按键单击"}
        Common(DUT).goBackHome()
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).AIkey("single", "今天天气好吗")
        time.sleep(5)
        result.append(Checkpoint(DUT).checkIfExist(text="小米天气"))
        print(result)
        self.assertEqual(all(result), True)

    def test_manual_002(self):
        result = []
        self.steps = {"action": "AI按键设置"}
        Common(DUT).goBackHome()
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).launchApp("com.miui.voiceassist/com.xiaomi.voiceassistant.AiSettings.AiSettingsActivity")
        result.append(Checkpoint(DUT).checkIfExist(text="单击AI键"))
        # Common(DUT).click_element(text="单击AI键")
        # time.sleep(5)
        # Checkpoint(DUT).checkIfExist(text="用小爱同学新建任务")
        # Common(DUT).click_element(text="用小爱同学新建任务")
        # time.sleep(5)
        # Checkpoint(DUT).checkIfExist(text="了解小爱更多功能")
        # Common(DUT).click_element(text="了解小爱更多功能")
        # time.sleep(5)
        # result.append(Checkpoint(DUT).compare_activity(target_act="com.miui.voiceassist/com.xiaomi.voiceassistant.skills.ui.PublicSkillsActivity"))
        # Checkpoint(DUT).checkIfExist(text="全部技能")
        self.assertEquals(all(result), True)

    def test_manual_003(self):
        result = []
        self.steps = {"action": "AI按键设置"}
        Common(DUT).goBackHome()
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).launchApp("com.miui.voiceassist/com.xiaomi.voiceassistant.AiSettings.AiSettingsActivity")
        Checkpoint(DUT).checkIfExist(text="单击AI键")
        Common(DUT).click_element(text="单击AI键")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="用小爱同学新建任务")
        Common(DUT).click_element(text="用小爱同学新建任务")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="录制指令")
        Common(DUT).click_element(text="录制指令")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="你说")
        Checkpoint(DUT).checkIfExist(resourceId="com.miui.voiceassist:id/exit")
        self.assertEquals(all(result), True)

    def test_manual_004(self):
        result = []
        self.steps = {"action": "AI按键设置"}
        Common(DUT).goBackHome()
        Common(DUT).switch_card_window_focus(True)

    def test_manual_005(self):
        result = []
        self.steps = {"action": "AI按键单击计划"}
        Common(DUT).goBackHome()
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).launchApp("com.miui.voiceassist/com.xiaomi.voiceassistant.AiSettings.AiSettingsActivity")
        Checkpoint(DUT).checkIfExist(text="双击AI键")
        Common(DUT).click_element(text="双击AI键")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="展开更多")
        Common(DUT).click_element(text="展开更多")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="双击")
        Checkpoint(DUT).checkIfExist(resourceId="com.miui.voiceassist:id/selected_image")
        result.append(Checkpoint(DUT).compare_activity(target_act="com.miui.voiceassist/com.xiaomi.voiceassistant.AiSettings.AiSettingsSubActivity"))
        self.assertEquals(all(result), True)

    def test_manual_006(self):
        result = []
        self.steps = {"action": "AI单击offline"}
        Common(DUT).goBackHome()
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).launchApp("com.miui.voiceassist/com.xiaomi.voiceassistant.AiSettings.AiSettingsActivity")
        Common(DUT).close_wifi()
        Checkpoint(DUT).checkIfExist(text="单击AI键")
        Common(DUT).click_element(text="单击AI键")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="网络不太好，请检查下网络设置或等下再试吧")
        self.assertEquals(all(result), True)
        Common(DUT).open_wifi()
        time.sleep(5)

    def test_manual_007(self):
        result = []
        self.steps = {"action": "AI按键单击唤醒小爱"}
        Common(DUT).goBackHome()
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).AIkey("single", "")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(resourceId="com.miui.voiceassist:id/flex_box_layout")
        self.assertEqual(all(result), True)

    def test_manual_008(self):
        result = []
        self.id = "C3443348"
        self.steps = {"action": "查看AI键入口"}
        Common(DUT).goBackHome()
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).launchApp("com.miui.voiceassist/com.xiaomi.voiceassistant.MiuiVoiceSettingActivity")
        Checkpoint(DUT).checkIfExist(text="AI按键")
        time.sleep(5)
        self.assertEqual(all(result), True)

    def test_manual_009(self):
        result = []
        self.id = "C3443229"
        self.steps = {"action": "查看AI键入口"}
        Common(DUT).goBackHome()
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).launchApp("com.miui.voiceassist/com.xiaomi.voiceassistant.MiuiVoiceSettingActivity")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="AI按键")
        Common(DUT).click_element(text="AI按键")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="AI键")
        Checkpoint(DUT).compare_activity(target_act="com.miui.voiceassist/com.xiaomi.voiceassistant.AiSettings.AiSettingsActivity")
        self.assertEqual(all(result), True)

    def test_manual_010(self):
        result = []
        self.id = "C3443230"
        self.steps = {"action": "单击AI键指令设置"}
        Common(DUT).goBackHome()
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).launchApp("com.miui.voiceassist/com.xiaomi.voiceassistant.AiSettings.AiSettingsActivity")
        Checkpoint(DUT).checkIfExist(text="单击AI键")
        Common(DUT).click_element(text="单击AI键")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="单击")
        Checkpoint(DUT).checkIfExist(resourceId="com.miui.voiceassist:id/item_layout")
        result.append(Checkpoint(DUT).compare_activity(target_act="com.miui.voiceassist/com.xiaomi.voiceassistant.AiSettings.AiSettingsSubActivity"))
        self.assertEquals(all(result), True)

    def test_manual_011(self):
        result = []
        self.id = "C3443231"
        self.steps = {"action": "双击AI键指令设置"}
        Common(DUT).goBackHome()
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).launchApp("com.miui.voiceassist/com.xiaomi.voiceassistant.AiSettings.AiSettingsActivity")
        Checkpoint(DUT).checkIfExist(text="双击AI键")
        Common(DUT).click_element(text="双击AI键")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="双击")
        Checkpoint(DUT).checkIfExist(resourceId="com.miui.voiceassist:id/item_layout")
        result.append(Checkpoint(DUT).compare_activity(target_act="com.miui.voiceassist/com.xiaomi.voiceassistant.AiSettings.AiSettingsSubActivity"))
        self.assertEquals(all(result), True)

    def test_manual_012(self):
        result = []
        self.id = "C3442845"
        self.steps = {"action": "首次单击AI键进入单击引导界面"}
        Common(DUT).clearUserData("com.miui.voiceassist")
        Common(DUT).goBackHome()
        Common(DUT).click_element(text="小爱同学")
        Checkpoint(DUT).checkIfExist(text="同意并继续")
        Common(DUT).click_element(text="同意并继续")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="体验单击AI键")
        Common(DUT).click_element(text="体验单击AI键")
        time.sleep(5)
        Checkpoint(DUT).compare_activity(target_act="com.miui.voiceassist/com.xiaomi.voiceassistant.guidePage.aiKey.AiKeyGuidePageActivity")
        time.sleep(3)
        self.assertEqual(all(result), True)

    def test_manual_013(self):
        result = []
        self.id = "C3442845"
        self.steps = {"action": "首次单击AI键进入单击引导界面"}
        Common(DUT).clearUserData("com.miui.voiceassist")
        Common(DUT).goBackHome()
        Common(DUT).click_element(text="小爱同学")
        Checkpoint(DUT).checkIfExist(text="同意并继续")
        Common(DUT).click_element(text="同意并继续")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="稍后再试")
        Common(DUT).click_element(text="稍后再试")
        time.sleep(5)
        Checkpoint(DUT).compare_activity(target_act="com.miui.home")
        time.sleep(3)
        self.assertEqual(all(result), True)

    def test_manual_014(self):
        result = []
        self.id = "C3443077"
        self.steps = {"action": "设置单击AI键指令界面，点击重新体验"}
        Common(DUT).clearUserData("com.miui.voiceassist")
        Common(DUT).goBackHome()
        Common(DUT).click_element(text="小爱同学")
        Checkpoint(DUT).checkIfExist(text="同意并继续")
        Common(DUT).click_element(text="同意并继续")
        time.sleep(5)
        Common(DUT).AIkey("single", "")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="重新体验")
        Common(DUT).click_element(text="重新体验")
        time.sleep(3)
        Checkpoint(DUT).compare_activity(target_act="com.miui.voiceassist/com.xiaomi.voiceassistant.guidePage.aiKey.AiKeyGuidePageActivity")
        self.assertEqual(all(result), True)

    def test_manual_015(self):
        result = []
        self.id = "C3443076"
        self.steps = {"action": "设置单击AI键指令界面,点击继续"}
        Common(DUT).clearUserData("com.miui.voiceassist")
        Common(DUT).goBackHome()
        Common(DUT).click_element(text="小爱同学")
        Checkpoint(DUT).checkIfExist(text="同意并继续")
        Common(DUT).click_element(text="同意并继续")
        time.sleep(5)
        Common(DUT).AIkey("single", "")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="继续")
        Common(DUT).click_element(text="继续")
        time.sleep(3)
        Checkpoint(DUT).checkIfExist(text="完成并进入小爱同学")
        self.assertEqual(all(result), True)

    def test_manual_016(self):
        result = []
        self.id = "C3443078"
        self.steps = {"action": "设置单击AI键指令界面,手动设置"}
        Common(DUT).clearUserData("com.miui.voiceassist")
        Common(DUT).goBackHome()
        Common(DUT).click_element(text="小爱同学")
        Checkpoint(DUT).checkIfExist(text="同意并继续")
        Common(DUT).click_element(text="同意并继续")
        time.sleep(5)
        Common(DUT).AIkey("single", "")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="截图")
        Common(DUT).click_element(text="截图")
        time.sleep(3)
        Checkpoint(DUT).checkIfExist(text="继续")
        Common(DUT).click_element(text="继续")
        time.sleep(3)
        Checkpoint(DUT).checkIfExist(text="完成并进入小爱同学")
        self.assertEqual(all(result), True)

    def test_manual_017(self):
        result = []
        self.id = "C3443140"
        self.steps = {"action": "设置单击AI键"}
        Common(DUT).clearUserData("com.miui.voiceassist")
        Common(DUT).goBackHome()
        Common(DUT).click_element(text="小爱同学")
        Checkpoint(DUT).checkIfExist(text="同意并继续")
        Common(DUT).click_element(text="同意并继续")
        time.sleep(5)
        Common(DUT).AIkey("single", "")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="截图")
        Common(DUT).click_element(text="截图")
        time.sleep(3)
        Checkpoint(DUT).checkIfExist(text="继续")
        Common(DUT).click_element(text="继续")
        time.sleep(3)
        Checkpoint(DUT).checkIfExist(text="设置-AI键")
        Common(DUT).click_element(text="设置-AI键")
        time.sleep(3)
        Checkpoint(DUT).checkIfExist(text="双击")
        Checkpoint(DUT).compare_activity(target_act="com.miui.voiceassist/com.xiaomi.voiceassistant.AiSettings.AiSettingsSubActivity")
        self.assertEqual(all(result), True)

    def test_manual_018(self):
        result = []
        self.id = "C3443141"
        self.steps = {"action": "设置单击AI键,进入小爱同学"}
        Common(DUT).clearUserData("com.miui.voiceassist")
        Common(DUT).goBackHome()
        Common(DUT).click_element(text="小爱同学")
        Checkpoint(DUT).checkIfExist(text="同意并继续")
        Common(DUT).click_element(text="同意并继续")
        time.sleep(5)
        Common(DUT).AIkey("single", "")
        time.sleep(5)
        Checkpoint(DUT).checkIfExist(text="截图")
        Common(DUT).click_element(text="截图")
        time.sleep(3)
        Checkpoint(DUT).checkIfExist(text="继续")
        Common(DUT).click_element(text="继续")
        time.sleep(3)
        Checkpoint(DUT).checkIfExist(text="完成并进入小爱同学")
        Common(DUT).click_element(text="完成并进入小爱同学")
        time.sleep(3)
        Checkpoint(DUT).compare_activity(target_act="com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        self.assertEqual(all(result), True)

    def tearDown(self):
        Common(DUT).goBackHome()



if __name__ == "__main__":
    TestScript().test_manual_002()
    # unittest.main()
