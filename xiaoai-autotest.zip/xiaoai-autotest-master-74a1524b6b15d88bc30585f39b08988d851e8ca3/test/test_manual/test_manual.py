# -*- coding:utf-8 -*-
from test import *


class TestScript(BaseTestCase):
    # def setUp(self):
    #     super(TestScript, self).setUp()
    #     self.domain = __file__.replace("\\", ".").replace("/", ".").split('.')[-3]  # 命令文件夹名为domain名
    #     self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]

    def test_manual_000(self):
        Common(DUT).clearUserData("com.miui.voiceassist")
        Common(DUT).goBackHome()
        Common(DUT).click_element(text="小爱同学")
        Checkpoint(DUT).checkIfExist(text="同意并继续")
        Common(DUT).click_element(text="同意并继续")
        Common(DUT).click_element(text="跳过")

    def test_manual_001(self):
        result = []
        self.steps = {"cid": "C3284699|C3333669", "feature": "功能测试", "action": "首次Home键唤醒弹出CTA->取消"}
        Common(DUT).clearUserData("com.miui.voiceassist")
        Common(DUT).goBackHome()
        Common(DUT).click_element(text="小爱同学")
        Checkpoint(DUT).checkIfExist(text="同意并继续")
        Common(DUT).click_element(text="取消")
        time.sleep(5)
        result.append(Checkpoint(DUT).compare_activity(target_act="com.miui.home"))
        self.result = all(result)

    def test_manual_002(self):
        result = []
        self.steps = {"cid": "C3284698", "feature": "功能测试", "action": "首次Home键唤醒弹出CTA->同意"}
        Common(DUT).clearUserData("com.miui.voiceassist")
        Common(DUT).goBackHome()
        Common(DUT).click_element(text="小爱同学")
        result.append(Checkpoint(DUT).checkIfExist(text="同意并继续"))
        Common(DUT).click_element(text="同意并继续")
        # Common(DUT).killXA()
        # Common(DUT).open_xiaoai_main()
        result.append(Checkpoint(DUT).checkIfExist(text="快速唤醒小爱"))
        Common(DUT).click_element(text="快速唤醒小爱")
        result.append(Checkpoint(DUT).checkIfExist(text="我知道了"))
        Common(DUT).click_element(text="我知道了")
        self.result = all(result)

    def test_manual_003(self):
        result = []
        self.steps = {"cid": "C3333679", "feature": "功能测试", "action": "设置页面"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_setting()
        # 电源键唤醒
        if Checkpoint(DUT).check_element_status(id="android:id/checkbox", expected={"checked":"true"}):
            Common(DUT).click_element(id="android:id/checkbox", index=0)
            result.append(Checkpoint(DUT).check_element_status(id="android:id/checkbox", expected={"checked":"false"}))
        else:
            Common(DUT).click_element(id="android:id/checkbox", index=0)
            Common(DUT).click_element(text="学会了，开始使用")
            result.append(Checkpoint(DUT).check_element_status(id="android:id/checkbox", expected={"checked": "true"}))
        # 语音唤醒
        Common(DUT).click_element(text="语音唤醒")
        Common(DUT).click_element(id="android:id/checkbox", index=0)
        Common(DUT).click_element(text="开始录入")
        result.append(Checkpoint(DUT).checkIfExist(text="请在安静环境下对手机说|我没听清|走神了|开小差"))
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_setting()
        # 智能家庭控制
        Common(DUT).switch_button(text="智能家庭控制授权", nex=2, expected={"checked": "true"})
        Common(DUT).click_element(text="确认授权")
        result.append(Checkpoint(DUT).check_element_status(text="智能家庭控制授权", nex=2, expected={"checked": "true"}, refresh=True))

        self.result = all(result)

    def test_manual_004(self):
        result = []
        self.steps = {"cid": "C3333671", "feature": "功能测试", "action": "全部技能"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="全部技能")
        result.append(Checkpoint(DUT).checkIfExist(text="全部技能"))
        result.append(Checkpoint(DUT).checkIfExist(text="推荐"))

        self.result = all(result)

    def test_manual_005(self):
        result = []
        self.steps = {"cid": "C3333672", "feature": "功能测试", "action": "全部技能—训练计划"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="全部技能")
        Common(DUT).click_element(content="训练计划")
        result.append(Checkpoint(DUT).checkIfExist(text="我的训练"))

        self.result = all(result)

    def test_manual_006(self):
        result = []
        self.steps = {"cid": "C3333673|C3333674|C3333675", "feature": "功能测试", "action": "技能详情页"}
        Common(DUT).open_xiaoai_main()
        res_lst = Common(DUT).get_elements("content-desc")
        for i, res in enumerate(res_lst):

            if "“" in res.get("content-desc"):
                print(res.get("content-desc"))
                _content = res_lst[i - 1].get("content-desc")
                print(_content)
                Common(DUT).click_element(content=_content)
                result.append(Checkpoint(DUT).checkIfExist(text=_content))
                result.append(Checkpoint(DUT).checkIfNotExist(text="个人中心"))
                Common(DUT).goBack()
        self.result = all(result)

    def test_manual_007(self):
        result = []
        self.steps = {"cid": "C3333683|C3333684", "feature": "功能测试", "action": "点击示例query直接执行-纯文本的 "}
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="全部技能")
        Common(DUT).click_element(content="系统")
        res_lst = Common(DUT).get_elements("content-desc")
        for i, res in enumerate(res_lst):

            if "“" in res.get("content-desc"):
                print(res.get("content-desc"))
                _content = res_lst[i - 1].get("content-desc")
                print(_content)
                Common(DUT).click_element(content=_content)
                result.append(Checkpoint(DUT).checkIfExist(text=_content))
                result.append(Checkpoint(DUT).checkIfNotExist(text="全部技能"))
                break
        res_lst_2 = Common(DUT).get_elements("content-desc")
        for i, res in enumerate(res_lst_2):

            if "“" in res.get("content-desc"):
                print(res.get("content-desc"))
                _content = res_lst_2[i].get("content-desc")
                print(_content)
                Common(DUT).click_element(content=_content)
                result.append(Checkpoint(DUT).checkIfNotExist(text=_content))
                break

        Common(DUT).switch_card_window_focus(False)
        self.result = all(result)

    def test_manual_008(self):
        result = []
        self.steps = {"cid": "C3333685", "feature": "功能测试", "action": "点击示例query直接执行-跳出app"}
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="全部技能")
        Common(DUT).click_element(content="微信")
        Common(DUT).click_element(content='“查看微信”')
        time.sleep(8)
        result.append(Checkpoint(DUT).compare_activity(target_act="com.tencent.mm"))
        self.result = all(result)

    def test_manual_009(self):
        result = []
        self.steps = {"cid": "C3333698", "feature": "功能测试", "action": "进入新建技能界面-已登录"}
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="我的训练")
        Common(DUT).click_element(text='新建训练')
        time.sleep(1)
        result.append(Checkpoint(DUT).compare_activity(target_act="com.miui.voiceassist/com.xiaomi.voiceassistant.skills.ui.CreateCommandActivity"))
        result.append(Checkpoint(DUT).checkIfExist(text="请添加一种说法"))
        self.result = all(result)

    def test_manual_010(self):
        result = []
        self.steps = {"cid": "", "feature": "唤醒测试", "action": "语音唤醒小爱"}
        result.append(Common(DUT).voice_wakeup())
        self.result = all(result)

    # 3.3.0
    def test_manual_011(self):
        result = []
        self.steps = {"cid": "C3374567|C3374570", "feature": "功能测试", "action": "手动开启智能调音-取消"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_setting()
        Common(DUT).click_element(text="小爱实验室")  # 1. 高级设置模块下有“小爱实验室”入口
        result.append(Checkpoint(DUT).checkIfExist(text="根据环境和人声，智能调节小爱同学回复的音量"))
        Common(DUT).click_element(text="智能调音")
        result.append(Checkpoint(DUT).checkIfExist(text="取消"))  # 3.弹出CTA弹窗提示，文案下方有“不再提示”选项，默认为未勾选，左边为“取消”，右边为“同意并继续”
        result.append(Checkpoint(DUT).checkIfExist(text="同意并继续"))
        result.append(Checkpoint(DUT).checkIfExist(text="不再提示"))
        Common(DUT).click_element(text="不再提示")
        result.append(Checkpoint(DUT).check_element_status(id="android:id/checkbox", expected={"checked": "true"}))
        Common(DUT).click_element(text="取消")
        result.append(Checkpoint(DUT).checkIfExist(text="方言识别"))  # 4.弹窗消失

        self.result = all(result)

    def test_manual_012(self):
        result = []
        self.steps = {"cid": "C3374568", "feature": "功能测试", "action": "手动开启智能调音-同意"}
        Common(DUT).clearUserData("com.miui.voiceassist")
        Common(DUT).open_xiaoai_main()
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_setting()
        Common(DUT).click_element(text="小爱实验室")  # 1. 高级设置模块下有“小爱实验室”入口
        result.append(Checkpoint(DUT).checkIfExist(text="根据环境和人声，智能调节小爱同学回复的音量"))
        Common(DUT).click_element(text="智能调音")
        result.append(Checkpoint(DUT).checkIfExist(text="取消"))  # 3.弹出CTA弹窗提示，文案下方有“不再提示”选项，默认为未勾选，左边为“取消”，右边为“同意并继续”
        result.append(Checkpoint(DUT).checkIfExist(text="同意并继续"))
        result.append(Checkpoint(DUT).checkIfExist(text="不再提示"))
        Common(DUT).click_element(text="同意并继续")
        result.append(Checkpoint(DUT).check_element_status(id="android:id/checkbox", expected={"checked": "true"}))  # 4.智能调音开关打开，
        self.result = all(result)
    # 个人中心
    def test_manual_013(self):
        '''
        对话记录-查看个人中心详情页的UI界面显示
        '''
        result = []
        Common(DUT).execute_xa("今天天气怎么样")  # 添加对话记录
        time.sleep(5)
        self.steps = {"cid": "C3383463|C3383465", "feature": "功能测试", "action": "个人中心详情页"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        result.append(Checkpoint(DUT).checkIfExist(text="我的训练"))
        result.append(Checkpoint(DUT).checkIfExist(text="对话记录", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(text="个人资料", refresh=False))
        Common(DUT).click_element(text="我的训练")
        result.append(Checkpoint(DUT).checkIfExist(text="新建训练"))
        Common(DUT).goBack()
        Common(DUT).click_element(text="对话记录")
        result.append(Checkpoint(DUT).checkIfExist(text="报错"))
        result.append(Checkpoint(DUT).checkIfExist(text="教教我", refresh=False))
        Common(DUT).goBack()
        Common(DUT).click_element(text="个人资料")
        time.sleep(2)
        result.append(Checkpoint(DUT).checkIfExist(text="公司"))
        Common(DUT).goBack()
        self.result = all(result)

    def test_manual_014(self):
        '''
        对话记录-点击报错按钮
        '''
        result = []
        self.steps = {"cid": "C3383466", "feature": "功能测试", "action": "对话记录-点击报错按钮 "}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="对话记录")
        Common(DUT).click_element(text="报错")
        result.append(Checkpoint(DUT).checkIfExist(text="提交"))
        self.result = all(result)

    def test_manual_015(self):
        '''
        对话记录-点击对话记录卡片上的教教我
        '''
        result = []
        self.steps = {"cid": "C3383479", "feature": "功能测试", "action": "对话记录-点击教教我 "}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="对话记录")
        Common(DUT).click_element(text="教教我")
        result.append(Checkpoint(DUT).checkIfExist(text="新建训练"))
        self.result = all(result)

    def test_manual_016(self):
        '''
        对话记录-在对话记录页面断网
        点击小爱icon-个人中心-对话记录-点击其中一条对话记录中的query
        '''
        Common(DUT).switch_card_window_focus(True)
        query = "关闭飞行模式"
        Common(DUT).execute_xa(query)
        time.sleep(10)
        result = []
        self.steps = {"cid": "C3383480", "feature": "功能测试", "action": "点击其中一条对话记录"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="对话记录")
        Common(DUT).close_wifi()
        Common(DUT).close_data()
        time.sleep(5)
        Common(DUT).click_element(text=query)
        time.sleep(5)
        result.append(Checkpoint(DUT).checkIfExist(text="网络不太好"))
        time.sleep(15)
        result.append(Checkpoint(DUT).checkIfNotExist(text="网络不太好"))  # 15秒后小球消失
        Common(DUT).switch_card_window_focus(False)
        self.result = all(result)
        Common(DUT).open_wifi()

    def test_manual_017(self):
        '''
         Steps
        1.点击小爱icon-个人中心-对话记录-点击对话记录“今天天气”气泡
        2.点击非气泡区域或三秒不操作
        3.点击卡片
        4.在步骤3后点击back键
        Expected Result
        1.界面蒙层，同时唤醒小爱，文字气泡展示相应内容并进行语音播报且出现卡片
        2.卡片消失
        3.跳转至天气详情页内
        4.返回到对话记录页面

        '''
        Common(DUT).switch_card_window_focus(True)
        query = "今天天气"
        Common(DUT).execute_xa(query)
        time.sleep(10)
        result = []
        self.steps = {"cid": "C3383488", "feature": "功能测试", "action": "话记录-点击对话记录“今天天气”气泡"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="对话记录")
        Common(DUT).click_element(text=query)
        time.sleep(5)
        result.append(Checkpoint(DUT).checkIfExist(text="小米天气"))
        Common(DUT).click_element(text="小米天气")
        time.sleep(4)
        result.append(Checkpoint(DUT).compare_activity(target_act="com.miui.weather2"))  # 天气卡片
        Common(DUT).goBack()
        result.append(Checkpoint(DUT).checkIfExist(text="教教我"))  # 天气卡片
        Common(DUT).switch_card_window_focus(False)
        self.result = all(result)

    def test_manual_018(self):
        '''
         Steps
        1.点击小爱icon-个人中心-对话记录-点击对话记录“打开微信”气泡
        Expected Result\
        1.界面蒙层，同时唤醒小爱，文字气泡展示相应内容并进行语音播报且打开微信，执行完之后TTS回复：已打开。且不回到对话记录页面

        '''
        query = "打开相机"
        Common(DUT).execute_xa(query)
        time.sleep(10)
        result = []
        self.steps = {"cid": "C3383489", "feature": "功能测试", "action": "点击对话记录“打开微信”气泡"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="对话记录")
        Common(DUT).click_element(text=query)
        time.sleep(5)

        result.append(Checkpoint(DUT).compare_activity(target_act="camera"))  # 进入相机
        Common(DUT).goBack()
        result.append(Checkpoint(DUT).checkIfExist(text="教教我"))  # 天气卡片
        self.result = all(result)

    def test_manual_019(self):
        '''
          Steps

        1.点击小爱icon-个人中心-对话记录-点击对话记录“用微信发消息”气泡
        Expected Result

        1.界面蒙层，同时唤醒小爱，文字气泡展示相应内容并进行语音播报且打开微信执行多轮对话，完成之后，不会回到对话记录页面，对话记录页面显示为：记录多轮询问的query

        '''
        query = "用微信发消息"
        Common(DUT).execute_xa(query)
        time.sleep(10)
        result = []
        self.steps = {"cid": "C3383493", "feature": "功能测试", "action": "点击对话记录“用微信发消息”气泡"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="对话记录")
        Common(DUT).click_element(text=query)
        time.sleep(5)

        result.append(Checkpoint(DUT).check_to_speak("给谁呢"))  # 进入多轮
        query2 = "小爱"
        Common(DUT).execute_xa(query2)
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="对话记录")
        result.append(Checkpoint(DUT).checkIfExist(text=query2))

        self.result = all(result)

    #  query编辑
    def test_manual_020(self):
        '''
         Steps
        1.唤醒小爱录入query：今天天气
        2.点击query文字或文字末尾的编辑符号
        3.修改query为“明天天气”，点击【确定】
        Expected Result
        1.给出今天天气的TTS回复和对应卡片，TTS气泡第一行引号内展示录入的query“今天天气”，query文字末尾附有一个编辑的符号
        2.弹出query编辑页面，出现黑色蒙层，页面正中间文本框内显示query，文本框最右端为【确定】键，同时底部弹出输入法框
        3.该界面消失，自动录入query“明天天气”，并给出明天天气的TTS回复和对应卡片


        '''
        Common(DUT).switch_card_window_focus(True)
        query = "今天天气"
        Common(DUT).execute_xa(query)
        result = []
        self.steps = {"cid": "C3388567", "feature": "功能测试", "action": "既定query再次编辑 "}

        Common(DUT).click_element(id="com.miui.voiceassist:id/txv_query")
        result.append(Checkpoint(DUT).checkIfExist(text=query))
        query2 = "明天天气"
        Common(DUT).deleteText(query)
        Common(DUT).inputText(query2)
        result.append(Checkpoint(DUT).checkIfExist(text="确定"))
        Common(DUT).click_element(text="确定")
        time.sleep(5)

        result.append(Checkpoint(DUT).checkIfExist(text=query2))
        result.append(Checkpoint(DUT).checkIfExist(text="小米天气"))

        self.result = all(result)

    def test_manual_021(self):
        '''
         Steps

        1.唤醒小爱录入query：刘德华
        2.点击query文字或文字末尾的编辑符号
        3.删除文本框内所有内容
        4.点击【取消】键
        Expected Result

        1.给出刘德华的人物卡片和TTS回复，TTS气泡第一行引号内展示录入的query“刘德华”，query文字末尾附有一个编辑的符号
        2.弹出query编辑页面，出现黑色蒙层，页面正中间文本框内显示query，文本框最右端为【确定】键，同时底部弹出输入法框
        3.文本框最右端的【确定】键变为【取消】键
        4.该界面消失


        '''
        Common(DUT).switch_card_window_focus(True)
        query = "刘德华"
        Common(DUT).execute_xa(query)
        result = []
        self.steps = {"cid": "C3388568", "feature": "功能测试", "action": "清空query内容"}

        Common(DUT).click_element(id="com.miui.voiceassist:id/txv_query")
        result.append(Checkpoint(DUT).checkIfExist(text=query))
        Common(DUT).deleteText(query)
        result.append(Checkpoint(DUT).checkIfExist(text="取消"))
        Common(DUT).click_element(text="取消")
        time.sleep(5)

        result.append(Checkpoint(DUT).checkIfExist(text="人物"))

        self.result = all(result)

    def test_manual_022(self):
        '''
         Steps
        1.唤醒小爱录入query：1加1等于几
        2.点击query文字或文字末尾的编辑符号
        3.点击除文本框和输入法框外的其他区域
        4.在步骤2之后点击back键
        5.再次点击back键
        Expected Result
        1.TTS回复1加1的结果并给出对应卡片，TTS气泡第一行引号内展示录入的query“1加1等于几”，query文字末尾附有一个编辑的符号
        2.弹出query编辑页面，出现黑色蒙层，页面正中间文本框内显示query，文本框最右端为【确定】键，同时底部弹出输入法框
        3.该界面消失
        4.输入法框消失
        5.该界面消失

        '''
        Common(DUT).switch_card_window_focus(True)
        query = "1加1等于几"
        Common(DUT).execute_xa(query)
        result = []
        self.steps = {"cid": "C3388568", "feature": "功能测试", "action": "退出query编辑页面"}

        Common(DUT).click_element(id="com.miui.voiceassist:id/txv_query")
        result.append(Checkpoint(DUT).checkIfExist(text=query))
        Common(DUT).deleteText(query)
        result.append(Checkpoint(DUT).checkIfExist(text="取消"))
        Common(DUT).click_element(text="取消")
        time.sleep(5)

        result.append(Checkpoint(DUT).checkIfExist(text="计算器"))

        self.result = all(result)

    # 个人信息页
    def test_manual_030(self):
        '''
         Steps
        进入小爱APP，点击个人中心-用户名
        Expected Result

        页面跳转至个人信息页详情页
        '''
        result = []
        self.steps = {"cid": "C3389513", "feature": "功能测试", "action": "个人信息页-查看用户名的详情页"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="2201966894")  # 测试机小米账号
        time.sleep(2)
        result.append(Checkpoint(DUT).checkIfExist(text="个人信息"))
        result.append(Checkpoint(DUT).checkIfExist(text="基础资料", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(text="返回", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(text="头像", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(text="名字", refresh=False))

        self.result = all(result)

    def test_manual_031(self):
        '''
         Steps
        进入小爱APP，点击个人中心-个人资料
        Expected Result
        页面跳转至个人的资料详情页，左上角返回按钮，下方是小字文案“以上信息将用于用户导航到家/公司，查询限号和快递等”，依次是家、公司、出行偏好、车辆信息、手机号
        '''
        result = []
        self.steps = {"cid": "C3389514", "feature": "功能测试", "action": "个人中心-个人资料"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="个人资料")
        time.sleep(5)
        result.append(Checkpoint(DUT).checkIfExist(text="个人资料"))
        result.append(Checkpoint(DUT).checkIfExist(text="以上信息将用于用户导航到家/公司，查询限号和快递等", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(text="返回", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(text="家", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(text="公司", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(text="出行偏好", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(text="车辆信息", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(text="手机号码", refresh=False))

        self.result = all(result)

    def test_manual_032(self):
        '''
         Steps
        进入小爱APP，点击个人中心-个人资料-点击家
        Expected Result
        页面跳转至家的详情页，有定位当前的城市的下拉框（如北京市），搜索框（框内置灰字体小区/写字楼/学校等）、输入东城区，出现相似的地点（如选择东城区），页面会返回个人资料的详情页且信息同步
        '''
        result = []
        self.steps = {"cid": "C3389515", "feature": "功能测试", "action": "个人中心-个人资料-点击家"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="个人资料")
        time.sleep(5)
        Common(DUT).click_element(text="家")
        result.append(Checkpoint(DUT).checkIfExist(text="小区/写字楼/学校"))
        result.append(Checkpoint(DUT).checkIfExist(text="返回", refresh=False))
        Common(DUT).inputText("keliyuan")
        result.append(Checkpoint(DUT).checkIfExist(text="科利源大厦"))

        self.result = all(result)

    def test_manual_033(self):
        '''
         Steps

        进入小爱APP，点击个人中心-个人资料-点击公司
        Expected Result

        页面跳转至家的详情页，有定位当前的城市的下拉框（如北京市），搜索框（框内置灰字体小区/写字楼/学校等）、输入科利源大厦，出现相似的地点（如选择科利源大厦），页面会返回个人资料的详情页且信息同步

        '''
        result = []
        self.steps = {"cid": "C3389516", "feature": "功能测试", "action": "个人中心-个人资料-点击公司"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="个人资料")
        time.sleep(5)
        Common(DUT).click_element(text="公司")
        result.append(Checkpoint(DUT).checkIfExist(text="小区/写字楼/学校"))
        result.append(Checkpoint(DUT).checkIfExist(text="返回", refresh=False))
        Common(DUT).inputText("keliyuan")
        result.append(Checkpoint(DUT).checkIfExist(text="科利源大厦"))

        self.result = all(result)

    def test_manual_034(self):
        '''
         Steps
        进入小爱APP，点击个人中心-个人资料-点击出行偏好
        Expected Result
        弹出“设置出行偏好”卡片，依次为公交、驾车（默认驾车）、骑行、步行，如选择公交（可自定义），页面返回上一页面信息同步
        '''
        result = []
        self.steps = {"cid": "C3389517", "feature": "功能测试", "action": "个人中心-个人资料-点击出行偏好"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="个人资料")
        time.sleep(5)
        Common(DUT).click_element(text="出行偏好")
        result.append(Checkpoint(DUT).checkIfExist(text="设置出行偏好"))
        result.append(Checkpoint(DUT).checkIfExist(text="公交", refresh=False))
        Common(DUT).click_element(text="公交")
        Common(DUT).click_element(text="出行偏好")
        Common(DUT).click_element(text="驾车")
        result.append(Checkpoint(DUT).checkIfExist(text="个人资料"))
        result.append(Checkpoint(DUT).checkIfExist(text="驾车"))

        self.result = all(result)

    def test_manual_035(self):
        '''
         Steps
        1.进入小爱APP，点击个人中心-个人资料-点击车辆信息
        2.在步骤1后点击车牌号
        3.在步骤2后输入a.正确车牌号点击确定/取消 b.错误车牌号点击确定/取消
        4.在步骤2后点击车辆名称
        5.在4步骤后输入小王同学的宝马（可自定义），点击确定
        Expected Result
        1.跳转至修改车辆信息页面，左上角是返回按钮，下方依次是新能源汽车按钮（默认是关着状态）、车牌号、车辆名称
        2.弹出“设置车牌号码”的卡片，默认京，下方有取消和确定的按钮（确定按钮暗色显示）
        3.a.返回上一页面，信息同步/卡片消失 b.红色文字标示:请输入正确的车牌号码/卡片消失
        4.弹出“设置车辆名称”的卡片，有输入框，取消按钮和确定按钮（输入框内没有文字，确定按钮置灰，输入文字，确定按钮方可选择），车辆名称最多30个字符，超出写更多字则打不上去字
        5.返回上一页面，信息同步
        '''
        result = []
        self.steps = {"cid": "C3389523", "feature": "功能测试", "action": "个人中心-个人资料-点击车辆信息"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="个人资料")
        time.sleep(5)
        Common(DUT).click_element(text="车辆信息")
        result.append(Checkpoint(DUT).checkIfExist(text="修改车辆信息"))
        Common(DUT).click_element(text="车牌号")
        result.append(Checkpoint(DUT).checkIfExist(text="设置车牌号"))
        Common(DUT).click_element(text="取消")
        result.append(Checkpoint(DUT).checkIfExist(text="修改车辆信息"))

        self.result = all(result)

    def test_manual_036(self):
        '''
         Steps
        1.进入小爱APP，点击个人中心-个人资料-点击手机号码
        2.在步骤1后a.输入正确的号码点击确定/取消 b.输入错误的手机号点击确定/取消
        Expected Result
        1.弹出“请输入手机号码”的卡片，输入框，取消和确定按钮（输入框内没有数字，确定按钮置灰，输入数字，确定按钮方可选择）
        2.a.返回上一页面，信息同步/卡片消失 b.toast:请输入正确的手机号码/卡片消失
        '''
        result = []
        self.steps = {"cid": "C3389518", "feature": "功能测试", "action": "个人中心-个人资料-点击手机号码"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="个人资料")
        time.sleep(5)
        Common(DUT).click_element(text="手机号码")
        result.append(Checkpoint(DUT).checkIfExist(text="授权手机号"))
        Common(DUT).click_element(text="取消")
        result.append(Checkpoint(DUT).checkIfExist(text="个人资料"))

        self.result = all(result)

    # 3.5.0
    def test_manual_040(self):
        '''
         Steps
        1.点击进入小爱同学→设置→默认音乐播放源
        2.点击QQ音乐
        3.query：我想听音乐
        Expected Result
        1.选择音乐播放源下有QQ音乐这项选择
        2.可以成功选择QQ音乐作为播放源
        3.可以播放音乐，并且音乐资源来自QQ音乐
        '''
        result = []
        self.steps = {"cid": "C3389518", "feature": "功能测试", "action": "选泽QQ音乐作为播放源 "}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_setting()
        Common(DUT).click_element(text="默认音乐播放源")
        Common(DUT).click_element(text="QQ音乐")
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).execute_xa("我想听音乐")
        time.sleep(5)
        result.append(Checkpoint(DUT).checkIfExist(text="QQ音乐"))
        Common(DUT).killXA()
        result.append(Checkpoint(DUT).compare_activity(target_act=CONST.APP["QQ音乐"]))

        self.result = all(result)

    def test_manual_041(self):
        '''
         Steps
        1.点击进入小爱同学→设置→默认音乐播放源
        2.点击QQ音乐
        3.query：我想听音乐
        Expected Result
        1.选择音乐播放源下有QQ音乐这项选择
        2.可以成功选择QQ音乐作为播放源
        3.可以播放音乐，并且音乐资源来自QQ音乐
        '''
        result = []
        self.steps = {"cid": "C3467851|C3467856", "feature": "功能测试", "action": "选泽QQ音乐作为播放源 "}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_setting()
        Common(DUT).click_element(text="默认音乐播放源")
        Common(DUT).click_element(text="QQ音乐")
        Common(DUT).switch_card_window_focus(True)
        Common(DUT).execute_xa("我想听音乐")
        time.sleep(5)
        result.append(Checkpoint(DUT).checkIfExist(text="QQ音乐"))
        Common(DUT).killXA()
        result.append(Checkpoint(DUT).compare_activity(target_act=CONST.APP["QQ音乐"]))

        '''
        Steps
       1.设置小米音乐为默认播放源，录入query：我想听音乐，待音乐播放后录入query：收藏音乐
       2.query：取消收藏
       3.设置QQ音乐为默认播放源，录入query：我想听音乐，待音乐播放后录入query：收藏音乐
       4.query：取消收藏
       Expected Result
       1、3.可以成功收藏这首歌
       2、4.可以成功取消收藏这首歌

       '''
        Common(DUT).execute_xa("收藏音乐")
        time.sleep(3)
        result.append(Checkpoint(DUT).check_to_speak("收藏成功"))
        time.sleep(3)
        Common(DUT).execute_xa("取消收藏")
        result.append(Checkpoint(DUT).check_to_speak("取消收藏成功"))

        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_setting()
        Common(DUT).click_element(text="默认音乐播放源")
        time.sleep(2)
        Common(DUT).click_element(text="小米音乐")
        Common(DUT).execute_xa("我想听音乐")
        time.sleep(8)
        Common(DUT).execute_xa("收藏音乐")
        time.sleep(3)
        result.append(Checkpoint(DUT).check_to_speak("收藏成功"))
        time.sleep(3)
        Common(DUT).execute_xa("取消收藏")
        result.append(Checkpoint(DUT).check_to_speak("取消收藏成功"))

        self.result = all(result)

    def test_manual_042(self):
        '''
         Steps
        1.小爱APP-个人中心-我的训练
        Expected Result
        上方展示的是示例推荐，下方是自己创建的训练计划（若推荐示例query与用户训练query冲突，则不展示）

         Steps
        1.小爱APP-个人中心-我的训练
        2.存在示例“早上好”-点击竖三点
        Expected Result
        1.卡片的左角是蓝色字体“示例”，右上角是竖三点，与你可以说，左下角是小爱的回应，右下角是“+添加使用”
        2.弹出卡片，编辑与删除按钮，各自前对应各自的图标
        '''
        result = []
        self.steps = {"cid": "C3472007|C3472009|C3472013", "feature": "功能测试", "action": "个人中心-我的训练"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="我的训练")
        result.append(Checkpoint(DUT).checkIfExist(text="示例"))
        result.append(Checkpoint(DUT).checkIfExist(text="你可以说", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(text="小爱的回应", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(text="添加使用", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(id="com.miui.voiceassist:id/more_iv", refresh=False))
        Common(DUT).click_element(id="com.miui.voiceassist:id/more_iv")
        result.append(Checkpoint(DUT).checkIfExist(text="编辑"))
        result.append(Checkpoint(DUT).checkIfExist(text="删除", refresh=False))

        Common(DUT).click_element(text="删除")
        result.append(Checkpoint(DUT).checkIfExist(text="确定要删除该示例吗"))
        Common(DUT).click_element(text="取消")
        Common(DUT).click_element(id="com.miui.voiceassist:id/more_iv")
        Common(DUT).click_element(text="编辑")
        result.append(Checkpoint(DUT).checkIfExist(text="新建训练"))
        result.append(Checkpoint(DUT).checkIfExist(text="完成", refresh=False))
        result.append(Checkpoint(DUT).checkIfExist(text="再添加一种说法", refresh=False))
        Common(DUT).goBack()
        result.append(Checkpoint(DUT).checkIfExist(text="确认放弃编辑吗"))
        Common(DUT).click_element(text="确认")

        self.result = all(result)

    # 3.6.0
    def test_manual_050(self):
        '''
         Steps
        1.点击技能卡片上的“共享”按钮
        2.点击“取消”
        3.点击“确认”
        Expected Result
        1.弹出卡片，卡片左下角为“取消”，右下角为“确认”
        2.卡片消失
        3.弹出toast提示“分享成功”，并且技能卡片左下侧为黄色“审核中”字样

        '''
        result = []
        self.steps = {"cid": "C3507691", "feature": "功能测试", "action": "我的训练-审核中"}
        Common(DUT).goBackHome()
        Common(DUT).open_xiaoai_main()
        Common(DUT).click_element(content="个人中心")
        Common(DUT).click_element(text="我的训练")
        x, y = Common(DUT).getScreenSize()
        start_x, start_y, stop_x, stop_y = 0.5, 0.7, 0.5, 0.4
        Common(DUT).swipe(float(start_x) * x, float(start_y) * y, float(stop_x) * x, float(stop_y) * y)
        # result.append(Checkpoint(DUT).checkIfExist(text="共享"))
        # Common(DUT).click_element(text="共享")
        # result.append(Checkpoint(DUT).checkIfExist(text="是否共享此技能给小爱同学"))
        # result.append(Checkpoint(DUT).checkIfExist(text="确认", refresh=False))
        # result.append(Checkpoint(DUT).checkIfExist(text="取消", refresh=False))
        Common(DUT).click_element(text="确认")
        time.sleep(3)
        result.append(Checkpoint(DUT).checkIfExist(text="审核中|审核通过|审核不通过|共享"))

        self.result = all(result)



    def tearDown(self):
        super(TestScript, self).tearDown()
        Common(DUT).clearRecentApp()



if __name__ == "__main__":
    unittest.main()