from test import *
import os
import json
import unittest


class TestScript(BaseTestCase):

    def test_hotqueries_reload_01(self):
        # clear cache -> 启动小爱 -> 检察文件resource_dynamic_list被下载 -> 重启动小爱 -> 所有resource_dynamic_list文件中配置的文件都会被下载,检察hot_query_josn_v2是否存在 -> 重启动小爱 -> hot_query_json_v2文件被使用
        Common(DUT).open_xiaoai_debug_on()
        self.steps = {"feature": "离线文件热更新", "action": "离线文件热更新",  "query": ["[离线文件热更新验证]"],
                      "wait_time": [2]}

        results = []
        Common(DUT).clearUserData("com.miui.voiceassist")
        time.sleep(3)
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        Common(DUT).click_element(text="同意并继续")
        time.sleep(5)
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        time.sleep(5)
        res = Common(DUT).shell("cat /data/data/com.miui.voiceassist/app_resource_updated/resource_dynamic_list")[0].decode("utf-8")
        print(res)
        if res == "":
            print("Fail | resource_dynamic_list 文件下载失败")
            results.append(False)
        else:
            print("Pass | resource_dynamic_list 文件下载失成功")
            results.append(True)
        # 重启动小爱 -> 所有resource_dynamic_list文件中配置的文件都会被下载,检察hot_query_josn_v2是否存在
        Common(DUT).killXA()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        time.sleep(60)

        # 重启动小爱 -> hot_query_json_v2文件被使用
        Common(DUT).shell("rm /sdcard/hot_query_file_used.txt")
        Common(DUT).killXA()
        Common(DUT).startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        time.sleep(5)
        res1 = Common(DUT).shell("cat /sdcard/hot_query_file_used.txt")[0].decode("utf-8")
        if res1 == "":
            print("Fail | hot_query_json_v2文件未被使用")
            results.append(False)
        else:
            print("Pass | hot_query_json_v2文件被使用：" + res1)
            results.append(True)

        self.result = all(results)


if __name__ == "__main__":
    unittest.main()
