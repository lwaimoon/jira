#!/usr/bin/env python
# -*- coding:utf-8 -*-
from aw import *
from alarm_utils import FalconCli
from test import *


class TestScript(BaseCase):

    def setUp(self):
        super(TestScript, self).setUp()
        with open(os.path.join(os.path.dirname(__file__), "testcase.json"), "r", encoding="utf-8") as f:
            self.test_cases = json.load(f)
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        self.app_name = "QQ"

    def test_step(self):
        self.app_ver = Common(DUT).getAppVersionName(CONST.APP[self.app_name]) if CONST.APP.get(self.app_name, "default") != "default" else "default"

        for test_case in self.test_cases:
            print("---------------------------------------------------------------")
            result_1 = result_2 = result_3 = result_4 = result_5 = True
            if len(test_case["query"]) == 1:
                self.single_query_num += 1
            else:
                self.multiple_query_num += 1
            retry_time = 3
            while retry_time:
                for i in range(len(test_case["query"])):
                    query = test_case["query"][i]
                    Common(DUT).execute_xa(query)
                    try:
                        time.sleep(test_case["wait_time"][i])
                    except Exception as e:
                        time.sleep(test_case["wait_time"]+(4-retry_time))

                if test_case["check_point"]["text"]:
                    result_1 = Checkpoint(DUT).checkIfExist("检测点:" + str(test_case["query"]),
                                                            text=test_case["check_point"]["text"])
                if test_case["check_point"]["resource-id"]:
                    result_2 = Checkpoint(DUT).checkIfExist("检测点:" + str(test_case["query"]),
                                                            resourceId=test_case["check_point"]["resource-id"])
                if test_case["check_point"]["activity"]:
                    result_3 = Checkpoint(DUT).compare_activity("检测点:" + str(test_case["query"]),
                                                                target_act=test_case["check_point"]["activity"])
                if test_case["check_point"]["nd"]:
                    result_4 = Checkpoint(DUT).checkIfNotExist("检测点:" + str(test_case["query"]),
                                                               text=test_case["check_point"]["nd"])

                result = result_1 and result_2 and result_3 and result_4 and result_5
                if result:
                    Common(DUT).goBackHome()
                    break
                else:
                    Common(DUT).clearRecentApp()
                    retry_time = retry_time - 1
            else:
                tag = "domain=smartApp,app=" + self.app_name + "_" + self.app_ver + ",device=" + self.dev_name + ",query=" + str(test_case["query"]) + ",result=Failed"
                FalconCli().send_alarm(tag)  # 重试三次后发布报警
                Checkpoint(DUT).catchLog()
            result_detail = {
                True: ["Pass", ""],
                False: ["Fail", ""],
                None: ["None", "待确认"]
            }
            
            param_dic = {
                "NodeId": self.NodeId, "domain": test_case.get("domain", self.domain),
                "feature": test_case.get("feature", self.app_name),
                "third_app": self.app_name,
                "app_version": self.app_ver,
                "query": test_case["query"],
                "action": test_case.get("action", "default"),
                "setup": test_case.get("setup", "任意界面"),
                "result": result_detail[result][0],
                "message": result_detail[result][1]
            }
            Common(DUT).post_result(param_dic)  # post测试结果到服务器
            self.test_result.append(result)


if __name__ == "__main__":
    unittest.main()
