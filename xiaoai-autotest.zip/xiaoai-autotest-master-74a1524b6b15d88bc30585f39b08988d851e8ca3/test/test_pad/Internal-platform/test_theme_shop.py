from test import *



class TestScript(BaseTestCase):
    @parameterized.expand([
        ("theme_main_page", {"feature": "主题商店", "query": ["我想换主题"], "wait_time": [2]},
         {"text": "主题", "activity": "com.android.thememanager/.ThemeResourceTabActivity"}),
        ("font", {"feature": "主题商店", "query": ["个性字体"], "wait_time": [2]},
         {"text": "字体", "activity": "com.android.thememanager/.ThemeResourceTabActivity"}),
        ("ring_bell", {"feature": "主题商店", "query": ["换个铃声"], "wait_time": [2]},
         {"text": "铃声", "activity": "com.android.thememanager/.ThemeResourceTabActivity"}),
        ("theme_range", {"feature": "主题商店", "query": ["打开主题排行榜"], "wait_time": [2]},
         {"text": "排行", "activity": "com.android.thememanager/.activity.ThemeTabActivity"}),
        ("wall_paper", {"feature": "主题商店", "query": ["换张壁纸"], "wait_time": [2]},
         {"text": "壁纸", "activity": "com.android.thememanager/.ThemeResourceTabActivity"})
    ])
    def test_theme_shop(self, name, steps, check_point):
        '''
        Suite Name: Theme Shop
        URL: http://intervention.pt.ai.xiaomi.com/skill/46
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT),
                                                       retry_time)
            self.result = common_result
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))


if __name__ == "__main__":
    unittest.main()
