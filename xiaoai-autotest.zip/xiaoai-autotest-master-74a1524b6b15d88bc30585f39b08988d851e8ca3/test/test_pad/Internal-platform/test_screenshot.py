from test import *

import re

p = re.compile(r'Screenshot_.*\.png')


class TestScript(BaseTestCase):
    @parameterized.expand([
        ("charge", {"feature": "截屏", "query": ["截屏"], "wait_time": [10]},
         {})
    ])
    def test_screenshot(self, name, steps, check_point):
        '''
        Suite Name: Screen Shot
        URL: http://intervention.pt.ai.xiaomi.com/skill/73
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]

        while retry_time:
            res1 = Common(DUT).shell("ls /storage/emulated/0/DCIM/Screenshots")[0]
            num_1 = len(p.findall(res1.decode("utf8")))
            time.sleep(2)
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT), retry_time)
            res2 = Common(DUT).shell("ls /storage/emulated/0/DCIM/Screenshots")[0]
            num_2 = len(p.findall(res2.decode("utf8")))
            self.result = common_result and (num_2 - num_1) == 1

            print("after {}\tres: {}, \nbefore {}\tres: {}".format(num_2, res2, num_1, res1))
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))


if __name__ == "__main__":
    unittest.main()
