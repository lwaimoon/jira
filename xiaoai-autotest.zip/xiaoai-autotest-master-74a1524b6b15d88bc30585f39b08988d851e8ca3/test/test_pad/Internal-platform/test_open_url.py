from test import *



class TestScript(BaseTestCase):
    @parameterized.expand([
        ("enter_mi_com", {"feature": "小米网", "query": ["进入小米网"], "wait_time": [3]},
         {"activity": "com.android.browser/.BrowserActivity"})
    ])
    def test_open_url(self, name, steps, check_point):
        '''
        Suite Name: Open URL
        URL: http://intervention.pt.ai.xiaomi.com/skill/82
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT), retry_time)
            self.result = common_result
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))


if __name__ == "__main__":
    unittest.main()
