from test import *



class TestScript(BaseTestCase):
    @parameterized.expand([
        ("lock_screen", {"query": ["关闭屏幕"], "wait_time": [3]},
         {"locked": "true"}),
        ("mi_home_auth", {"query": ["米家授权"], "wait_time": [3]},
         {"text": "米家设备授权管理", "activity": "com.miui.mihome/.AuthSettingPreferences"}),
        ("miui_home", {"query": ["米家授权", "返回桌面"], "wait_time": [3, 3]},
         {"activity": "com.miui.home/.launcher.Launcher"}),
        # ("dialer", {"query": ["打开通话记录"], "wait_time": [3]},
        #  {"text": "通话", "activity": "com.android.contacts/.activities.TwelveKeyDialer"})
    ])
    def test_voice_assist(self, name, steps, check_point):
        '''
        Suite Name: Voice Assist
        URL: http://intervention.pt.ai.xiaomi.com/skill/55
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT), retry_time)
            self.result = common_result
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))


if __name__ == "__main__":
    unittest.main()
