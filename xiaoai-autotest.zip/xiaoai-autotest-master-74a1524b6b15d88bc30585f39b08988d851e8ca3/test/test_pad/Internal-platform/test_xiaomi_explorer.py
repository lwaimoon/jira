from test import *



class TestScript(BaseTestCase):
    @parameterized.expand([
        ("mother_day", {"query": ["让妈妈体验品质生活"], "wait_time": [8]},
         {"activity": "com.xiaomi.youpin/com.xiaomi.miot.store.ui.MiotStoreMainActivity"}),
        ("big_data", {"query": ["小爱大数据"], "wait_time": [3]},
         {"text": "小爱同学", "activity": "com.android.browser/.BrowserActivity"}),
        ("create_train_plan", {"query": ["创建训练计划", {"text": "登录"}], "wait_time": [3, 3]},
         {"text": "创建训练", "activity": "com.android.browser/.BrowserActivity"}),
        # ("xiaoai_weibo", {"query": ["小爱同学官方微博"], "wait_time": [3]},
        #  {"activity": "com.android.browser/.BrowserActivity"})
    ])
    def test_xiaomi_explorer(self, name, steps, check_point):
        '''
        Suite Name: Xiaomi Explorer
        URL: http://intervention.pt.ai.xiaomi.com/skill/69
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT), retry_time)
            self.result = common_result
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))


if __name__ == "__main__":
    unittest.main()
