from test import *
from aw import *


class TestScript(BaseTestCase):
    @parameterized.expand([
         ['xiaomi_shop', {'query': ['我的小米订单'], 'wait_time': [5]},
          {'activity': 'com.xiaomi.shop/com.xiaomi.shop2.plugin.PluginRootActivity', 'text': '我的订单'}],
        ['xiaomi_shop', {'domain': 'shopping', 'query': ['我的订单到哪了'], 'wait_time': [5]},
         {'to_speak': '小米商城'}],
        ['xiaomi_shop', {'query': ['小米手机'], 'wait_time': [5]},
         {'activity': 'com.xiaomi.padshop/com.xiaomi.shop2.plugin.PluginRootActivity', 'text': '小米手机'}],
        ['xiaomi_shop', {'domain': 'shopping', 'query': ['小米八多少钱'], 'wait_time': [5]},
         {'to_speak': '查到小米8'}]
    ])
    def test_xiaomi_shop(self, name, steps, check_point):
        '''
        Suite Name: Xiaomi Shop
        URL: http://intervention.pt.ai.xiaomi.com/skill/44
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT), retry_time)
            self.result = common_result
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))


if __name__ == "__main__":
    unittest.main()
