from test import *



class TestScript(BaseTestCase):
    @parameterized.expand([
        ("hot_music", {"feature": "小米音乐", "query": ["给我放下最热的歌"], "wait_time": [3]},
         {"activity": "com.miui.player/.ui.MusicBrowserActivity"})
    ])
    def test_xiaomi_music(self, name, steps, check_point):
        '''
        Suite Name: Xiaomi Music热
        URL: http://intervention.pt.ai.xiaomi.com/skill/67
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT), retry_time)
            self.result = common_result
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))


if __name__ == "__main__":
    unittest.main()
