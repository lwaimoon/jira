from test import *


class TestScript(BaseTestCase):
    @parameterized.expand([
        ("keyboard", {"feature": "系统设置", "query": ["小爱打开实体键盘"], "wait_time": [3]},
         {"text": "实体键盘", "activity": "com.android.settings/.Settings$PhysicalKeyboardActivity"}),
        ("correct_color", {"feature": "系统设置", "query": ["小爱打开色彩校正"], "wait_time": [3]},
         {"text": "色彩校正", "activity": "com.android.settings/.Settings$AccessibilityDaltonizerSettingsActivity"}),
        ("vpn", {"feature": "系统设置", "query": ["我想打开VPN"], "wait_time": [3]},
         {"activity": "com.android.settings/.Settings$VpnSettingsActivity"}),
        ("setting", {"feature": "系统设置", "query": ["打开设置"], "wait_time": [5]},
         {"text": "设置", "activity": "com.android.settings/.MainSettings"}),
        # BUG MIUI-1287956
        ("battery_record", {"feature": "系统设置", "query": ["小爱打开电量使用记录"], "wait_time": [5]},
         {"text": "耗电排行", "activity": "com.miui.securitycenter/com.miui.powercenter.legacypowerrank.PowerConsumeRank"}),
        ("wireless_setting", {"feature": "系统设置", "query": ["小爱打开更多连接方式"], "wait_time": [3]},
         {"text": "连接方式", "activity": "com.android.settings/.Settings$WirelessSettingsActivity"}),
        ("WLAN", {"feature": "系统设置", "query": ["小爱打开WIFI列表"], "wait_time": [3]},
         {"text": "WLAN", "activity": "com.android.settings/.Settings$WifiSettingsActivity"}),
        ("WLAN_setting", {"feature": "系统设置", "query": ["小爱同学打开WIFI高级设置"], "wait_time": [3]},
         {"text": "WLAN", "activity": ""}),
        ("APN_setting", {"feature": "系统设置", "query": ["小爱打开APN"], "wait_time": [3]},
         {"text": "APN", "activity": "com.android.settings/.Settings$ApnSettingsActivity"}),
        ("blue_tooth", {"feature": "系统设置", "query": ["小爱打开蓝牙设置"], "wait_time": [3]},
         {"text": "蓝牙", "activity": " com.android.settings/.Settings$BluetoothSettingsActivity"}),
        ("date_time", {"feature": "系统设置", "query": ["小爱打开日期和时间设置"], "wait_time": [3]},
         {"text": "日期和时间", "activity": "com.android.settings/.Settings$DateTimeSettingsActivity"}),
        ("language", {"feature": "系统设置", "query": ["小爱修改语言"], "wait_time": [3]},
         {"text": "语言", "activity": "com.android.settings/.Settings$LocalePickerActivity"}),
        ("add_keyboard", {"feature": "系统设置", "query": ["小爱添加输入法"], "wait_time": [3]},
         {"text": "输入法"}),
        ("display_settings", {"feature": "系统设置", "query": ["小爱打开显示"], "wait_time": [3]},
         {"text": "显示", "activity": "com.android.settings/.Settings$DisplaySettingsActivity"}),
        ("open_source", {"feature": "系统设置", "query": ["小爱打开开源代码许可"], "wait_time": [5]},
         {"text": "开放源代码许可", "activity": "com.android.htmlviewer/com.android.settings.SettingsLicenseActivity"}),
        ("security_setting", {"feature": "系统设置", "query": ["小爱打开系统安全"], "wait_time": [3]},
         {"text": "安全"}),
        ("location_setting", {"feature": "系统设置", "query": ["小爱打开位置设置"], "wait_time": [3]},
         {"text": "位置信息", "activity": "com.android.settings/.Settings$LocationSettingsActivity"}),
        ("app_manager", {"feature": "系统设置", "query": ["小爱打开更多应用"], "wait_time": [3]},
         {"text": "应用管理|更多应用", "activity": "com.miui.securitycenter/com.miui.appmanager.AppManagerMainActivity"}),
        ("accessibility_setting", {"feature": "系统设置", "query": ["小爱打开无障碍设置"], "wait_time": [3]},
         {"text": "无障碍", "activity": "com.android.settings/.Settings$AccessibilitySettingsActivity"}),
        ("caption_setting", {"feature": "系统设置", "query": ["小爱打开字幕设置"], "wait_time": [3]},
         {"text": "字幕", "activity": "com.android.settings/.Settings$CaptioningSettingsActivity"}),
        ("print", {"feature": "系统设置", "query": ["小爱我要打印"], "wait_time": [3]},
         {"text": "打印", "activity": "com.android.settings/.Settings$PrintSettingsActivity"}),
        ("sync", {"feature": "系统设置", "query": ["小爱打开同步"], "wait_time": [3]},
         {"text": "同步", "activity": ""}),
        ("development_setting", {"feature": "系统设置", "query": ["小爱打开开发者选项"], "wait_time": [3]},
         {"text": "开启开发者选项"}),
        ("unlock", {"feature": "系统设置", "query": ["小爱设置指纹"], "wait_time": [3]},
         {"text": "解锁|锁屏密码", "activity": "com.android.settings"}),
        ("sub_settings", {"feature": "系统设置", "query": ["小爱打开存储空间"], "wait_time": [3]},
         {"text": "存储空间", "activity": "com.android.settings/.SubSettings"}),
        ("miracast_settings", {"feature": "系统设置", "query": ["小爱打开无线显示"], "wait_time": [3]},
         {"text": "无线显示", "activity": "com.android.settings/.Settings$MiracastSettingsActivity"}),
        ("add_account", {"feature": "系统设置", "query": ["小爱打开同步添加"], "wait_time": [3]},
         {"text": "添加", "activity": "com.android.settings/.accounts.ChooseAccountActivity"}),
        ("user_setting", {"feature": "系统设置", "query": ["小爱打开用户设置"], "wait_time": [3]},
         {"text": "用户", "activity": "com.android.settings/.Settings$UserSettingsActivity"}),
        ("sound_setting", {"feature": "系统设置", "query": ["小爱打开声音和振动"], "wait_time": [3]},
         {"text": "声音", "activity": "com.android.settings/.Settings$SoundSettingsActivity"}),
        ("backup", {"feature": "系统设置", "query": ["小爱打开备份和重置"], "wait_time": [3]},
         {"text": "备份", "activity": "com.android.settings/.Settings$PrivacySettingsActivity"}),
        ("default_setting", {"feature": "系统设置", "query": ["小爱打开默认应用设置"], "wait_time": [3]},
         {"text": "默认应用设置", "activity": "com.android.settings/.applications.PreferredListSettings"}),
        ("not_disturb", {"feature": "系统设置", "query": ["小爱打开防打扰"], "wait_time": [3]},
         {"text": "防打扰", "activity": "com.android.settings/.dndmode.DoNotDisturbModeActivity"}),
        ("screen_paper", {"feature": "系统设置", "query": ["小爱打开护眼模式"], "wait_time": [3]},
         {"text": "护眼模式", "activity": "com.android.settings/.display.ScreenPaperModeActivity"}),
        ("xiaoai_setting", {"feature": "系统设置", "query": ["怎么设置小爱同学"], "wait_time": [3]},
         {"activity": "com.miui.voiceassist/com.xiaomi.voiceassistant.MiuiVoiceSettingActivity"})
    ])
    def test_miui_setting(self, name, steps, check_point):
        '''
        Suite Name: MIUI Setting
        URL: http://intervention.pt.ai.xiaomi.com/skill/76
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT),
                                                       retry_time)
            self.result = common_result
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))


if __name__ == "__main__":
    unittest.main()
