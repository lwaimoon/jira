from test import *

from aw import *


# TODO
class TestScript(BaseTestCase):
    '''
    Suite Name: Question Answer
    URL: http://intervention.pt.ai.xiaomi.com/skill/52
    '''
    @parameterized.expand([
    ])
    def test_question_answer(self):
        pass


if __name__ == "__main__":
    unittest.main()
