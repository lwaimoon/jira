from test import *

import re

p = re.compile(r'Screenrecorder.*\.mp4')


class TestScript(BaseTestCase):
    @parameterized.expand([
        ("charge", {"feature": "录制屏幕", "query": ["开始录屏", "停止录屏"], "wait_time": [10, 2]},
         {})
    ])
    def test_record_screen(self, name, steps, check_point):
        '''
        Suite Name: Record Screen
        URL: http://intervention.pt.ai.xiaomi.com/skill/75
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]

        while retry_time:
            res1 = Common(DUT).shell("ls /storage/emulated/0/DCIM/ScreenRecorder")[0]
            num_1 = len(p.findall(res1.decode("utf8")))
            time.sleep(2)
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT), retry_time)
            res2 = Common(DUT).shell("ls /storage/emulated/0/DCIM/ScreenRecorder")[0]
            num_2 = len(p.findall(res2.decode("utf8")))
            self.result = common_result and (num_2 - num_1) == 1
            time.sleep(2)
            print("after {}\tres: {}, \nbefore {}\tres: {}".format(num_2, res2, num_1, res1))
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))


if __name__ == "__main__":
    unittest.main()
