from test import *



class TestScript(BaseTestCase):
    @parameterized.expand([
        # ("trash_clean", {"feature": "垃圾清理", "query": ["打开垃圾清理"], "wait_time": [10]},
        #  {"text": "垃圾清理", "activity": "com.miui.cleanmaster/com.miui.optimizecenter.MainActivity"}),
        # ("trash_clean_2", {"feature": "垃圾清理", "query": ["清一下垃圾"], "wait_time": [10]},
        #  {"text": "垃圾清理", "activity": "com.miui.cleanmaster/com.miui.optimizecenter.MainActivity"}),
        # ("trash_deep_clean", {"feature": "垃圾清理", "query": ["手机瘦身"], "wait_time": [10]},
        #  {"text": "手机瘦身", "activity": "com.miui.cleanmaster/com.miui.optimizecenter.deepclean.DeepCleanActivity"}),
        # ("wechat_clean", {"feature": "垃圾清理", "query": ["微信专清"], "wait_time": [10]},
        #  {"text": "微信专清", "activity": "com.miui.cleanmaster/com.miui.optimizecenter.deepclean.tencent.WeChatQQCleanActivity"}),
        # ("qq_clean", {"feature": "垃圾清理", "query": ["清理QQ垃圾"], "wait_time": [10]},
        #  {"text": "QQ专清", "activity": "com.miui.cleanmaster/com.miui.optimizecenter.deepclean.tencent.WeChatQQCleanActivity"})
    ])
    def test_trash_clean(self, name, steps, check_point):
        '''
        Suite Name: Trash Clean
        URL: http://intervention.pt.ai.xiaomi.com/skill/45
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT),
                                                       retry_time)
            self.result = common_result
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))


if __name__ == "__main__":
    unittest.main()
