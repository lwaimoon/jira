from test import *

from aw import *


class TestScript(BaseTestCase):
    @parameterized.expand([
        # ("stop_recorder", {"query": ["停止录音"], "wait_time": [3]},
        #  {"text": "完成", "activity": "com.android.soundrecorder/.SoundRecorder"}),
        ("start_recorder", {"feature": "录音", "query": ["开始录音"], "wait_time": [7]},
         {"activity": "com.android.soundrecorder/.SoundRecorder"}),
    ])
    def test_recorder(self, name, steps, check_point):
        '''
        Suite Name: Recorder
        URL: http://intervention.pt.ai.xiaomi.com/skill/71
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT), retry_time)
            self.result = common_result
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))
        Common(DUT).killApp("com.android.soundrecorder")


if __name__ == "__main__":
    unittest.main()
