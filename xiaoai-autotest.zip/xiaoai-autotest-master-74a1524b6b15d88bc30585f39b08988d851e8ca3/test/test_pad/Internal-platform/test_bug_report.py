from datetime import datetime
from test import *


class TestScript(BaseTestCase):
    @parameterized.expand([
        ("gen_log", {"feature": "日志抓取", "query": [{"focus": "true"}, "小爱抓个日志"], "wait_time": [5]}, {"text": "*#*#284#*#*"})
    ])
    def test_bug_report(self, name, steps, check_point):
        '''
        Suite Name: KLO Bugreport
        URL: http://intervention.pt.ai.xiaomi.com/skill/43
        '''
        # file_path = "/sdcard/MIUI/debug_log/com.miui.voiceassist/"
        # file_name = file_path + datetime.now().strftime('%Y%m%d%H.log')
        # #  Clear existed log file to make sure the log file is new;
        # Checkpoint(DUT).shell("> " + file_name)
        # Checkpoint(DUT).shell("tail -10 " + file_name)[0].decode("utf8")
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT), retry_time)
            # Check points:
            # 1. exist the log file;
            # 2. the latest body of log is updated;
            # self.result = Checkpoint(DUT).shell("ls " + file_name)[0] and \
            #     datetime.now().strftime("%Y%m%d_%H") in Checkpoint(DUT).shell("tail -10 " + file_name)[0].decode("utf8") and common_result
            self.result = common_result
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))
        Common(DUT).switch_card_window_focus(False)


if __name__ == "__main__":
    unittest.main()
