from test import *

from aw import *


# TODO unknown expected result
class TestScript(BaseTestCase):
    @parameterized.expand([
        # ("interface_test", {"query": ["帮我整理下图标"], "wait_time": [3]},
        #  {"text": "缓存", "activity": "com.tencent.qqlive/.ona.offline.client.group.DownloadGroupActivity"}),
        # ("interface_test", {"query": ["撤销图标整理"], "wait_time": [3]},
        #  {"text": "缓存", "activity": "com.tencent.qqlive/.ona.offline.client.group.DownloadGroupActivity"}),
        # ("interface_test", {"query": ["帮我自动归类图标"], "wait_time": [3]},
        #  {"text": "缓存", "activity": "com.tencent.qqlive/.ona.offline.client.group.DownloadGroupActivity"}),
        # ("interface_test", {"query": ["帮我整理当前屏幕桌面图标"], "wait_time": [3]},
        #  {"text": "缓存", "activity": "com.tencent.qqlive/.ona.offline.client.group.DownloadGroupActivity"})
    ])
    def test_clean_desktop(self, name, steps, check_point):
        '''
        Suite Name: Clean Desktop
        URL: http://intervention.pt.ai.xiaomi.com/skill/80
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT), retry_time)
            self.result = common_result
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))


if __name__ == "__main__":
    unittest.main()
