from test import *



class TestScript(BaseTestCase):
    @parameterized.expand([
        ("IMEI_code", {"feature": "系统设置", "query": ["手机设备号"], "wait_time": [3]},
         {"text": "IMEI", "activity": "com.android.settings/.Settings$ImeiInformationActivity"}),
        # ("my_set", {"feature": "系统设置", "query": ["打开我的设备"], "wait_time": [5]},
        #  {"text": "我的设备", "activity": "com.android.settings/.SubSettings"}),
        ("cloud_service", {"feature": "系统设置", "query": ["打开云服务"], "wait_time": [3]},
         {"text": "小米云服务", "activity": "com.miui.cloudservice/.ui.MiCloudMainActivity"}),
        # TODO to be confirmed
        ("about", {"feature": "系统设置", "query": ["关于手机"], "wait_time": [3]},
         {"text": "设置|关于手机", "activity": "com.android.settings/.SubSettings"}),
        # TODO to be confirmed
        ("open_input", {"feature": "系统设置", "query": ["打开输入法"], "wait_time": [3]},
         {"text": "设置|输入法", "activity": "com.android.settings/.SubSettings"}),
        ("fashion_gallery", {"feature": "系统设置", "query": ["打开锁屏画报"], "wait_time": [3]},
         {"text": "锁屏画报", "activity": "com.mfashiongallery.emag/.ssetting.JumpSettingActivity"}),
        ("voice_assistant", {"feature": "系统设置", "query": ["语音设置"], "wait_time": [3]},
         {"activity": "com.miui.voiceassist/com.xiaomi.voiceassistant.MiuiVoiceSettingActivity"}),
        ("x_space", {"feature": "系统设置", "query": ["开启应用双开"], "wait_time": [3]},
         {"text": "应用双开", "activity": "com.miui.securitycore/com.miui.xspace.ui.activity.XSpaceSettingActivity"}),
        ("app_lock", {"feature": "系统设置", "query": ["我要给APP上锁"], "wait_time": [3]},
         {"text": "应用锁", "activity": "com.miui.securitycenter/com.miui.applicationlock.FirstUseAppLockActivity"}),
        ("headset_settings", {"feature": "系统设置", "query": ["打开耳机设置"], "wait_time": [3]},
         {"text": "耳机和音效", "activity": "com.android.settings/.Settings$HeadsetSettingsActivity"}),
        ("date_time", {"feature": "系统设置", "query": ["设置日期和时间"], "wait_time": [3]},
         {"text": "日期和时间", "activity": "com.android.settings/.Settings$DateTimeSettingsActivity"}),
        ("sound_settings", {"feature": "系统设置", "query": ["铃声设定"], "wait_time": [3]},
         {"text": "铃声", "activity": "com.android.settings/.Settings$SoundSettingsActivity"}),
        ("theme_settings", {"feature": "系统设置", "query": ["主题设置"], "wait_time": [3]},
         {"text": "个性主题", "activity": "com.android.thememanager/.activity.ThemeSettingsActivity"}),
        ("wall_paper_settings", {"feature": "系统设置", "query": ["打开壁纸设置"], "wait_time": [3]},
         {"text": "壁纸", "activity": "com.android.thememanager/.settings.WallpaperSettingsActivity"}),
        ("font_setting", {"feature": "系统设置", "query": ["我要换字体"], "wait_time": [3]},
         {"text": "标准文字", "activity": "com.android.settings/.Settings$PageLayoutActivity"}),
        ("MIUI_updater", {"feature": "系统设置", "query": ["查看MIUI版本"], "wait_time": [3]},
         {"text": "MIUI", "activity": "com.android.updater/.MainActivity"}),
    ])
    def test_system_setting(self, name, steps, check_point):
        '''
        Suite Name: System Setting
        URL: http://intervention.pt.ai.xiaomi.com/skill/54
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT), retry_time)
            self.result = common_result
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))


if __name__ == "__main__":
    unittest.main()
