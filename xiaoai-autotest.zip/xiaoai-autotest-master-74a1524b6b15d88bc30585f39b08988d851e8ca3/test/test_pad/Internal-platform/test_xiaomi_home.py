from test import *



# TODO can't set checkpoints
class TestScript(BaseTestCase):
    @parameterized.expand([
        ("clean_background_app", {"query": ["清理后台程序"], "wait_time": [3]}, {}
         )
    ])
    def test_xiaomi_home(self, name, steps, check_point):
        '''
        Suite Name: Xiaomi Home
        URL: http://intervention.pt.ai.xiaomi.com/skill/64
        '''
        self.steps = steps
        self.query = self.steps["query"]
        wait_time = self.steps["wait_time"]
        retry_time = CONST.RETRY_MAX
        self.NodeId = __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        while retry_time:
            common_result = Common(DUT).common_execute(self.query, wait_time, check_point, Common(DUT), Checkpoint(DUT), retry_time)
            self.result = common_result
            if self.result:
                break
            else:
                retry_time -= 1
        else:
            Checkpoint(DUT).send_fail_message(self.steps.get("action", ""), self.query, self.domain, Checkpoint(DUT))


if __name__ == "__main__":
    unittest.main()
