import unittest
from aw import *
from aw.common import Common
from aw.checkpoint import Checkpoint

class BaseCase(unittest.TestCase):
    def setUp(self):
        self.dev_name = Common(DUT).getprop("ro.build.product")
        self.domain = "smartApp"
        self.test_result = []
        self.single_query_num = 0
        self.multiple_query_num = 0
        if Common(DUT).isScreenLocked():  # 判断锁屏状态
            Common(DUT).unlockScreen()
            Common(DUT).unlockScreen(CONST.LOCKPW)
        # Common(DUT).shell("rm -rf /sdcard/last_to_speak.txt")

    def tearDown(self):
        rate = self.test_result.count(True) / len(self.test_result)
        print("用例总数：" + str(len(self.test_result)))
        print("单query数：" + str(self.single_query_num))
        print("多query数：" + str(self.multiple_query_num))
        print("Pass数：" + str(self.test_result.count(True)))
        rate_pct = '%.2f%%' % (rate * 100)
        print("测试通过率：" + rate_pct)
        self.assertEqual(rate == 1.0, True)
        Common(DUT).clearRecentApp()


class BaseTestCase(unittest.TestCase):

    def setUp(self):
        self.dev_name = Common(DUT).getprop("ro.build.product")
        self.NodeId = ""  # __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        self.steps = {}
        self.query = []
        self.domain = "default"
        self.result = True
        if Common(DUT).isScreenLocked():  # 判断锁屏状态
            Common(DUT).unlockScreen()
            Common(DUT).unlockScreen(CONST.LOCKPW)
        # Common(DUT).shell("rm -rf /sdcard/last_to_speak.txt")

    def tearDown(self):
        result_detail = {
            True: ["Pass", ""],
            False: ["Fail", ""],
            None: ["Pass", "待确认"]
        }
        self.app_name = self.steps.get("app", "default")
        self.app_ver = Common(DUT).getAppVersionName(CONST.APP[self.app_name]) if CONST.APP.get(self.app_name, "default") != "default" else "default"
        param_dic = {
            "NodeId": self.NodeId,
            "domain": self.steps.get("domain", self.domain),
            "feature": self.steps.get("feature", self.domain),
            "third_app": self.app_name,
            "app_version": self.app_ver,
            "query": self.query,
            "action": self.steps.get("action", "default"),
            "setup": self.steps.get("setup", "任意界面"),
            "result": result_detail[self.result][0],
            "message": result_detail[self.result][1]
        }
        Common(DUT).post_result(param_dic)  # post测试结果到服务器
        Common(DUT).goBackHome()
        Common(DUT).switch_card_window_focus(flag=False)
        self.assertEqual(self.result, True)



#lite
class LiteBaseTestCase(unittest.TestCase):

    def setUp(self):
        self.dev_name = Common(DUT).getprop("ro.build.product")
        self.NodeId = ""  # __file__.replace("\\", ".").replace("/", ".").split('.')[-2]
        self.steps = {}
        self.query = []
        self.domain = "default"
        self.result = True
        if Common(DUT).isScreenLocked():  # 判断锁屏状态
            Common(DUT).unlockScreen()
            Common(DUT).unlockScreen(CONST.LOCKPW)
        # Common(DUT).shell("rm -rf /sdcard/last_to_speak.txt")
        #启动小爱lite的activity
        Common(DUT).startActivity("com.xiaomi.xiaoailite/com.xiaomi.voiceassistant.MainTabActivity")
        Checkpoint(DUT).click_pop_window()


    def tearDown(self):
        result_detail = {
            True: ["Pass", ""],
            False: ["Fail", ""],
            None: ["None", "待确认"]
        }
        self.app_name = self.steps.get("app", "default")
        self.app_ver = Common(DUT).getAppVersionName(CONST.APP[self.app_name]) if CONST.APP.get(self.app_name, "default") != "default" else "default"
        param_dic = {
            "NodeId": self.NodeId,
            "domain": self.steps.get("domain", self.domain),
            "feature": self.steps.get("feature", self.domain),
            "third_app": self.app_name,
            "app_version": self.app_ver,
            "query": self.query,
            "action": self.steps.get("action", "default"),
            "setup": self.steps.get("setup", "任意界面"),
            "result": result_detail[self.result][0],
            "message": result_detail[self.result][1]
        }
        Common(DUT).post_result(param_dic)  # post测试结果到服务器
        self.assertEqual(self.result, True)
        Common(DUT).goBackHome()
        Common(DUT).killApp("com.xiaomi.xiaoailite")


# if __name__ == "__main__":
#     unittest.main()