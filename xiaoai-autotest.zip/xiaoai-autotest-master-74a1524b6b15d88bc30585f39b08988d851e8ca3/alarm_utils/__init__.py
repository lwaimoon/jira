# -*- coding:utf8 -*-

import json, socket, itertools, sys, os
import time
from socketpool.pool import ConnectionPool
from socketpool.conn import TcpConnector

import CONST
from fds_utils import fds_utils


sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), "/../../../"))


class FalconCli(object):

    def __init__(self):
        self.id_counter = itertools.count()
        self.buf_size = 1000
        if not hasattr(FalconCli, 'pool'):
            self.pool = FalconCli.create_pool()
        self._connection = FalconCli.pool.connection()

    @staticmethod
    def create_pool():
        options = {'host': 'transfer.falcon.miliao.srv', 'port': 8433}
        try:
            FalconCli.pool = ConnectionPool(factory=TcpConnector, options=options)
        except Exception as e:
            raise Exception('FalconCli_conn_fail(%s)' % str(e))

    def call(self, name, *params):
        request = dict(id=next(self.id_counter),
                       params=params,
                       method=name)
        payload = json.dumps(request).encode()
        response = '{}'

        with self._connection as conn:
            sent = conn.send(payload)
            response = conn.recv(1024)
        # print(payload)
        print(response)

        # env.logger.debug(payload)
        # env.logger.debug(response)
        response = json.loads(response.decode("utf8"))
        if response.get('error') is not None:
            raise Exception(response.get('error'))
        return response.get('result')

    def send(self, lines):
        s = 0
        resp = []

        while True:
            buf = lines[s:s + self.buf_size]
            s = s + self.buf_size
            if len(buf) == 0:
                break
            r = self.call("Transfer.Update", buf)
            resp.append(r)

        return resp

    def release(self):
        if hasattr(FalconCli, 'pool'):
            FalconCli.pool.release_all()

    @staticmethod
    def config():
        with open(os.path.join(os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir)), "project.json"), "r") as f:
            return json.load(f)

    def send_alarm(self, tag):
        #过滤重复报警
        # from aw import CONFIG
        if self.config()["result_config"]["send_msg"] == "yes":  # 判断工程配置中result_config状态
            try:
                # with open(os.path.join(os.path.dirname(__file__), os.path.pardir, "alarm_list.txt"), "r") as l:
                with open(CONST.ALARM_FILE, "r") as l:
                    item_lst = tag.split(",")
                    for item in item_lst:
                        item = item.split("=")
                        if item[0] == "query":
                            # print(item[0])
                            content = l.readlines()
                            if self.config()["project"] == "monitor":  # 监控测试不进行报警过滤
                                break
                            if item[1] + "\n" in content or len(content) > 60:  # 过滤相同报警，且限制最大报警次数
                                return
                            else:
                                with open(CONST.ALARM_FILE, "a") as l:
                                    l.write(item[1] + "\n")
            except Exception as e:
                print("过滤重复报警出错：" + str(e))
            # 截图上传到融合云
            try:
                with open(os.path.join(os.path.dirname(__file__), os.path.pardir, "link.log"), "r") as f:
                    link = f.read()
                    # print(link)
                slink = fds_utils.upload_file("bvt-test-result", link)
            except Exception as e:
                print("截图上传融合云出错："+str(e))
                slink = ""

            ts = int(time.time())
            _metric = "BVT_Test" if self.config()["project"] == "monitor" else "my_test"  # 分流报警
            payload = [
                {
                    "endpoint": "production",
                    "metric": _metric,
                    "timestamp": ts,
                    "step": 60,
                    "value": 1,
                    "counterType": "GAUGE",
                    "tags": tag+",screenshot=\""+str(slink)+"\"",
                }
            ]
            self.send(payload)

    def send_alarm_lite(self, tag):
        #过滤重复报警
        # from aw import CONFIG
        if self.config()["result_config"]["send_msg"] == "yes":  # 判断工程配置中result_config状态
            try:
                # with open(os.path.join(os.path.dirname(__file__), os.path.pardir, "alarm_list.txt"), "r") as l:
                with open(CONST.ALARM_FILE, "r") as l:
                    item_lst = tag.split(",")
                    for item in item_lst:
                        item = item.split("=")
                        if item[0] == "query":
                            # print(item[0])
                            content = l.readlines()
                            if self.config()["project"] == "monitor":  # 监控测试不进行报警过滤
                                break
                            if item[1] + "\n" in content or len(content) > 60:  # 过滤相同报警，且限制最大报警次数
                                return
                            else:
                                with open(CONST.ALARM_FILE, "a") as l:
                                    l.write(item[1] + "\n")
            except Exception as e:
                print("过滤重复报警出错：" + str(e))
            # 截图上传到融合云
            try:
                with open(os.path.join(os.path.dirname(__file__), os.path.pardir, "link.log"), "r") as f:
                    link = f.read()
                    # print(link)
                slink = fds_utils.upload_file("lite-test-result", link)
            except Exception as e:
                print("截图上传融合云出错："+str(e))
                slink = ""

            ts = int(time.time())
            _metric = "Lite_Test" if self.config()["project"] == "monitor" else "my_test"  # 分流报警
            payload = [
                {
                    "endpoint": "production",
                    "metric": _metric,
                    "timestamp": ts,
                    "step": 60,
                    "value": 1,
                    "counterType": "GAUGE",
                    "tags": tag+",screenshot=\""+str(slink)+"\"",
                }
            ]
            self.send(payload)

    def send_jira_url(self, tag):
        ts = int(time.time())
        payload = [
            {
                "endpoint": "production",
                "metric": "BVT_Test",
                "timestamp": ts,
                "step": 60,
                "value": 1,
                "counterType": "GAUGE",
                "tags": tag,
            }
        ]
        self.send(payload)

    def send_alarm_service(self, tag):
        #过滤重复报警
        # from aw import CONFIG
        if self.config()["result_config"]["send_msg"] == "yes":  # 判断工程配置中result_config状态
            try:
                # with open(os.path.join(os.path.dirname(__file__), os.path.pardir, "alarm_list.txt"), "r") as l:
                with open(CONST.ALARM_FILE, "r") as l:
                    item_lst = tag.split(",")
                    for item in item_lst:
                        item = item.split("=")
                        if item[0] == "query":
                            # print(item[0])
                            content = l.readlines()
                            if self.config()["project"] == "monitor":  # 监控测试不进行报警过滤
                                break
                            if item[1] + "\n" in content or len(content) > 60:  # 过滤相同报警，且限制最大报警次数
                                return
                            else:
                                with open(CONST.ALARM_FILE, "a") as l:
                                    l.write(item[1] + "\n")
            except Exception as e:
                print("过滤重复报警出错：" + str(e))
            # 截图上传到融合云
            # try:
            #     with open(os.path.join(os.path.dirname(__file__), os.path.pardir, "link.log"), "r") as f:
            #         link = f.read()
            #         # print(link)
            #     slink = fds_utils.upload_file("bvt-test-result", link)
            # except Exception as e:
            #     print("截图上传融合云出错："+str(e))
            #     slink = ""

            ts = int(time.time())
            _metric = "my_test"  # 分流报警
            payload = [
                {
                    "endpoint": "production",
                    "metric": _metric,
                    "timestamp": ts,
                    "step": 60,
                    "value": 1,
                    "counterType": "GAUGE",
                    "tags": tag,
                }
            ]
            self.send(payload)


#BVT_Test
    def __del__(self):
        try:
            self.release()
        except Exception as e:
            pass
            # print(e)


if __name__ == "__main__":
    list = ["adbc",{"ccc":"sss"}]
    print(str(list))
    FalconCli().send_alarm('domain=xiaoaiApp,xiaoai=3.2.1-20180522,query='+str(list).replace(",","->"))

