# -*- coding:utf-8 -*-

import getopt
import json
import os
import re
import sys
import time
import traceback
import unittest
import subprocess
import socket

import CONST
from fds_utils import fds_utils


import HTMLTestRunner

rootPath = os.path.abspath(os.path.dirname(__file__))
record = time.strftime("%Y-%m-%d_%H-%M-%S")
spath = os.path.join(rootPath, "report", "test_" + record)
jsonFile = os.path.join(rootPath, "project.json")


with open(jsonFile, "r") as f:
    config = json.load(f)


def generate_test():
    test_txt = open(os.path.join(rootPath, "test.txt"), "w")
    test_txt.close()
    for root, dirs, files in os.walk(os.path.join(rootPath, "test")):
        for file in files:
            if "__" not in file:

                if all(["__" not in file, ".json" not in file, "demo" not in file, file.endswith("py")]):
                    file_path = os.path.join(root, file)
                    test_case = str(file_path.split("/test/")[-1]).replace(".py", "")
                    m = test_case.replace("/", ".").replace("\\", ".")
                    test_module = __import__(".".join(["test", m]), {}, {}, ["test"])
                    test_list = list(test_module.TestScript.__dict__.keys())
                    if test_module.__name__.split(".")[-1] in test_list:  # 解决nose 执行时的error问题，internal-platform适配执行器
                        test_list.remove(test_module.__name__.split(".")[-1])
                    for test in test_list:
                        if "test" in test:
                            with open(os.path.join(rootPath, "test.txt"), "a") as test_txt:
                                test_txt.write(m + "." + test + "\n")


def testSuit(tag=""):
    case_num = 0
    suite = unittest.TestSuite()
    filter_file = "test_" + tag + ".txt" if tag else "test.txt"
    with open(os.path.join(rootPath, filter_file)) as f:
        for line in f.readlines():
            line = line.strip()
            if line[0] != "#" and len(line) != 0:
                li = line.split(".")
                m = ".".join(li[:-1])
                try:
                    test_module = __import__(".".join(["test", m]), {}, {}, ["test"])
                    suite.addTest(test_module.TestScript(li[-1]))
                    case_num += 1
                except Exception as e:
                    traceback.print_exc()
    print("plan to execute :" + str(case_num) + " test cases")
    return suite


def changeConfig(A, B):
    f = open(jsonFile, "r")
    s = f.read()
    s = s.replace(A, B)
    f.close()
    p = open(jsonFile, "w+")
    p.write(s)
    p.close()


def switch_test_env(sn, env):
    xiaoai_ver_code = subprocess.Popen("adb -s %s shell \"dumpsys package com.miui.voiceassist |grep versionCode\"" % sn, shell=True,
                           stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE).communicate()[0].strip().split(b" ")[0].split(b"=")[1].decode("utf8")

    xfolder = "/sdcard/aisdk/" if int(xiaoai_ver_code) < 303006000 else "/sdcard/MIUI/debug_log/com.miui.voiceassist/dev_env/"  # 根据版本号适配环境切换路径


    res = subprocess.Popen("adb -s %s shell rm -rf " % sn + xfolder, shell=True,
                           stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE).communicate()[0]
    subprocess.Popen("adb -s %s shell am force-stop com.miui.voiceassist" % sn, shell=True,
                     stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE).communicate()
    try:
        if env == "staging":
            res = subprocess.Popen("adb -s %s shell mkdir -p " % sn + xfolder + "staging_on", shell=True, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE).communicate()[0]
            subprocess.Popen("adb -s %s shell am force-stop com.miui.voiceassist" % sn, shell=True,
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE).communicate()

            print("测试环境切换到" + env + "：" + res.decode("utf8"))
        elif env == "preview":
            res = subprocess.Popen("adb -s %s shell mkdir -p " % sn + xfolder + "preview_on",
                                   shell=True, stdout=subprocess.PIPE,stderr=subprocess.PIPE).communicate()[0]
            subprocess.Popen("adb -s %s shell am force-stop com.miui.voiceassist" % sn,
                             shell=True,
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE).communicate()

            print("测试环境切换到" + env + "：" + res.decode("utf8"))
        elif env == "production":
            print("测试环境切换到" + env)
        else:
            print("请选择正确的测试环境：production/preview/staging")
            sys.exit(1)
    except Exception as e:
        print("测试环境切换异常："+str(e))
        sys.exit(1)


def wireless_adb(ip):
    compile_ip = re.compile('^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')
    if compile_ip.match(ip):
        res = subprocess.Popen("adb connect %s" % ip, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0].decode("utf-8").strip()
        if "unable" in res:
            print("连接失败："+res)
            return False
        else:
            print("连接成功：" + res)
            return True
    else:
        print("ip地址格式有误")
        return False

def get_host_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()

    return ip

def toRun(tag="astarqltechn", loop=1):
    changeConfig("\"screencap\":\"no\"", "\"screencap\":\"yes\"")
    from aw import CONFIG
    sn = CONFIG["device"]["DUT"]["sn"]
    switch_test_env(sn, CONFIG["test_env"])

    res = os.popen("adb -s %s root" % sn).read().strip() if sn else os.popen("adb root").read().strip()# 已root手机获取adb root权限
    print(res)
    res1 = os.popen("adb -s %s shell \"rm -rf /sdcard/nlp_track.txt\"" % sn).read().strip() if sn else os.popen(
        "adb shell \"rm -rf /sdcard/nlp_track.txt\"").read().strip()  # 删除nlp_track.txt
    print(res1)
    with open(os.path.join(rootPath, "project.log"), 'w+') as f:
        f.write(spath)
    #     print >>f,spath
    if not os.path.exists(spath):
        os.makedirs(spath)
    # 删除一个月前的log
    _date = record.split("_")[0].split("-")
    _year, _month, _day =_date[0], _date[1], _date[2]
    if int(_day) >= 28:
        if _month == "01":
            d_year, d_month = str(int(_year) - 1), "12"
        elif _month == "11":
            d_year, d_month = _year, "10"
        elif _month == "12":
            d_year, d_month = _year, "11"
        else:
            d_year, d_month = _year, "0" + str(int(_month) - 1)
        print("sudo rm -rf " + spath.replace(record, "-".join([d_year, d_month, "*"])))
        subprocess.Popen("sudo rm -rf " + spath.replace(record, "-".join([d_year, d_month, "*"])), shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    print("Report saved to :" + spath)
    for i in range(loop):
        filename = os.path.join(spath, CONFIG["project"] + "_test_report_" + str(i) + ".html")
        # print("ln -s "+os.path.split(filename)[0] + " /home/yanglikai/uwsgi_env/mysite/report/")
        fp = open(filename, 'wb')
        # runner = unittest.TextTestRunner()
        if tag not in CONST.NOT_MI_DEVICE:
            runner = HTMLTestRunner.HTMLTestRunner(stream=fp, title="小爱客户端自动测试报告", description="测试机型：" + CONFIG["project"] + " 小爱版本：" + CONFIG["xiaoai_ver"] + " 测试环境：" + CONFIG["test_env"],
                                                verbosity=2)
        else:
            runner = HTMLTestRunner.HTMLTestRunner(stream=fp, title="小爱Lite自动测试报告", description="测试机型：" + CONFIG["project"] + " 小爱版本：" + CONFIG["xiaoai_ver"] + " 测试环境：" + CONFIG["test_env"],
                                                verbosity=2)
        runner.run(testSuit(tag))
        # runner.run(unittest.defaultTestLoader.discover("test", pattern="*.py", top_level_dir=None))
        fp.close()
        server_ip = get_host_ip() #获取当前ip生成报告链接
        if tag and server_ip == CONST.WORK_SERVER["ip_1"]:  # tag不为空时，框架会将测试报告软链接到nginx服务器下，实现网页访问报告
            subprocess.Popen("ln -s "+os.path.split(filename)[0] + " /home/yanglikai/uwsgi_env/mysite/report/", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            print("TestReport:http://" + CONST.WORK_SERVER["ip_1"] +"/report/" + str(os.path.split(filename)[0].split("/")[-1]) + "/" + str(os.path.split(filename)[1]))
        elif tag and server_ip == CONST.WORK_SERVER["ip_2"]:
            subprocess.Popen("ln -s " + os.path.split(filename)[0] + " /var/www/html/report/", shell=True,stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            print("TestReport:http://" + CONST.WORK_SERVER["ip_2"] + "/report/" + str(os.path.split(filename)[0].split("/")[-1]) + "/" + str(os.path.split(filename)[1]))
    # os.popen("adb -s %s pull /sdcard/nlp_track.txt " % sn + os.path.join(spath, "nlp_track_%s.txt" % sn)).read().strip() if sn else os.popen(
    #     "adb pull  /sdcard/nlp_track.txt " + os.path.join(spath, "nlp_track.txt")).read().strip()  # 删除nlp_track.txt
    # dl = fds_utils.upload_file("xiaoai-log", os.path.join(spath, "nlp_track_%s.txt" % sn))
    # print("nlp_trace 下载链接：" + dl)
    changeConfig("\"screencap\":\"yes\"", "\"screencap\":\"no\"")


def main(argv):
    sn = ""
    _tag = ""
    _loop = 1
    try:
        opts, args = getopt.getopt(argv, "hs:l:f:e:p:b:")
    except getopt.GetoptError:
        print('usage:python run.py -s xxxx -l 1 -f mix2s -e staging')
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print('python run.py -s <device serial> -l <test loop> -f <filter file\'s tag name > -e <test environment '
                  'staging or production>')
            sys.exit()
        elif opt == "-s":
            sn = arg
            # 实现adb无线连接
            compile_ip = re.compile('^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')
            if compile_ip.match(sn):
                res = subprocess.Popen("adb connect %s" % sn, shell=True, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE).communicate()[0].decode("utf-8").strip()
                if "unable" in res:
                    print("无线adb连接失败：" + res)
                    return
                else:
                    print("无线adb连接成功：" + res)
                    sn = sn+":5555"

            if os.popen("adb -s %s get-state" % sn).read().strip() == "device":  # 判断设备连接状态
                name = os.popen("adb -s %s shell getprop ro.product.model" % sn).read().strip()
                version = os.popen("adb -s %s shell \"dumpsys package com.miui.voiceassist |grep versionName\"" % sn).read().strip()
                if version == "":
                    version = os.popen("adb -s %s shell \"dumpsys package com.xiaomi.xiaoailite |grep versionName\"" % sn).read().strip()
                print(version)

                xiaoai_ver = version.split(" ")[0].split("=")[1].strip()
                # miui_v = os.popen("adb -s %s shell getprop ro.miui.ui.version.name" % sn).read().strip()
                miui_ver = os.popen("adb -s %s shell getprop ro.build.version.incremental" % sn).read().strip()

                changeConfig("\"xiaoai_ver\":\"" + config["xiaoai_ver"] + "\"", "\"xiaoai_ver\":\"" + xiaoai_ver + "\"")
                changeConfig("\"miui\":\"" + config["miui"] + "\"", "\"miui\":\"" + "MIUI%s" % miui_ver + "\"")
                changeConfig("\"sn\":\"" + config["device"]["DUT"]["sn"] + "\"", "\"sn\":\"" + sn + "\"")
                changeConfig("\"name\":\"" + config["device"]["DUT"]["name"] + "\"", "\"name\":\"" + name + "\"")
            else:
                sys.exit(1)
        elif opt == "-l":
            _loop = arg
        elif opt == "-f":
            _tag = arg
            changeConfig("\"project\":\"" + config["project"] + "\"", "\"project\":\"" + _tag + "\"")
        elif opt == "-e":
            env = arg
            changeConfig("\"test_env\":\"" + config["test_env"] + "\"", "\"test_env\":\"" + env + "\"")
        elif opt == "-p":
            _post = arg
            changeConfig("\"post_result\":\"" + config["result_config"]["post_result"] + "\"", "\"post_result\":\"" + _post + "\"")
            # changeConfig("\"send_msg\":\"" + config["result_config"]["send_msg"] + "\"", "\"send_msg\":\"" + _post + "\"")
        elif opt == "-b":
            _branch = arg
            changeConfig("\"xiaoai_branch\":\"" + config["xiaoai_branch"] + "\"",
                         "\"xiaoai_branch\":\"" + _branch + "\"")
            # changeConfig("\"send_msg\":\"" + config["result_config"]["send_msg"] + "\"", "\"send_msg\":\"" + _post + "\"")

    if len(sn) == 0:
        print("sn不能为空")
        return
    toRun(tag=_tag, loop=int(_loop))


if __name__ == "__main__":
    # generate_test()
    main(sys.argv[1:])
    # toRun()