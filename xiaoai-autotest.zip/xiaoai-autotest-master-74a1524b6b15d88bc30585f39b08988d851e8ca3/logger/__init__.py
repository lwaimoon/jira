# -*-coding:utf-8-*-
import sys
import time, datetime
import HTMLTestRunner

__out_console__ = sys.stdout
__err_console__ = sys.stderr


def to_console(func):
    def wraper(*args, **kwargs):
        sys.stdout = __out_console__
        sys.stderr = __err_console__
        func(*args, **kwargs)
        sys.stdout = HTMLTestRunner.stdout_redirector
        func(*args, **kwargs)
    return wraper


class Logger(object):

    def _now(self):
        return str(datetime.datetime.now()).split(".")[0]

    def debug(self, message):
        print(self._now() + "-[DEBUG]-" + message)

    # @to_console
    def info(self, message):
        print(self._now() + "-[INFO]-" + message)

    def warn(self, message):
        print(self._now() + "-[WARN]-" + message)

    def error(self, message):
        print(self._now() + "-[ERROR]-" + message)

    def critical(self, message):
        print(self._now() + "-[CRITICAL]-" + message)


Logger = Logger()

if __name__ == "__main__":
    pass
