# -*- coding: utf-8 -*-
import getopt
import json
import sys
import os
import subprocess

import time
import traceback
import urllib.request

from jenkinsapi.jenkins import Jenkins
# from app_monitor import AppMonitor
import CONST

with open(os.path.join(os.path.abspath(os.path.dirname(__file__)), "project.json"), "r") as f:
    config = json.load(f)

def get_server_instance():
    jenkins_url = 'http://jenkins.cc.d.xiaomi.net'
    server = Jenkins(jenkins_url, username="yanglikai", password="d237e49caa161ad4068196196b4f1f7c")
    return server

def triger_test(SN, LOOP, FILTER, ENV, POST, MSG, BRANCH):
    '''
    构建jenkins任务
    :param SN: 设备SN号
    :param LOOP: 测试轮数
    :param FILTER: 选择测试的用例集
    :param ENV: 测试环境选择，指的是小爱运行环境：production or staging
    :return:
    '''
    server = get_server_instance()
    job = server.get_job("ST_Client_BVT_Test")
    build_params = dict()
    # build_params["PROJECT_NAME"] = PROJECT_NAME
    build_params["SN"] = SN
    build_params["LOOP"] = LOOP
    build_params["FILTER"] = FILTER
    build_params["ENVIRONMENT"] = ENV
    build_params["POST"] = POST
    build_params["MESSAGE"] = MSG
    build_params["BRANCH"] = BRANCH
    queue_item = job.invoke(build_params=build_params, delay=0)
    queue_item.block_until_building()
    build = queue_item.get_build()
    print("start ST_Client_BVT_Test. build number is %s" % build.get_number())
    time.sleep(5)
    # build.block_until_complete(delay=10)
    # build.poll()

def triger_apk_build(SN, BRANCH):
    '''
        构建jenkins任务
        :param SN: 设备SN号,"all" 为全部连接设备
        :param BRANCH: 需要打包的分支
        :return:
        '''
    server = get_server_instance()
    job = server.get_job("ST_client_apk_autotest")
    build_params = dict()
    # build_params["PROJECT_NAME"] = PROJECT_NAME
    build_params["SN"] = SN
    build_params["BRANCH"] = BRANCH
    queue_item = job.invoke(build_params=build_params, delay=0)
    queue_item.block_until_building()
    build = queue_item.get_build()
    print("start ST_client_apk_autotest. build number is %s" % build.get_number())
    build.block_until_complete(delay=10)
    build.poll()
    return build.get_description()

def main(argv):
    with open(CONST.ALARM_FILE, "w") as f:  # 初始化报警过滤文件
        f.write("")
    _loop = "1"
    _apk_file = ""
    _sn = ""
    _env = "production"
    _post = "yes"
    _msg = ""
    _branch = ""
    flag = True
    try:
        opts, args = getopt.getopt(argv, "hs:l:e:p:f:m:b:")
    except getopt.GetoptError:
        sys.exit(2)
    for opt, arg in opts:
        if opt == "-l":
            _loop = arg
        elif opt == "-s":
            _sn = arg
        elif opt == "-f":
            _apk_file = arg.strip()
            if _apk_file.startswith("http://"):
                local_file, dummy = urllib.request.urlretrieve(_apk_file, os.path.join(os.path.dirname(__file__), _apk_file.split("/")[-1]))
                _apk_file = local_file
        elif opt == "-e":
            _env = arg
        elif opt == "-p":
            _post = arg
        elif opt == "-m":
            _msg = arg
        elif opt == "-b":
            _branch = arg
        elif opt == "-h":
            print("Usage : python run_triger_jenkins.py -s [device sn number | 'all' mean all devices connected] -l [test loop ] -e [production or staging, default production]")
    if _sn == "all":  # 对服务器上连接的所有手机进行自动化测试
        res = os.popen("adb devices").read()
        dev_lst = res.strip().split("\n")[1:]
        if len(_apk_file) < 4 and len(_branch) > 0:
            flag = False
            _apk_file = triger_apk_build(_sn, _branch)  # 触发apk打包

        for dev in dev_lst:
            dev_info = dev.split("\t")
            if all([len(dev_info) == 2, dev_info[1] == "device", dev_info[0] not in config["blacklist"]]):
                sn = dev_info[0]
                res = subprocess.Popen("adb -s %s shell getprop ro.build.product" %sn, shell=True,
                                       stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE).communicate()  # 获取设备名，设备名对应相应的测试用例集
                _filter = res[0].decode("utf8").strip() if "not found" not in res[0].decode("utf8") else "monitor" # 如果获取设备名失败则为监控用例
                print(sn + " : 执行测试集合 " + _filter)
                if len(str(_apk_file)) > 4 and flag:
                    subprocess.Popen("adb -s %s uninstall com.miui.voiceassist" % sn, shell=True,
                                     stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE).communicate()  # 先卸载小爱应用，避免低版本无法安装

                if len(_branch) == 0:  # 触发无需升级apk的测试
                    _branch = "online"  # 根据测试策略 online线上版本监控测试，之后会根据app质量平台做调整
                    triger_test(sn, _loop, _filter, _env, _post, _msg, _branch)
                    print(sn + ": 测试执行成功")
                    continue

                if os.path.isfile(_apk_file):
                    try:
                        res = subprocess.Popen("adb -s %s install -r \"%s\"" % (sn, _apk_file), shell=True,
                                               stdout=subprocess.PIPE,
                                               stderr=subprocess.PIPE).communicate(timeout=300)  # 安装相应的apk
                        print(sn + ": 小爱安装状态 " + res[0].decode("utf8").strip())
                        if res[0].decode("utf8").strip() == "Success":
                            _branch = "online" if _branch == "onlinemiai" else _branch  # 对分支名做临时处理，之后会根据app质量平台做调整
                            triger_test(sn, _loop, _filter, _env, _post, _msg, _branch)
                            print(sn + ": 测试执行成功")
                    except Exception as e:
                        traceback.print_exc()
                else:
                    print("apk file 无效，请检查！")
                    return

    else:
        if len(_apk_file) < 4 and len(_branch) > 0:  # _branch 不为空时 触发打包
            flag = False  # 判断是否需要卸载现在小爱的标志
            _apk_file = triger_apk_build(_sn, _branch)  # 触发apk打包
        sn_lst = _sn.split(",")  # 对指定sn的设备进行自动化测试
        for sn in sn_lst:
            if sn:
                res = subprocess.Popen("adb -s %s shell getprop ro.build.product" %sn, shell=True,
                                       stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE).communicate()  # 获取设备名，设备名对应相应的测试用例集
                _filter = res[0].decode("utf8").strip() if "not found" not in res[0].decode("utf8") else "monitor" # 如果获取设备名失败则为监控用例
                print(sn + " : 执行测试集合 " + _filter)
                if len(str(_apk_file)) > 4 and flag:
                    subprocess.Popen("adb -s %s uninstall com.miui.voiceassist" % sn, shell=True,
                                     stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE).communicate()  # 先卸载小爱应用，避免低版本无法安装

                if len(_branch) == 0:  # 触发无需升级apk的测试
                    _branch = "online"  # 根据测试策略 online线上版本监控测试，之后会根据app质量平台做调整
                    triger_test(sn, _loop, _filter, _env, _post, _msg, _branch)
                    _branch = ""  # 重置参数
                    print(sn + ": 测试执行成功")
                    continue
                if os.path.isfile(_apk_file):
                    try:
                        res = subprocess.Popen("adb -s %s install -r \"%s\"" % (sn, _apk_file), shell=True,
                                               stdout=subprocess.PIPE,
                                               stderr=subprocess.PIPE).communicate(timeout=300)  # 安装相应的apk
                        print(sn + ": 小爱安装状态 " + res[0].decode("utf8").strip())
                        if res[0].decode("utf8").strip() == "Success":
                            _branch = "online" if _branch == "onlinemiai" else _branch  # 对分支名做临时处理，之后会根据app质量平台做调整
                            triger_test(sn, _loop, _filter, _env, _post, _msg, _branch)
                            print(sn + ": 测试执行成功")
                    except Exception as e:
                        traceback.print_exc()
                else:
                    print("apk file 无效，请检查！")
                    return


if __name__ == "__main__":
    main(sys.argv[1:])

