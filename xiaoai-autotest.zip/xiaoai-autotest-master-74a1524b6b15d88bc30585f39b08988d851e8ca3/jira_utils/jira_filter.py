#coding=utf-8
import os
from jira_utils.jira_config import JiraConfig

class JiraFilter(object):
    """Jira问题的过滤器,有些问题无需提Jira,通过此类过滤"""

    def __init__(self):
        #标识所有MIUI应用,以字符串形式存在
        #格式:com.xiaomi.scanner
        self.__miui_app_list = []
        #标识当提Jira时,哪些可以过滤掉不提Jira,以字符串形式存在
        #格式:android.app.Activity.performPause
        #默认为空,业务组可根据情况排除一些无需提Jira的情况
        self.white_list = []
        #解析config文件
        self.__init_miui_app_list()
        self.init_white_list()

    def __init_miui_app_list(self):
        """private方法,根据config文件初始化变量"""
        config_dir = os.path.join(JiraConfig.WORK_DIR, JiraConfig.CONFIG_DIR)
        if os.path.exists(config_dir):
            self._config_dir = config_dir
            #初始化miui_app_list
            miui_app_list_config = os.path.join(self._config_dir, JiraConfig.MIUI_APP_LIST_CONFIG_FILE)
            if os.path.exists(miui_app_list_config):
                try:
                    miui_app_reader = open(miui_app_list_config, "r")
                    for line in miui_app_reader.readlines():
                        line = line.strip()
                        if line != "":
                            self.__miui_app_list.append(line)
                except Exception as e:
                    print("init miui app list  failed : " + str(e))
                finally:
                    if miui_app_reader != None:
                        miui_app_reader.close()

    def init_white_list(self):
        #初始化white_list,默认位置在当前位置的config目录下
        white_list_config = os.path.join(self._config_dir, JiraConfig.WHITE_LIST_CONFIG_FILE)
        if os.path.exists(white_list_config):
            try:
                white_list_reader = open(white_list_config, "r")
                for line in white_list_reader.readlines():
                    line = line.strip()
                    if line != "":
                        self.white_list.append(line)
            except Exception as e:
                print("init white list failed : " + str(e))
            finally:
                if white_list_reader != None:
                    white_list_reader.close()

    def filter_from_white_list(self, json_obj):
        """protected方法,如果业务组需要自己定制白名单,需集成这个类并重写此方法"""
        return False

    def filter(self, json_obj):
        """主方法,返回true标识提Jira"""
        if self._is_miui_app(json_obj) and not self.filter_from_white_list(json_obj):
            return True
        return False

    def _is_miui_app(self, json_obj):
        """protected方法,如果不是miui app,返回true标识,如果用户需要自定义功能,重写此方法即可"""
        try:
            package_name = json_obj[JiraConfig.JSON_PACKAGE_KEY].strip()
            if len(self.__miui_app_list) != 0 and package_name.strip() in self.__miui_app_list:
                return True
        except Exception as e:
            print("parse the json error : " + str(e))
        print("Package: " + package_name + " is not miui app, no need to create jira")
        return False

    def get_miui_app_list(self):
        """public方法,返回私有变量"""
        return self.__miui_app_list