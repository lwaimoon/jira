#coding=utf-8
import os

class JiraConfig:

    CONFIG_DIR = "config"

    COMPONENTS_CONFIG_FILE = "components.conf"
    WHITE_LIST_CONFIG_FILE = "white_list.conf"
    MIUI_APP_LIST_CONFIG_FILE = "miui_app_list.conf"

    #Jira Server地址
    JIRA_HOST = 'http://jira.n.xiaomi.com'
    JIRA_PORT = 8080
    JIRA_REST_PATH = '/rest/api/2/issue/'
    JIRA_OPTIONS = {'server': JIRA_HOST}

    #登录Jira时用户
    JIRA_USERNAME = 'yanglikai'
    JIRA_PASSWORD = 'Kevin_456'
    JIRA_ROOT_AUTH = (JIRA_USERNAME, JIRA_PASSWORD)

    #jira project
    JIRA_PROJECT_MIUI = "MIUI"
    JIRA_PROJECT_XIAOAI = "XIAOAI"

    #Jira Json对象字段配置
    JSON_SUMMARY_KEY = "summary"
    JSON_LABEL_KEY = "label"
    JSON_PACKAGE_KEY = "package"
    JSON_APP_VERSION_KEY = "app_version"
    JSON_DESC_KEY = "desc"
    JSON_AFFECTED_VERSION_KEY = "affected_version"
    JSON_ANDROID_VERSION_KEY = "android_version"
    JSON_ATTACHMENT_FILE_KEY = "file_path"
    JSON_ASSIGNEE_KEY = "assignee"

    #Jira Status
    #提Jira失败
    JIRA_STATE_ERROR = -1
    #无需提Jira
    JIRA_STATE_DONOT_NECESSARY_TO_CREATE_JIRE = 0
    #已提Jira
    JIRA_STATE_HAS_JIRA = 1
    #可提Jira
    JIRA_STATE_CAN_SET_JIRA = 2
    #新建Jira
    JIRA_STATE_NEW_JIRA = 3

    #Jira 问题类型
    ISSUE_TYPE_IMPROVENT_ENGLISH = "Improvement"
    ISSUE_TYPE_IMPROVENT_CHINESE = "改进"
    ISSUE_TYPE_TASK_ENGLISH = "Task"
    ISSUE_TYPE_TASK_CHINESE = "任务"
    ISSUE_TYPE_NEW_FEATURE_ENGLISH = "New Feature"
    ISSUE_TYPE_NEW_FEATURE_CHINESE = "新功能"
    ISSUE_TYPE_BUG_CHINESE = "故障"
    ISSUE_TYPE_BUG_ENGLISH = "Bug"

    #jira status
    STATUS_OPEN_ENGLISH = "open"
    STATUS_OPEN_CHINESE = "开放"
    STATUS_REOPEN_ENGLISH = "reopen"
    STATUS_REOPEN_CHINESE = "重新打开"

    #Jira问题类型-MIUI
    ISSUE_MIUI_FUNCTION_TYPE = "基本功能Basic Functionality"
    ISSUE_MIUI_PERFORMACE_TYPE = "性能Performance"
    ISSUE_MIUI_POWER_TYPE = "功耗Power Consumption"
    ISSUE_MIUI_STABILITY_TYPE = "稳定性Stability"

    #issue status
    ISSUE_CLOSE = 2
    ISSUE_OPEN = 3
    ISSUE_RESOLVE = 5

    #Jira priority
    JIRA_PRIORITY_MINOR_ENGLISH = "Minor"
    JIRA_PRIORITY_MINOR_CHINESE = "次要"
    JIRA_PRIORITY_MAJOR_ENGLISH = "Major"
    JIRA_PRIORITY_MAJOR_CHINESE = "重要"
    JIRA_PRIORITY_CRITICAL_ENGLISH = "Critical"
    JIRA_PRIORITY_CRITICAL_CHINESE = "严重"
    JIRA_PRIORITY_BLOCKER_ENGLISH = "Blocker"
    JIRA_PRIORITY_BLOCKER_CHINESE = "紧急"

    #问题出现频率
    ISSUE_APPEARING_CERTAIN = "必现 every time"
    ISSUE_APPEARING_INCIDENTAL = "偶现 sometimes"

    #平台类别
    ANDROID = "Android"
    IOS = "iOS"

    #获取工作目录
    WORK_DIR = os.path.dirname(os.path.realpath(__file__))
