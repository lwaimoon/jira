# -*- coding: utf-8 -*-

from jenkinsapi.jenkins import Jenkins


def get_server_instance():
    jenkins_url = 'http://jenkins.cc.d.xiaomi.net'
    server = Jenkins(jenkins_url)
    return server


def trigger_jira_creat(server):
    job = server.get_job("ST_client_jira_creat")
    build_params = dict()
    build_params["QUERY"] = "自动创建jira测试"  # 对应case query
    build_params["XIAOAI"] = ""  # 对应小爱版本
    build_params["DEVICE"] = ""  # 对应设备名
    build_params["MIUI"] = ""  # 对应miui版本
    build_params["FILE"] = ""  # 对应附件路径
    build_params["PERSON"] = ""  # 对应责任人
    queue_item = job.invoke(build_params=build_params, delay=0)
    queue_item.block_until_building()
    build = queue_item.get_build()
    print("start to build. build number is %s" % build.get_number())
    build.block_until_complete(delay=10)
    build.poll()

    jira_url = build.get_description().replace("</a>", "").split(">")[-1]
    return jira_url.strip()  # jira_url链接


if __name__ == "__main__":
    server = get_server_instance()
    trigger_jira_creat(server)

