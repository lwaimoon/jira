# coding=utf-8

from jira_utils.jira_config import JiraConfig


class JiraSource:

    def __init__(self, summary, label, package, app_version, desc, affected_version, android_version, attach_file, assignee):
        self.summary = summary
        self.label = label
        self.package = package
        self.app_version = app_version
        self.desc = desc
        self.affected_version = affected_version
        self.android_version = android_version
        self.attach_file = attach_file
        self.assignee = assignee

    def to_json(self):
        """需要业务组实现"""
        return {JiraConfig.JSON_SUMMARY_KEY: self.summary, JiraConfig.JSON_LABEL_KEY: self.label,
                JiraConfig.JSON_PACKAGE_KEY: self.package,
                JiraConfig.JSON_APP_VERSION_KEY: self.app_version, JiraConfig.JSON_DESC_KEY: self.desc,
                JiraConfig.JSON_AFFECTED_VERSION_KEY: self.affected_version,
                JiraConfig.JSON_ANDROID_VERSION_KEY: self.android_version,
                JiraConfig.JSON_ATTACHMENT_FILE_KEY: self.attach_file,
                JiraConfig.JSON_ASSIGNEE_KEY: self.assignee}
