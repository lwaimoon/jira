# coding=utf-8
import json
import os
import subprocess
import traceback
import zipfile
# reload(sys)
# sys.setdefaultencoding('utf-8')
import tarfile
from jira.client import JIRA

from jira_utils import jira_source
from jira_utils.jira_config import JiraConfig
from jira_utils.jira_filter import JiraFilter
from jira_utils.jira_source import JiraSource


class JiraHelper(object):
    CREATE_JIRA_ERROR_LOG = "errors_log"
    ADD_ATTACHMENT_LOG_FILE = "add_attachment_log"

    def __init__(self, jira_filter=None):
        """初始化"""
        self.filter = jira_filter
        error_file_name = os.path.join(os.path.dirname(__file__), JiraHelper.CREATE_JIRA_ERROR_LOG)
        if os.path.exists(error_file_name):
            os.remove(error_file_name)
        self.error_file = open(error_file_name, 'a')
        if not self.filter:
            self.filter = JiraFilter()
        self.jira = JIRA(options=JiraConfig.JIRA_OPTIONS, basic_auth=JiraConfig.JIRA_ROOT_AUTH)
        # 标识Jira中package对应的component,以键值对方式存在
        # 格式: com.miui.virtualsim:Description 通讯组
        self.__package_component = {}
        self.__init_jira_components()

    def __del__(self):
        self.error_file.close()

    def __init_jira_components(self):
        # 初始化components
        config_dir = os.path.join(JiraConfig.WORK_DIR, JiraConfig.CONFIG_DIR)
        if os.path.exists(config_dir):
            self._config_dir = config_dir
            components_config = os.path.join(self._config_dir, JiraConfig.COMPONENTS_CONFIG_FILE)
            if os.path.exists(components_config):
                try:
                    components_reader = open(components_config, "r")
                    for line in components_reader.readlines():
                        line = line.strip()
                        datas = line.split(':')
                        if len(datas) == 2:
                            self.__package_component[datas[0].strip()] = datas[1].strip()
                        else:
                            print("add component is error: " + line)
                except Exception as e:
                    print("init components failed : " + str(e))
                finally:
                    if components_reader != None:
                        components_reader.close()

    def get_jira_component(self, package):
        return "无"
        # package = package.strip()
        # if package in (self.__package_component.keys()):
        #     return self.__package_component[package]
        # else:
        #     return None

    def start_jira(self, source):
        """主方法"""
        # source为JiraSource实例,需要实现toJson方法
        jira_id = ""
        json_obj = source.to_json()
        if isinstance(source, JiraSource):
            if self.__is_necessary_to_create_jira(json_obj):
                return self.may_create_jira(json_obj)
            else:
                # print("########## no need to create jira")
                # 无需提Jira
                return JiraConfig.JIRA_STATE_DONOT_NECESSARY_TO_CREATE_JIRE
        else:
            # print("parameter error")
            return JiraConfig.JIRA_STATE_ERROR, jira_id

    def __is_necessary_to_create_jira(self, json_obj):
        if self.get_jira_priority(json_obj) == '':
            return False
        return self.filter.filter(json_obj)

    def may_create_jira(self, json_obj):
        """根据json数据先判断是否需要新建Jira,如果已存在Jira,更新Jira状态,如果没有则新建"""
        exist_jiras = self.search_issues(json_obj)
        # print(exist_jiras)
        if exist_jiras != None and len(exist_jiras) > 0:
            # 如果Jira类似,则先合并,只留最高优先级的Jira
            exist_jira = self.merge_similar_jiras(exist_jiras)
            # print("find similar jira, update it directly: " + str(exist_jira))
            if not self.update_exist_jira(json_obj, exist_jira):
                self.__write_errors("########## Update Exist Jira Error ##########")
                self.__write_errors(self.generate_jira_desc(json_obj))
            return JiraConfig.JIRA_STATE_HAS_JIRA, exist_jira.key
        else:
            # print("donot find similar jira, now create new jira")
            state, jira_id = self.create_jira(json_obj)
            if state == JiraConfig.JIRA_STATE_ERROR:
                self.__write_errors("########## Create New Jira Error ##########")
                self.__write_errors(self.generate_jira_desc(json_obj))
            return state, jira_id

    def merge_similar_jiras(self, jiras):
        jira_tmp = ''
        # 1:从OPEN的jira中找出优先级最高的jira
        for exist_jira in jiras:
            if self._is_open(exist_jira.fields.status):
                current_priority = exist_jira.fields.priority
                if str(jira_tmp) == '' or self.compare_priority(current_priority, jira_tmp.fields.priority):
                    jira_tmp = exist_jira
        # 2:如果没有oepn的jira,则从close的Jira中找出优先级最高的jira
        if str(jira_tmp) == '':
            for exist_jira in jiras:
                current_priority = exist_jira.fields.priority
                if str(jira_tmp) == '' or self.compare_priority(current_priority, jira_tmp.fields.priority):
                    jira_tmp = exist_jira
        # 3:将优先级最高的jira open,并将其他Jira都关闭
        if str(jira_tmp) != '':
            for exist_jira in jiras:
                if exist_jira == jira_tmp:
                    if not self._is_open(exist_jira.fields.status):
                        # open jira
                        self.jira.transition_issue(exist_jira, JiraConfig.ISSUE_OPEN)
                        # print("Reopen jira: " + str(exist_jira.key))
                else:
                    if self._is_open(exist_jira.fields.status):
                        # close jira
                        self.jira.transition_issue(exist_jira, JiraConfig.ISSUE_CLOSE)
                        description = "Find similar jira: " + str(jira_tmp.key) + " now close jira: " + str(
                            exist_jira.key)
                        # print(description)
                        self.jira.add_comment(exist_jira, description)
        return jira_tmp

    def create_jira(self, json_obj):
        summary = json_obj[JiraConfig.JSON_SUMMARY_KEY].strip()
        label = json_obj[JiraConfig.JSON_LABEL_KEY].strip()
        package = json_obj[JiraConfig.JSON_PACKAGE_KEY].strip()
        apk_version = json_obj[JiraConfig.JSON_APP_VERSION_KEY].strip()
        affectedVersion = json_obj[JiraConfig.JSON_AFFECTED_VERSION_KEY].strip()
        android_version = json_obj[JiraConfig.JSON_ANDROID_VERSION_KEY].strip()
        assignee = json_obj[JiraConfig.JSON_ASSIGNEE_KEY].strip()
        component = self.get_jira_component(package)
        project = self.get_jira_project(json_obj)
        priority = self.get_jira_priority(json_obj)
        miui_type = self.get_jira_miui_type(json_obj)
        if not component:
            # print("cannot find %s component, please check" % package)
            return JiraConfig.JIRA_STATE_ERROR
        issue_type = self.get_issue_type(json_obj)
        jira_reproductivity = self.get_jira_reproductivity(json_obj)
        jira_description = self.generate_jira_desc(json_obj)
        # print("###### project:" + project)
        # print("###### issue_type: " + issue_type)
        # print("###### summary: " + summary)
        # print("###### label: " + label)
        # print("###### component: " + component)
        # print("###### jira_description: " + jira_description)
        # print("###### affectedVersion: " + affectedVersion)
        # print("###### android_version: " + android_version)
        # print("###### apk_version: " + apk_version)
        # print("###### priority: " + priority)
        # print("###### miui_type: " + miui_type)
        # print("###### jira_reproductivity: " + jira_reproductivity)
        if not affectedVersion:
            affectedVersion = "N/A"
        import CONST
        '''
        jira_dict = {'project': {'key': project}, 'issuetype': {'name': issue_type}, 'priority': {'name': priority},
                     'versions': [{'name': affectedVersion}], 'labels': [label],
                     'customfield_12500': {'value': miui_type}, 'customfield_12600': [{'value': android_version}],
                     'customfield_12700': {'value': jira_reproductivity}, 'customfield_12926': [apk_version], 'summary': summary,
                     'description': jira_description, 'components': [{'name': component}], "assignee": {"name": assignee}}
        '''
        jira_dict = {'project': {'key': project}, 'issuetype': {'name': issue_type}, 'priority': {'name': priority},
                     'labels': [label, "V"+apk_version.split("-")[0][0:4]+"0online"],
                     'customfield_15101': {'value': miui_type}, 'customfield_15102': {'value': JiraConfig.ANDROID},
                     'customfield_15100': {'value': jira_reproductivity}, 'customfield_15106': apk_version,
                     'summary': summary,
                     'description': jira_description,
                     "assignee": {"name": assignee}}
        new_jira = self.jira.create_issue(fields=jira_dict)
        try:
            if new_jira:
                jira_id = new_jira.key
                # print("create jira: " + str(jira_id))
                # 添加附件,默认不添加
                self.add_attachment(jira_id, json_obj)
                # self.add_watcher(jira_id)
                return JiraConfig.JIRA_STATE_NEW_JIRA, jira_id
        except Exception as e:
            traceback.print_exc()
        return JiraConfig.JIRA_STATE_ERROR

    def _is_open(self, status):
        if str(status) == JiraConfig.STATUS_OPEN_CHINESE:
            return True
        elif str(status) == JiraConfig.STATUS_OPEN_ENGLISH:
            return True
        elif str(status) == JiraConfig.STATUS_REOPEN_CHINESE:
            return True
        elif str(status) == JiraConfig.STATUS_REOPEN_ENGLISH:
            return True
        return False

    def get_jira_project(self, json):
        """根据json内容,确定jira project,默认返回MIUI,业务组可根据不同需求实现此方法"""
        return JiraConfig.JIRA_PROJECT_XIAOAI

    def get_issue_type(self, json_obj):
        """根据json内容,确定jira类型,默认返回Bug/故障,业务组可根据不同需求实现此方法"""
        return JiraConfig.ISSUE_TYPE_BUG_ENGLISH

    def get_jira_priority(self, json_obj):
        """根据json内容,确定jira优先级,默认返回major,业务组可根据不同需求实现此方法"""
        return JiraConfig.JIRA_PRIORITY_MAJOR_ENGLISH

    def get_jira_reproductivity(self, json_obj):
        """根据json内容,获取是必现问题还是偶现问题,默认返回必现,业务组可根据不同需求实现此方法"""
        return JiraConfig.ISSUE_APPEARING_CERTAIN

    def generate_jira_desc(self, json_obj):
        """根据json内容,生成Jira的描述,,默认直接使用json数据中的desc对应字段,业务组可根据不同需求实现此方法"""
        return json_obj[JiraConfig.JSON_DESC_KEY].strip()

    def get_jira_miui_type(self, json_obj):
        """根据json内容,生成Jira问题类别-MIUI,默认返回功能 Functionality,业务组可根据不同需求实现此方法"""
        return JiraConfig.ISSUE_MIUI_FUNCTION_TYPE

    def search_issues(self, json_obj):
        """根据json内容搜索Jira,默认用label和comment搜索,业务组可根据不同需求实现此方法"""
        label = json_obj[JiraConfig.JSON_LABEL_KEY].strip()
        package = json_obj[JiraConfig.JSON_PACKAGE_KEY].strip()
        component = self.get_jira_component(package)
        summary = json_obj[JiraConfig.JSON_SUMMARY_KEY]
        try:
            _jql_str = 'labels = ' + label + ' AND summary ~ '+summary.split('"')[1]#+' AND component = ' + component
            # print(_jql_str)
            return self.jira.search_issues(jql_str=_jql_str)
        except Exception as e:
            # print(str(e))
            return []
            # print('search error: ' + str(e))

    def exist_similar_jira(self, json_obj, jira_issue):
        """根据json内容判断是否跟某个Jira相类似,默认比较label和components,业务组可根据不同需求实现此方法"""
        label = json_obj[JiraConfig.JSON_LABEL_KEY].strip()
        package = json_obj[JiraConfig.JSON_PACKAGE_KEY].strip()
        component = self.get_jira_component(package)
        if label in jira_issue.fields.labels:
            for comp in jira_issue.fields.components:
                if comp.name == component:
                    return True
        return False

    def update_exist_jira(self, json_obj, exist_jira):

        """根据json内容更新已存在的Jira,默认是在已存在的Jira上u加comment,如何Jira已关闭,则重新open,业务组根据实际需求实现update的逻辑"""
        try:
            status = str(exist_jira.fields.status)
            jira_id = exist_jira.key
            # print("update jira: " + str(jira_id))
            # jira_description = self.generate_jira_desc(json_obj)
            _new_comment = "小爱同学："+json_obj[JiraConfig.JSON_APP_VERSION_KEY] + "出现相似问题，请关注"
            if not self._is_open(status):
                # 重新打开Jira
                try:
                    self.jira.transition_issue(exist_jira, JiraConfig.ISSUE_OPEN)
                except Exception as e:
                    pass
                # 添加Comment
                self.jira.add_comment(jira_id, _new_comment)
                # 添加附件图片
                self.add_attachment(jira_id, json_obj)

        except Exception as e:
            # print('update_exist_jira error:' + str(e))
            return False
        return True

    def add_watcher(self, jira_id):
        """业务组根据实际需求添加Jira的watcher,默认添加作者"""
        self.jira.add_watcher(jira_id, JiraConfig.JIRA_USERNAME)

    def compare_priority(self, priority1, priority2):
        """priority1优先级高于priority2返回True"""
        if priority1 == '' or str(priority1).strip() == '':
            return False
        if priority2 == '' or str(priority2).strip() == '':
            return True
        priority1_int = 0
        priority2_int = 0
        priority1 = str(priority1).strip()
        priority2 = str(priority2).strip()
        if priority1 == JiraConfig.JIRA_PRIORITY_MINOR_CHINESE or priority1 == JiraConfig.JIRA_PRIORITY_MINOR_ENGLISH:
            priority1_int = 0
        if priority1 == JiraConfig.JIRA_PRIORITY_MAJOR_CHINESE or priority1 == JiraConfig.JIRA_PRIORITY_MAJOR_ENGLISH:
            priority1_int = 1
        if priority1 == JiraConfig.JIRA_PRIORITY_CRITICAL_CHINESE or priority1 == JiraConfig.JIRA_PRIORITY_CRITICAL_ENGLISH:
            priority1_int = 2
        if priority1 == JiraConfig.JIRA_PRIORITY_BLOCKER_CHINESE or priority1 == JiraConfig.JIRA_PRIORITY_BLOCKER_ENGLISH:
            priority1_int = 3
        if priority2 == JiraConfig.JIRA_PRIORITY_MINOR_CHINESE or priority2 == JiraConfig.JIRA_PRIORITY_MINOR_ENGLISH:
            priority2_int = 0
        if priority2 == JiraConfig.JIRA_PRIORITY_MAJOR_CHINESE or priority2 == JiraConfig.JIRA_PRIORITY_MAJOR_ENGLISH:
            priority2_int = 1
        if priority2 == JiraConfig.JIRA_PRIORITY_CRITICAL_CHINESE or priority2 == JiraConfig.JIRA_PRIORITY_CRITICAL_ENGLISH:
            priority2_int = 2
        if priority2 == JiraConfig.JIRA_PRIORITY_BLOCKER_CHINESE or priority2 == JiraConfig.JIRA_PRIORITY_BLOCKER_ENGLISH:
            priority2_int = 3
        if priority1_int > priority2_int:
            return True
        return False

    def __get_file_size(self, file_path):
        # file_path = unicode(file_path,'utf8')
        fsize = os.path.getsize(file_path)
        # print("file_path: %s fsize: %s " % (file_path, str(fsize)))
        fsize = fsize / float(1024 * 1024)
        return round(fsize, 2)

    def __make_zip_file(self, file_path):
        dir_name = os.path.dirname(file_path)
        base_name = os.path.basename(file_path)
        tar_file_name = dir_name + "/" + base_name + ".zip"
        f = zipfile.ZipFile(tar_file_name, 'w', zipfile.ZIP_DEFLATED)
        f.write(file_path, base_name)
        f.close()
        return tar_file_name

    def add_attachment(self, jira_id, json_obj):
        self.add_attachment_impl(jira_id, json_obj[JiraConfig.JSON_ATTACHMENT_FILE_KEY])

    def add_attachment_impl(self, jira_id, file_path):
        if not jira_id or not file_path:
            return
        if not os.path.exists(file_path):
            #print("file %s not exist " % file_path)
            return
        if self.__get_file_size(file_path) > 20:
            #print("file %s size is larger than 20MB, and it will be compressed" % file_path)
            file_path = self.__make_zip_file(file_path)
        file_dir = ' "file=@' + file_path + '" '
        add_attachment_jira_url = '%s:%s%s%s%s' % (
        JiraConfig.JIRA_HOST, JiraConfig.JIRA_PORT, JiraConfig.JIRA_REST_PATH, jira_id, '/attachments')
        _cmd = 'curl -D- -u ' + JiraConfig.JIRA_USERNAME + ':' + JiraConfig.JIRA_PASSWORD + ' -X POST -H "X-Atlassian-Token: no-check" -F  '\
            + file_dir + add_attachment_jira_url + ' > ' + os.path.dirname(__file__) + "/" + JiraHelper.ADD_ATTACHMENT_LOG_FILE
        subprocess.Popen(_cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()

    def __write_errors(self, info):
        self.error_file.write(info)
        self.error_file.write('\n')


if __name__ == "__main__":
    JiraHelper()