# -*- coding:utf-8 -*-

import getopt
import json
import os
import re
import sys
import time
import traceback
import unittest
import subprocess
import socket

import requests

import CONST
from fds_utils import fds_utils


import HTMLTestRunner

rootPath = os.path.abspath(os.path.dirname(__file__))
record = time.strftime("%Y-%m-%d_%H-%M-%S")
spath = os.path.join(rootPath, "report", "test_" + record)
jsonFile = os.path.join(rootPath, "project.json")
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "test", "test_mp"))
filter_file = "test_guide.txt"

with open(jsonFile, "r") as f:
    config = json.load(f)

def get_guide_queries():
    queries = []
    rq_url = "http://admin.ai.srv/api/functionGuide/online/test"
    result = requests.get(rq_url).text
    # print(result)
    rq = json.loads(result)
    for q in rq["queries"]:
        query = q["query"].replace("", "").replace("》", "") if "《" in q["query"] else q["query"]

        queries.append(query.replace(" ", ""))

    return queries


def generate_test():
    query_to_case = generate_query_to_case(root_dir)

    with open(query_to_case, "r", encoding="utf-8") as f:
        test_cases = json.load(f)
    queries = get_guide_queries()
    print("获取引导query总数为：" + str(len(queries)))

    with open(os.path.join(rootPath, filter_file), "w") as f:  # 初始化文件
        f.write("")
    for q, _case_id in test_cases.items():
        for _q in queries:

            if _q in q:  # q 为 case 集合中的query句式，可能配有多种句式
                with open(os.path.join(rootPath, filter_file), "a") as f:
                    f.write("\n".join(_case_id) + "\n")
                print(_q + " : " + q)
                queries.remove(_q)

            elif _q in "截图|截屏":
                _case_id = "test_mp.internal-platform.test_internal_platform.test_screenshot_0_charge"
                with open(os.path.join(rootPath, filter_file), "a") as f:
                    f.write(_case_id + "\n")

                queries.remove(_q)
    print("未对应测试集合query数目：" + str(len(queries)))
    print(queries)
    return os.path.join(rootPath, filter_file)


def generate_query_to_case(root_dir):
    '''
    :param root_dir: test case 根目录
    :return: 根目录下所有用例的 query :[case id] 对应
    '''
    case_set = dict()
    # root_dir = os.path.join(os.path.dirname(__file__), "test", "test_mp")
    print(root_dir)
    for root, dirs, files in os.walk(root_dir):
        _root = os.path.split(root)[-1]
        # print(_root)
        for file in files:

            if "__" not in file:
                if file.endswith(".py") and "out_query" not in file:
                    file_path = os.path.join(root, file)
                    # print(file_path)
                    for _root, _dirs, _files in os.walk(os.path.dirname(file_path)):
                        for json_file in _files:

                            if json_file.endswith(".json"):
                                # print(json_file)
                                json_file_path = os.path.join(_root, json_file)
                                # print(json_file_path)
                                with open(json_file_path, "r", encoding="utf-8") as jf:
                                    test_cases = json.load(jf)
                                    for i, test_case in enumerate(test_cases):
                                        try:
                                            case_id = test_case["id"]
                                            case_query = test_case["case"]["query"]
                                            _file = file.replace(".py", "")
                                            # print(_file)
                                            test_id = file_path.split("test/")[-1][:-2].replace("/",
                                                                                                ".") + _file + "_" + str(
                                                i) + "_" + case_id
                                            if isinstance(case_query, list):
                                                for q in case_query:
                                                    if isinstance(q, str):
                                                        if "|" in q:
                                                            for _q in q.split("|"):
                                                                # print(_q)

                                                                case_query = _q
                                                                if case_query in case_set.keys():
                                                                    # print(case_query)
                                                                    _value = case_set[case_query] + [test_id]
                                                                    case_set[case_query] = _value
                                                                    # print(case_set[case_query])

                                                                else:
                                                                    case_set[case_query] = [test_id]
                                                        else:
                                                            case_query = q
                                                            break
                                                    # _file = file.replace(".py", "")
                                                    # # print(_file)
                                                    # test_id = file_path.split("test/")[-1][:-2].replace("/",
                                                    #                                                     ".") + _file + "_" + str(i) + "_" + case_id
                                                    # print(test_id)
                                                if case_query in case_set.keys():
                                                    # print(case_query)
                                                    _value = case_set[case_query] + [test_id]
                                                    case_set[case_query] = _value
                                                    # print(case_set[case_query])

                                                else:
                                                    case_set[case_query] = [test_id]
                                                # print(case_set[case_query])
                                        except Exception as e:
                                            continue

    json_obj = json.dumps(case_set, ensure_ascii=False)
    with open(os.path.join(root_dir, "query_to_case.json"), "w", encoding="utf-8") as f:
        f.write(json_obj)
    return os.path.join(root_dir, "query_to_case.json")

def testSuit(tag=""):
    case_num = 0
    suite = unittest.TestSuite()
    filter_file = generate_test()
    with open(filter_file, "r") as f:
        for line in f.readlines():
            line = line.strip()
            if line[0] != "#" and len(line) != 0:
                li = line.split(".")
                m = ".".join(li[:-1])
                # print(m)
                if len(m) > 0:
                    try:
                        test_module = __import__(".".join(["test", m]), {}, {}, ["test"])
                        suite.addTest(test_module.TestScript(li[-1]))
                        case_num += 1
                    except Exception as e:
                        traceback.print_exc()
    print("plan to execute :" + str(case_num) + " test cases")
    return suite


def changeConfig(A, B):
    f = open(jsonFile, "r")
    s = f.read()
    s = s.replace(A, B)
    f.close()
    p = open(jsonFile, "w+")
    p.write(s)
    p.close()


def switch_test_env(sn, env):
    xiaoai_ver_code = subprocess.Popen("adb -s %s shell \"dumpsys package com.miui.voiceassist |grep versionCode\"" % sn, shell=True,
                           stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE).communicate()[0].strip().split(b" ")[0].split(b"=")[1].decode("utf8")

    xfolder = "/sdcard/aisdk/" if int(xiaoai_ver_code) < 303006000 else "/sdcard/MIUI/debug_log/com.miui.voiceassist/dev_env/"  # 根据版本号适配环境切换路径


    res = subprocess.Popen("adb -s %s shell rm -rf " % sn + xfolder, shell=True,
                           stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE).communicate()[0]
    subprocess.Popen("adb -s %s shell am force-stop com.miui.voiceassist" % sn, shell=True,
                     stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE).communicate()
    try:
        if env == "staging":
            res = subprocess.Popen("adb -s %s shell mkdir -p " % sn + xfolder + "staging_on", shell=True, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE).communicate()[0]
            subprocess.Popen("adb -s %s shell am force-stop com.miui.voiceassist" % sn, shell=True,
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE).communicate()

            print("测试环境切换到" + env + "：" + res.decode("utf8"))
        elif env == "preview":
            res = subprocess.Popen("adb -s %s shell mkdir -p " % sn + xfolder + "preview_on",
                                   shell=True, stdout=subprocess.PIPE,stderr=subprocess.PIPE).communicate()[0]
            subprocess.Popen("adb -s %s shell am force-stop com.miui.voiceassist" % sn,
                             shell=True,
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE).communicate()

            print("测试环境切换到" + env + "：" + res.decode("utf8"))
        elif env == "production":
            print("测试环境切换到" + env)
        else:
            print("请选择正确的测试环境：production/preview/staging")
            sys.exit(1)
    except Exception as e:
        print("测试环境切换异常："+str(e))
        sys.exit(1)


def wireless_adb(ip):
    compile_ip = re.compile('^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')
    if compile_ip.match(ip):
        res = subprocess.Popen("adb connect %s" % ip, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0].decode("utf-8").strip()
        if "unable" in res:
            print("连接失败："+res)
            return False
        else:
            print("连接成功：" + res)
            return True
    else:
        print("ip地址格式有误")
        return False


def get_host_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()

    return ip


def toRun(tag="", loop=1):
    changeConfig("\"screencap\":\"no\"", "\"screencap\":\"yes\"")
    from aw import CONFIG
    sn = CONFIG["device"]["DUT"]["sn"]
    switch_test_env(sn, CONFIG["test_env"])

    res = os.popen("adb -s %s root" % sn).read().strip() if sn else os.popen("adb root").read().strip()# 已root手机获取adb root权限
    print(res)
    res1 = os.popen("adb -s %s shell \"rm -rf /sdcard/nlp_track.txt\"" % sn).read().strip() if sn else os.popen(
        "adb shell \"rm -rf /sdcard/nlp_track.txt\"").read().strip()  # 删除nlp_track.txt
    print(res1)
    with open(os.path.join(rootPath, "project.log"), 'w+') as f:
        f.write(spath)
    #     print >>f,spath
    if not os.path.exists(spath):
        os.makedirs(spath)
    # 删除一个月前的log
    _date = record.split("_")[0].split("-")
    _year, _month, _day =_date[0], _date[1], _date[2]
    if int(_day) >= 28:
        if _month == "01":
            d_year, d_month = str(int(_year) - 1), "12"
        elif _month == "11":
            d_year, d_month = _year, "10"
        elif _month == "12":
            d_year, d_month = _year, "11"
        else:
            d_year, d_month = _year, "0" + str(int(_month) - 1)
        print("sudo rm -rf " + spath.replace(record, "-".join([d_year, d_month, "*"])))
        subprocess.Popen("sudo rm -rf " + spath.replace(record, "-".join([d_year, d_month, "*"])), shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    print("Report saved to :" + spath)
    for i in range(loop):
        filename = os.path.join(spath, CONFIG["project"] + "_test_report_" + str(i) + ".html")
        # print("ln -s "+os.path.split(filename)[0] + " /home/yanglikai/uwsgi_env/mysite/report/")
        fp = open(filename, 'wb')
        # runner = unittest.TextTestRunner()
        if tag not in CONST.NOT_MI_DEVICE:
            runner = HTMLTestRunner.HTMLTestRunner(stream=fp, title="小爱客户端自动测试报告", description="测试机型：" + CONFIG["project"] + " 小爱版本：" + CONFIG["xiaoai_ver"] + " 测试环境：" + CONFIG["test_env"],
                                                verbosity=2)
        else:
            runner = HTMLTestRunner.HTMLTestRunner(stream=fp, title="小爱Lite自动测试报告", description="测试机型：" + CONFIG["project"] + " 小爱版本：" + CONFIG["xiaoai_ver"] + " 测试环境：" + CONFIG["test_env"],
                                                verbosity=2)
        runner.run(testSuit(tag))
        # runner.run(unittest.defaultTestLoader.discover("test", pattern="*.py", top_level_dir=None))
        fp.close()
        server_ip = get_host_ip() #获取当前ip生成报告链接
        if tag and server_ip == CONST.WORK_SERVER["ip_1"]:  # tag不为空时，框架会将测试报告软链接到nginx服务器下，实现网页访问报告
            subprocess.Popen("ln -s "+os.path.split(filename)[0] + " /home/yanglikai/uwsgi_env/mysite/report/", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            print("TestReport:http://" + CONST.WORK_SERVER["ip_1"] +"/report/" + str(os.path.split(filename)[0].split("/")[-1]) + "/" + str(os.path.split(filename)[1]))
        elif tag and server_ip == CONST.WORK_SERVER["ip_2"]:
            subprocess.Popen("ln -s " + os.path.split(filename)[0] + " /var/www/html/report/", shell=True,stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            print("TestReport:http://" + CONST.WORK_SERVER["ip_2"] + "/report/" + str(os.path.split(filename)[0].split("/")[-1]) + "/" + str(os.path.split(filename)[1]))
    # os.popen("adb -s %s pull /sdcard/nlp_track.txt " % sn + os.path.join(spath, "nlp_track_%s.txt" % sn)).read().strip() if sn else os.popen(
    #     "adb pull  /sdcard/nlp_track.txt " + os.path.join(spath, "nlp_track.txt")).read().strip()  # 删除nlp_track.txt
    # dl = fds_utils.upload_file("xiaoai-log", os.path.join(spath, "nlp_track_%s.txt" % sn))
    # print("nlp_trace 下载链接：" + dl)
    changeConfig("\"screencap\":\"yes\"", "\"screencap\":\"no\"")


def main(argv):
    sn = ""
    _tag = ""
    _loop = 1
    try:
        opts, args = getopt.getopt(argv, "hs:l:f:e:p:b:")
    except getopt.GetoptError:
        print('usage:python run.py -s xxxx -l 1 -f mix2s -e staging')
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print('python run.py -s <device serial> -l <test loop> -f <filter file\'s tag name > -e <test environment '
                  'staging or production>')
            sys.exit()
        elif opt == "-s":
            sn = arg
            # 实现adb无线连接
            compile_ip = re.compile('^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')
            if compile_ip.match(sn):
                res = subprocess.Popen("adb connect %s" % sn, shell=True, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE).communicate()[0].decode("utf-8").strip()
                if "unable" in res:
                    print("无线adb连接失败：" + res)
                    return
                else:
                    print("无线adb连接成功：" + res)
                    sn = sn+":5555"

            if os.popen("adb -s %s get-state" % sn).read().strip() == "device":  # 判断设备连接状态
                name = os.popen("adb -s %s shell getprop ro.product.model" % sn).read().strip()
                version = os.popen("adb -s %s shell \"dumpsys package com.miui.voiceassist |grep versionName\"" % sn).read().strip()
                if version == "":
                    version = os.popen("adb -s %s shell \"dumpsys package com.xiaomi.xiaoailite |grep versionName\"" % sn).read().strip()

                xiaoai_ver = version.split(" ")[0].split("=")[1].strip()
                # miui_v = os.popen("adb -s %s shell getprop ro.miui.ui.version.name" % sn).read().strip()
                miui_ver = os.popen("adb -s %s shell getprop ro.build.version.incremental" % sn).read().strip()

                changeConfig("\"xiaoai_ver\":\"" + config["xiaoai_ver"] + "\"", "\"xiaoai_ver\":\"" + xiaoai_ver + "\"")
                changeConfig("\"miui\":\"" + config["miui"] + "\"", "\"miui\":\"" + "MIUI%s" % miui_ver + "\"")
                changeConfig("\"sn\":\"" + config["device"]["DUT"]["sn"] + "\"", "\"sn\":\"" + sn + "\"")
                changeConfig("\"name\":\"" + config["device"]["DUT"]["name"] + "\"", "\"name\":\"" + name + "\"")
                changeConfig("\"log\":\"" + config["log_config"]["log"] + "\"", "\"log\":\"" + "no" + "\"")
            else:
                sys.exit(1)
        elif opt == "-l":
            _loop = arg
        elif opt == "-f":
            _tag = arg
            changeConfig("\"project\":\"" + config["project"] + "\"", "\"project\":\"" + _tag + "\"")
        elif opt == "-e":
            env = arg
            changeConfig("\"test_env\":\"" + config["test_env"] + "\"", "\"test_env\":\"" + env + "\"")
        elif opt == "-p":
            _post = arg
            changeConfig("\"post_result\":\"" + config["result_config"]["post_result"] + "\"", "\"post_result\":\"" + _post + "\"")
            # changeConfig("\"send_msg\":\"" + config["result_config"]["send_msg"] + "\"", "\"send_msg\":\"" + _post + "\"")
        elif opt == "-b":
            _branch = arg
            changeConfig("\"xiaoai_branch\":\"" + config["xiaoai_branch"] + "\"",
                         "\"xiaoai_branch\":\"" + _branch + "\"")
            # changeConfig("\"send_msg\":\"" + config["result_config"]["send_msg"] + "\"", "\"send_msg\":\"" + _post + "\"")

    if len(sn) == 0:
        print("sn不能为空")
        return
    toRun(tag=_tag, loop=int(_loop))


if __name__ == "__main__":
    # generate_test()
    main(sys.argv[1:])
    # toRun()