# -*- coding:utf-8 -*-
import getopt
import sys

import CONST
from jira_utils.jira_source import JiraSource
from jira_utils.jira_helper import JiraHelper


def get_jira(data):
    source = JiraSource(data["summary"], data["label"], data["package"], data["app_version"],
                                    data["desc"], data["affected_version"], data["android_version"],
                                    data["file_path"], data["assignee"])
    return JiraHelper().start_jira(source)

def main(argv):
    query = ""
    _xiaoai_ver = ""
    _dev_name = ""
    _miui_ver = ""
    _file_path = ""
    assginee = ""

    try:
        opts, args = getopt.getopt(argv, "q:v:d:m:f:p:")
    except getopt.GetoptError:
        sys.exit(2)
    for opt, arg in opts:
        if opt == "-q":
            query = arg
        elif opt == "-v":
            _xiaoai_ver = arg
        elif opt == "-d":
            _dev_name = arg
        elif opt == "-m":
            _miui_ver = arg.strip()[4:]
        elif opt == "-f":
            _file_path = arg
        elif opt == "-p":
            assginee = arg
            if "(" in assginee:
                assginee = assginee.split("(")[-1][:-1]
    _info_jira = {
        "summary": '【语音助手】跟小爱说："' + query + '", 未完成指定操作',
        "label": "自动测试发现",
        "package": "com.miui.voiceassist",
        "app_version": _xiaoai_ver,
        "desc": "【Steps】跟小爱说：%s\n【Actual result】小爱未完成指定操作\n【Expected result】小爱完成指定操作\n【Sample "
                "Info】%s\n【Reproducibility】\n【Remarks】\n【Contact】杨立凯 15313974070" % (
                    query, _dev_name + " " + _miui_ver),
        "affected_version": _miui_ver,
        "android_version": "8.0",
        "file_path": _file_path,
        "assignee": assginee
    }
    try:
        status, jira_id = get_jira(_info_jira)
        jira_url = "http://jira.n.xiaomi.com/browse/" + jira_id
        print(jira_url)

    except Exception as e:
        print(str(e))
        jira_url = ""
    from alarm_utils import FalconCli
    tag = "domain=xiaoaiApp,device=" + _dev_name + ",query=" + query + ",result=Failed,jira_id=\"" + jira_url+"\""
    FalconCli().send_jira_url(tag)


if __name__ == "__main__":
    main(sys.argv[1:])
