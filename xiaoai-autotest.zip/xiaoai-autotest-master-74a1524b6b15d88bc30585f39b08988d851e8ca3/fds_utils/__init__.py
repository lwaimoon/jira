#!/usr/bin/env python
# -*- coding:utf8 -*-
'''
对小米融合云接口的功能封装
'''
import json
# pip install galaxy-fds-sdk
from fds import GalaxyFDSClient, GalaxyFDSClientException
from fds.model.fds_object_metadata import FDSObjectMetadata
import glob
import os

class fds_utils(object):
    def __init__(self):
        self.XIAOMI_ACCESS_KEY_ID = "AKB5EQRQHBDVGUP7B7"
        self.XIAOMI_SECRET_ACCESS_KEY = "3PClVJ8ooSAtCOHYkWTjRH/brLdfc2f65xy4oJ9k"
        # endpoint is auto-read from ~/.config/xiaomi/config
        # 如果没有config文件，手动新建一个内容如下
        # {
        #     "xiaomi_access_key_id": "AKB5EQRQHBDVGUP7B7",
        #     "xiaomi_cloudml_endpoint": "https://cnbj2-cloud-ml.api.xiaomi.net",
        #     "xiaomi_fds_endpoint": "cnbj1-fds.api.xiaomi.net",
        #     "xiaomi_secret_access_key": "3PClVJ8ooSAtCOHYkWTjRH/brLdfc2f65xy4oJ9k"
        # }
        self.client = GalaxyFDSClient(self.XIAOMI_ACCESS_KEY_ID, self.XIAOMI_SECRET_ACCESS_KEY)

    def upload_file(self, bucket_name, filename):
        try:
            if os.path.isfile(filename):
                # print(filename.split('/')[-1])
                with open(filename, 'rb') as f:
                    data = f.read()
                with open(os.path.join(os.path.dirname(__file__), os.path.pardir, "project.json")) as f:
                    DATA = json.load(f)
                path_to = DATA["project"]+"_"+filename.split('/')[-1]
                # metadata = FDSObjectMetadata()
                # metadata.add_header('x-xiaomi-meta-mode', '33188')
                res = self.client.put_object(bucket_name, path_to, data)
                # print('Put Object: ', res.signature, res.expires)
                self.client.set_public(bucket_name, path_to)
                # print('Set public', path_to)
                dl_url = self.client.generate_download_object_uri(bucket_name, path_to)
                return dl_url.replace("https", "http").replace("cnbj1-fds", "cnbj1.fds").replace(".net", ".com")  #返回外网访问地址
        except GalaxyFDSClientException as e:
            print(e.message)
            return ""

    def delete_objects_and_bucket(self, bucket_name):
        if self.client.does_bucket_exist(bucket_name):
            for obj in self.client.list_all_objects(bucket_name, delimiter=""):
                # print(obj.object_name)
                self.client.delete_object(bucket_name, obj.object_name)
            # client.delete_bucket(bucket_name)

fds_utils = fds_utils()

# fds_utils.delete_objects_and_bucket("bvt-test-result")