# -*- coding:utf-8 -*-
import os

LOCKPW = "0000"
APP = {
    "微信": "com.tencent.mm",
    "腾讯视频": "com.tencent.qqlive",
    "爱奇艺": "com.qiyi.video",
    "优酷": "com.youku.phone",
    "支付宝": "com.eg.android.AlipayGphone",
    "QQ音乐": "com.tencent.qqmusic",
    "qq音乐": "com.tencent.qqmusic",
    "酷狗音乐": "com.kugou.android",
    "网易云音乐": "com.kugou.android",
    "摩拜单车": "com.mobike.mobikeapp",
    "ofo共享单车": "so.ofo.labofo",
    "喜马拉雅FM": "com.sdu.didi.psnger",
    "喜马拉雅": "com.sdu.didi.psnger",
    "滴滴出行": "com.ximalaya.ting.android",
    "QQ": "com.tencent.mobileqq",
    "qq": "com.tencent.mobileqq",
    "手机淘宝": "com.taobao.taobao",
    "京东": "com.jingdong.app.mall",
    "大众点评": "com.dianping.v1",
    "相机": "com.android.camera",
    "小米视频": "com.miui.video",
    "百度地图": "com.baidu.BaiduMap",
    "高德地图": "com.autonavi.minimap",
    "腾讯地图": "com.tencent.map",
    "时钟": "com.android.deskclock",
    "日历": "com.android.calendar",
    "浏览器": "com.android.browser",
    "微博": "com.sina.weibo",
    "去哪儿": "com.Qunar",
    "音乐": "com.miui.player"
}
RETRY_MAX = 3
RETRY_WAIT_TIME = 5
OFFLINE_EXECUTE_LENGTH = 100
TIMEOUT = 60
DEVICE = {
    "polaris": "MIX2S",
    "sagit": "MI6"
}
NOT_MI_DEVICE = {
    "astarqltechn": "GalaxyA9",
    "G8850": "MLA-TL10"
}
MANAGER = {
    "smartApp": "蒋丽静(jianglijing)",
    "internal-platform": "何声欢(heshenghuan)",
    "mapApp": "刘聪(liucong)",
    "camera": "梁康(liangkang)",
    "openplatform": "熊磊(xionglei)",
    "recommand": "殷松华(yinsonghua)",
    "default": "韩伟(hanwei)",
    "transportTicket": "熊磊(xionglei)"
}

ALARM_FILE = "/home/testspace/alarm_list.txt"

WORK_SERVER = {
    "ip_1": "10.231.57.145",
    "ip_2": "10.231.57.102"
}

ROOT_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
RESOURCE_PATH = os.path.join(ROOT_PATH, "resource")
