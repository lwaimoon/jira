# -*- coding:utf-8 -*-
import json
import tarfile

import requests

import CONST
from aw import CONFIG
import time
import os, sys
from alarm_utils import FalconCli
from functools import reduce
from aw.common import Common, usb_reset
from bs4 import BeautifulSoup

try:
    from logger import Logger
except Exception as e:
    pass
from PIL import Image
import math
import operator
import subprocess

rootPath = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))


def check(func):
    def wrapper(*args, **kwargs):
        flag = func(*args, **kwargs)

        if flag == True:
            if CONFIG["log_config"]["pass"] == "yes" and CONFIG["log_config"]["screencap"] == "yes":
                Checkpoint()._screenShot()
        else:
            Checkpoint().click_pop_window()
            if CONFIG["log_config"]["screencap"] == "yes":
                Checkpoint()._screenShot()
        return flag

    return wrapper


class Checkpoint(Common):
    def __init__(self, sn=CONFIG["device"]["DUT"]["sn"]):
        # global d
        # d = Device(sn)
        super().__init__(sn)
        self.sn = sn
        self.rootPath = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
        self.record = time.strftime("%Y-%m-%d_%H-%M-%S")
        self.jsonFile = os.path.join(self.rootPath, "project.json")

    def get_window_dump(self, retry=3):
        while retry:
            res = self.shell("uiautomator dump")[0].decode("utf8")
            if "UI hierchary dumped to: /sdcard/window_dump.xml" not in res:
                Logger.info("获取界面信息失败：" + res)
                retry -= 1
                time.sleep(2)
                continue
            else:
                self.adbCmd(
                    "pull /sdcard/window_dump.xml " + os.path.abspath(
                        os.path.join(os.path.dirname(__file__), "dump.xml")))
                return True
        else:
            return False

    def webLink(self):
        with open(os.path.join(rootPath, "link.log")) as f:
            web_link = f.read().strip()
        return web_link

    # def config(self):
    #     with open(os.path.join(self.rootPath, "project.json"), "r") as f:
    #         config = json.load(f)
    #     return config

    def catchLog(self):
        with open(os.path.join(self.rootPath, "project.log"), "r") as f:
            savePath = f.readline().strip()
        if CONFIG["log_config"]["log"] == "yes":
            # logPath = os.path.join(savePath, "logs")
            Logger.info("正在抓取LOG...")
            # if not os.path.exists(savePath):
            #     os.makedirs(savePath)
            br_file = os.path.join(savePath, "bugreport.txt")
            self.adb("bugreport >%s" % br_file)
            self.adb("pull /sdcard/last_nlp_response.txt " + os.path.join(savePath, "last_nlp_response.txt"))
            log_tar_gz = os.path.join(savePath, "bugreport_" + self.record + ".tar.gz")
            tar_file = tarfile.open(log_tar_gz, "w:gz")
            tar_file.add(br_file, arcname="bugreport_" + self.record + ".txt")
            try:
                tar_file.add(os.path.join(savePath, "last_nlp_response.txt"), arcname="last_nlp_response.txt")
                os.remove(br_file)
                os.remove(os.path.join(savePath, "last_nlp_response.txt"))
            except Exception as e:
                print("error:" + str(e))
            tar_file.close()
            print("bugreport_" + self.record + ".tar.gz")
            Logger.info("LOG抓取完成")

    # @usb_reset
    # def _screenShot(self):
    #     with open(os.path.join(rootPath, "project.log"), "r") as f:
    #         savePath = f.readline().strip()
    #     if CONFIG["log_config"]["screencap"] == "yes":
    #         record = time.strftime("%Y-%m-%d_%H-%M-%S")
    #         imagepath = "/data/local/tmp/" + record + ".png"
    #         sn = CONFIG["device"]["DUT"]["sn"]
    #         if sn == "None" or sn == "":
    #             subprocess.Popen("adb shell screencap -p " + imagepath, shell=True).wait()
    #             subprocess.Popen("adb pull " + imagepath + " " + os.path.join(savePath, record + ".png"), shell=True,
    #                              stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
    #             print(savePath + "/" + record + ".png")
    #             subprocess.Popen("adb shell rm " + imagepath, shell=True).wait()
    #             with open(os.path.join(rootPath, "link.log"), "w") as f:
    #                 f.write(os.path.join(savePath, record + ".png"))
    #                 # web_link = f.write(savePath.replace("/home/yanglikai/uwsgi_env/mysite", "10.231.55.238")+"/"+record + ".png")
    #
    #             # return os.path.join(savePath, record + ".png")
    #         else:
    #             subprocess.Popen("adb -s %s shell screencap -p " % sn + imagepath, shell=True).wait()
    #             subprocess.Popen("adb -s %s pull " % sn + imagepath + " " + os.path.join(savePath, record + ".png"),
    #                              shell=True,
    #                              stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()
    #             print(record + ".png")
    #             # print(''' <img %(hidde)s src="%(image)s" alt="screen_shot" height="300" width="200"></img>''' % dict(
    #             #     hidde="", image=savePath + "/" + record + ".png"))
    #             subprocess.Popen("adb -s %s shell rm " % sn + imagepath, shell=True).wait()
    #             with open(os.path.join(rootPath, "link.log"), "w") as f:
    #                 f.write(os.path.join(savePath, record + ".png"))
    #                 # web_link = f.write(savePath.replace("/home/yanglikai/uwsgi_env/mysite", "10.231.55.238")+"/"+record + ".png")
    #             # return os.path.join(savePath, record + ".png")

    def muti_check(self, dut, query, check_point):
        results = []
        dut.check_network()  # 网络检查

        if "text" in check_point.keys() and check_point["text"]:
            if isinstance(check_point["text"], list):
                results.append(dut.checkIfExist("检测点:" + str(query), text=check_point["text"][0]))
                for text in check_point["text"][1:]:
                    results.append(dut.checkIfExist("检测点:" + str(query), refresh=False, text=text))
            else:
                results.append(dut.checkIfExist("检测点:" + str(query), text=check_point["text"]))
        if "resource-id" in check_point.keys() and check_point["resource-id"]:
            results.append(dut.checkIfExist("检测点:" + str(query), resourceId=check_point["resource-id"]))
        if "status" in check_point.keys() and check_point["status"]:
            results.append(dut.check_element_status(expected=check_point["status"], id=check_point["resource-id"]))
        if "activity" in check_point.keys() and check_point["activity"]:
            results.append(dut.compare_activity("检测点:" + str(query), target_act=check_point["activity"]))
        if "to_speak" in check_point.keys():
            results.append(dut.check_to_speak(except_word=check_point["to_speak"]))
        if "nd" in check_point.keys() and check_point["nd"]:
            results.append(dut.checkIfNotExist("检测点:" + str(query), text=check_point["nd"]))
        if "query_text" in check_point.keys():
            results.append(dut.check_query("检测点：" + str(query)))
        if "locked" in check_point.keys() and check_point["locked"]:
            res_dic = {
                "true": True,
                "false": False
            }

            results.append(any([self.isScreenLocked(), not self.isScreenON()]) == res_dic[check_point["locked"]])
        print(results)
        if "or" in check_point.keys() and check_point["or"] == "true":
            return any(results)
        return None if None in results and False not in results else all(results)

    def send_fail_message(self, action, query, domain, Checkpoint_DUT):
        # dev_name = Common_DUT.getprop("ro.build.product")
        if isinstance(query, list):
            for item in query:
                if isinstance(item, dict):
                    rm_lst = ["focus"]
                    if list(item.keys())[0] in rm_lst:
                        query.remove(item)
        tag = "app=xiaoaiApp,device=" + CONFIG["device"]["DUT"]["name"] +",result=Failed,env=" + CONFIG["test_env"] + ",xiaoai=" + CONFIG["xiaoai_ver"]
        if len(domain) > 0:
            tag = tag + ",owner=" + CONST.MANAGER.get(domain, CONST.MANAGER["default"])
        if len(query) > 0:
            _query = str(query).replace(",", "->")
            tag = tag + ",query=" + _query
        elif len(action) > 0:
            tag = tag + ",action=" + action
        FalconCli().send_alarm(tag)
        Checkpoint_DUT.catchLog()

    def send_fail_message_lite(self, action, query, Common_DUT, Checkpoint_DUT):
            # dev_name = Common_DUT.getprop("ro.build.product")
            if isinstance(query, list):
                for item in query:
                    if isinstance(item, dict):
                        rm_lst = ["focus"]
                        if list(item.keys())[0] in rm_lst:
                            query.remove(item)
            tag = "domain=xiaoaiApp,device=" + CONFIG["device"]["DUT"]["name"] + ",result=Failed,env=" + CONFIG[
                "test_env"] + ",xiaoai=" + CONFIG["xiaoai_ver"]
            if len(query) > 0:
                _query = str(query).replace(",", "->")
                tag = tag + ",query=" + _query
            elif len(action) > 0:
                tag = tag + ",action=" + action
            FalconCli().send_alarm_lite(tag)
            Checkpoint_DUT.catchLog()

    @check
    def checkIfExist(self, message="检测点：", refresh=True, **keyargs):
        Logger.info(message)
        if refresh:
            retry = CONST.RETRY_MAX
            retry = CONST.RETRY_MAX
            if not self.get_window_dump(retry):
                return None
        with open(os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")), "r", encoding="utf-8") as f:
            content = f.read()
            # print(content)
        target = list(keyargs.keys())[0]
        if target == "resourceId" or target == "id":  # 处理 resource-id 格式参数再python中的识别问题
            target_mask = "resource-id"
        else:
            target_mask = target

        val = keyargs[target]
        if "|" in val:  # 用"|"分割的检测点为或的关系，有一项为True则结果为Pass
            res_lst = []
            for item in val.split("|"):
                if item.strip() in content:
                    print("=".join([target_mask, "\"" + item + "\""]))
                    res_lst.append(True)
                    break
                else:
                    res_lst.append(False)
            Logger.info("Pass | " + target_mask + "=" + val + " | 存在于当前页面") if any(res_lst) else Logger.info("Fail | " + target_mask + "=" + val + " | 不存在于当前页面")
            return any(res_lst)

        else:
            if keyargs[target] in content:
                print("=".join([target_mask, "\"" + keyargs[target] + "\""]))
                Logger.info("PASS | " + target_mask + "=" + keyargs[target] + " | 存在于当前页面")
                return True
            else:
                Logger.info("FAIL | " + target_mask + "=" + keyargs[target] + " | 不存在于当前页面")
                return False


    @check
    def checkIfNotExist(self, message="检测点：", **keyargs):
        Logger.info(message)
        retry = CONST.RETRY_MAX
        if not self.get_window_dump(retry):
            return None
        self.adbCmd(
            "pull /sdcard/window_dump.xml " + os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")))
        with open(os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")), "r", encoding="utf-8") as f:
            content = f.read()
            # print(content)
        target = list(keyargs.keys())[0]
        if target == "resourceId":  # 处理 resource-id 格式参数再python中的识别问题
            target_mask = "resource-id"
        else:
            target_mask = target

        if keyargs[target] in content:
            print("=".join([target_mask, "\"" + keyargs[target] + "\""]))
            Logger.info("FAIL | " + target_mask + "=" + keyargs[target] + " | 存在于当前页面")
            return False
        else:
            Logger.info("PASS | " + target_mask + "=" + keyargs[target] + " | 不存在于当前页面")
            return True

    def click_pop_window(self, flag=0):

        res = self.shell("uiautomator dump")[0].decode("utf8")
        if "UI hierchary dumped to: /sdcard/window_dump.xml" not in res:
            print("获取界面信息失败：" + res)
            return None
        self.adbCmd(
            "pull /sdcard/window_dump.xml " + os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")))
        with open(os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")), "r", encoding="utf-8") as f:
            content = f.read()
        pop_list = ["允许", "确定", "同意", "继续", "同意并继续", "好", "暂不升级", "跳过", "立即体验", "知道了", "我知道了", "更新", "立即开通", "我同意",
                    "查看日志摘要", "接受", "以后再说"]
        for text in pop_list:
            if "text=\"" + text + "\"" in content:
                soup = BeautifulSoup(content, "lxml")
                nodes = soup.find_all("node")
                for node in nodes:
                    if node.get("text") == text:
                        self._screenShot()  # 截图
                        bounds = node.get("bounds").replace("[", "").replace("]", ",").split(",")
                        x, y = (int(bounds[0]) + int(bounds[2])) / 2, (int(bounds[1]) + int(bounds[3])) / 2
                        Logger.info("点击弹框文本："+text)
                        self.shell("input tap " + str(x) + " " + str(y))
                        flag += 1
                        if flag < 5:
                            self.click_pop_window(flag)

    def imageSimilarity(self, image2):

        image1 = self._screenShot()
        image2 = self.rootPath + "\\resource\\image\\" + image2

        image1 = Image.open(image1)
        image2 = Image.open(image2)
        h1 = image1.histogram()
        h2 = image2.histogram()
        SV = math.sqrt(reduce(operator.add, list(map(lambda a, b: (a - b) ** 2, h1, h2))) / len(h1))
        print(SV)
        return SV

    @check
    def checkImage(self, standardImage, similar=0.99):
        """
        1.图片对比
        """
        _dic = {
            1: 0,
            0.99: 10,
            0.9: 50,
        }

        if self.imageSimilarity(standardImage) > _dic[similar]:
            Logger.error("Fail,图片对比失败")
            return False

        else:
            Logger.info("pass,图片对比成功")
            return True

    def getActivity(self):
        try:
            activity = self.shell("\"dumpsys input | grep FocusedApplication\"")[0].decode("utf8").strip().split(": name=")[1]
            return activity
        except Exception as e:
            print(str(e))
            return ""

    @check
    def compare_activity(self, message="检测点", target_act=""):
        current_act = self.getActivity()
        Logger.info("当前页面activity :" + current_act)
        Logger.info("期望页面activity :" + target_act)
        Logger.info(message + ":")
        if "|" in target_act:
            res_lst = []
            for ta in target_act.split("|"):
                if ta in current_act:
                    res_lst.append(True)
                    break
                else:
                    res_lst.append(False)
            Logger.info("PASS | 目标activity存在于当前页面") if any(res_lst) else Logger.info(
                "FAIL | 目标activity不存在于当前页面")
            return any(res_lst)
        else:
            if target_act in current_act:
                Logger.info("PASS | 目标activity存在于当前页面")
                return True
            else:
                Logger.info("FAIL | 目标activity不存在于当前页面")
                return False

    @check
    def check_path(self, path):
        return os.path.exists(path)

    def wait_exist(self, **keyargs):
        res = self.shell("uiautomator dump")[0].decode("utf8")
        if "UI hierchary dumped to: /sdcard/window_dump.xml" not in res:
            print(res)
            return None
        self.adbCmd(
            "pull /sdcard/window_dump.xml " + os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")))
        with open(os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")), "r", encoding="utf-8") as f:
            content = f.read()
            # print(content)
        target = list(keyargs.keys())[0]
        if keyargs[target]:
            if target == "target_act":
                current_act = self.getActivity()
                if keyargs[target] in current_act:
                    # Logger.info("PASS | 目标activity存在于当前页面")
                    return True
            elif target == "text" or target == "resourceId":
                if keyargs[target] in content:
                    # print("=".join([target_mask, "\"" + keyargs[target] + "\""]))
                    # Logger.info("PASS | " + target_mask + "=" + keyargs[target] + " | 存在于当前页面")
                    return True
        return False

    @check
    def check_to_speak(self, except_word, fuzzy=True):
        # return True
        '''
        :param except_word:
        :param fuzzy:True:支持关键字匹配，False:不支持关键字匹配
        :return:
        '''
        #counter = 0
        #print(self.adbCmd("shell ls /sdcard/last_to_speak.txt"))
        #while "No such" in self.adbCmd("shell ls /sdcard/last_to_speak.txt")[0].decode('utf-8').strip():
        #    time.sleep(1)
        #    counter += 1
        #    if counter > 10:
        #        Logger.info("未生成to_speak文件")

        if self.getAppVersionCode("com.miui.voiceassist").split("-")[0] < "303003000":
            return True
        current_word = self.adbCmd("shell cat /sdcard/last_to_speak.txt ")[0].decode('utf-8').strip()
        if "No such file or directory" in current_word:
            return True
        self.adbCmd("shell rm /sdcard/last_to_speak.txt ")
        Logger.info("to speak:" + current_word)
        #self.adbCmd("shell rm -rf /sdcard/last_to_speak.txt ")
        if "$" in current_word:
            Logger.info("FAIL | toSpeak中出现非法字符")
            return False
        if "|" in except_word:
            res_lst = []
            for item in except_word.split("|"):
                res_lst.append(self.check_to_speak(item))
            return any(res_lst)
        Logger.info("期望 toSpeak:" + except_word)
        if except_word == current_word:
            Logger.info("PASS | toSpeak符合预期")
            return True
        else:
            if fuzzy:
                if except_word in current_word:
                    Logger.info("PASS | toSpeak符合预期")
                    return True
            Logger.info("FAIL | toSpeak不符合预期")
            return False

    def check_network(self):
        '''
        过滤网络不好引发的失败， 同时抓起服务故障引发的
        :return: boolean
        '''

        current_network = self.adbCmd("shell \"cat /sdcard/last_error.txt\"")[0].decode('utf-8').strip()
        if len(current_network) == 0 or "No such file or directory" in current_network:
            return True

        self.adbCmd("shell \"rm /sdcard/last_error.txt\" ")

        if "Network error" in current_network:
            Logger.info("网络不太好：" + current_network)
            return True
        elif "offline" in current_network:
            Logger.info("小爱走神了：" + current_network)
            tag = "app=xiaoaiApp,device=" + CONFIG["device"]["DUT"]["name"] + ",env=" + CONFIG[
                "test_env"] + ",xiaoai=" + CONFIG["xiaoai_ver"] + ",error=[小爱走神了%s]" % current_network
            FalconCli().send_alarm_service(tag)
            return True
        else:
            Logger.info("小爱连接Error：" + current_network)
            tag = "app=xiaoaiApp,device=" + CONFIG["device"]["DUT"]["name"] + ",env=" + CONFIG[
                "test_env"] + ",xiaoai=" + CONFIG["xiaoai_ver"] + ",error=[小爱走神了%s]" % current_network
            FalconCli().send_alarm_service(tag)
            return True


    def check_prop(self, prop, except_value):
        Logger.info("检查prop：")
        res = self.shell("getprop " + prop)[0].strip().decode("utf8")
        Logger.info("获取prop结果:" + prop)
        if res == except_value:
            Logger.info("PASS | prop值符合预期")
            return True
        else:
            Logger.info("FAIL | prop值不符合预期")
            return False

    @check
    def check_element_status(self, expected={}, refresh=False, nex=0, **keyargs):
        '''
        usage：Common(DUT).click_element(text="设置", index=1)
        :param index: 指定控件的index， 主要用于多个相同控件在同一界面，0 为第一个，以此类推
        :param keyargs: 界面控件的属性及其对应的值 example： text=“设置”
        :return:
        '''
        Logger.info("检查控件状态：")
        if refresh:
            res = self.shell("uiautomator dump")[0].decode("utf8")
            if "UI hierchary dumped to: /sdcard/window_dump.xml" not in res:
                print(res)
                return None
            self.adbCmd(
               "pull /sdcard/window_dump.xml " + os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")))
        with open(os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")), "r", encoding="utf-8") as f:
            content = f.read()
        soup = BeautifulSoup(content, "lxml")
        nodes = soup.find_all("node")
        key = list(keyargs.keys())[0]
        mask_key = key
        for i, node in enumerate(nodes):
            if key == "id":  # 解决resource-id不能作为key值的问题
                mask_key = "resource-id"

            if node.get(mask_key) == keyargs[key]:
                if nex != 0:
                    node = nodes[i+nex]
                _keey = list(expected.keys())[0]
                status = node.get(list(expected.keys())[0])
                if status == expected[_keey]:
                    Logger.info("PASS | 控件状态 %s 为 %s 符合预期" % (_keey, status))
                    return True
                else:
                    Logger.info("FAIL | 控件状态 %s 为 %s 不符合预期" % (_keey, status))
                    return False
                # value = expected
        else:
            print("没有找到对应的控件状态")
            return False

    @check
    def check_query(self, message="检测点:", **keyargs):
        return True
        Logger.info(message)
        retry = CONST.RETRY_MAX
        if not self.get_window_dump(retry):
            return None
        self.adbCmd(
            "pull /sdcard/window_dump.xml " + os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")))
        current_pkg = self.getActivity()
        current_pkg = current_pkg.strip().split("u0 ")[1]
        current_pkg = current_pkg.strip().split("/")[0]
        # all_query = {"com.android.deskclock": ["倒计时五分钟", "明天早上8点叫我起床", "十分钟后提醒我"],
        #              "com.miui.notes": ["帮我记一下明天打球", "帮我记一下下周一开会", "帮我记一下周末看电影"],
        #              "com.miui.calculator": ["九十九元打八折", "妈妈的妈妈叫什么", "美元汇率", "三十七乘二十八", "一百加二百等于多少", "一米等于多少厘米"],
        #              "com.eg.android.AlipayGphone": ["支付宝转账记录", "支付宝转账", "支付宝付款码", "支付宝扫一扫", "支付宝收款码"],
        #              "com.tencent.mm": ["朋友圈", "微信二维码	", "微信付款码", "微信扫一扫"]
        #              }
        all_query = {
            "com.android.deskclock": [],
            "com.miui.notes": [],
            "com.miui.calculator": [],
            "com.eg.android.AlipayGphone": [],
            "com.tencent.mm": []
        }
        # 获取推荐query
        rq_url = "http://admin.ai.srv/api/functionGuide/online/test"
        result = requests.get(rq_url).text
        # print(result)
        rq = json.loads(result)["queries"]
        for item in rq:
            if item["exe_pkg_name"] in all_query.keys():
                all_query[item["exe_pkg_name"]].append(item["query"])

        print(all_query)
        lists = all_query.get(current_pkg, [])
        if len(lists) == 0:
            return True
        res = self.shell("uiautomator dump")[0].decode("utf8")
        # if "UI hierchary dumped to: /sdcard/window_dump.xml" not in res:
        #     print("---获取界面信息失败：" + res)
        #     return None
        # self.adbCmd(
        #     "pull /sdcard/window_dump.xml " + os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")))
        with open(os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")), "r", encoding="utf-8") as f:
            content = f.read()
            soup = BeautifulSoup(content, "lxml")
            nodes = soup.find_all("node")
            print(nodes)
            for node in nodes:
                if node.get("resource-id") == "com.miui.voiceassist:id/recommend_item_txt":
                    test = node.get("text")
                    test = test.replace("\"", "")
                    Logger.info("推荐query："+test)
                    if test in lists:
                        Logger.info("PASS | 推荐query符合预期")
                        return True
                    else:
                        Logger.info("FAIL | 推荐query不符合预期")
                        return False

            return False


if __name__ == "__main__":
    Checkpoint("2067bad").check_network()
