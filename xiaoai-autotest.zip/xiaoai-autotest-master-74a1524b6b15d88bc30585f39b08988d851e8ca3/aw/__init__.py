import os
import json
import sys
import CONST
import unittest
import time
from parameterized import parameterized, param
try:
    import HTMLTestRunner
except Exception as e:
    print("Import HTMLTestRunner error")

rootPath = os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir))
resourcePath = os.path.join(rootPath, "resource")


def config():
    with open(os.path.join(rootPath, "project.json"), "r") as f:
        return json.load(f)


CONFIG = config()

def set_device_sn(device="DUT"):
    # res = subprocess.Popen("adb devices", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0].decode("utf8")
    res = os.popen("adb devices").read()
    # print(res)
    dev_lst = res.strip().split("\n")[1:]
    dev_status = {}
    for dev in dev_lst:
        dev_info = dev.split("\t")
        if len(dev_info) == 2:
            dev_status[dev_info[0]] = dev_info[1]

    # print(dev_status)
    Sn = CONFIG["device"][device]["sn"]
    # if dut != "None" and dut != "":

    if Sn in list(dev_status.keys()):
        if dev_status[Sn] == "device":
            return Sn
        else:
            print(Sn+":"+dev_status[Sn])
            sys.exit(0)
    elif Sn == "None" or Sn == "":
        if len(list(dev_status.keys())) == 1:
            return None
        else:
            print("设备连接数目与配置文件不一致，请检查！")
            sys.exit(0)

    else:
        print("设备连接状态与配置文件不一致，请检查！")
        sys.exit(0)


DUT = set_device_sn("DUT")
# SUBDUT1 = setDeviceSn("SUBDUT1")
