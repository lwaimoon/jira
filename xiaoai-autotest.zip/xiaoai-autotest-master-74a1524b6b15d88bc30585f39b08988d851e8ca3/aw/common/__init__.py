# -*- coding:utf-8 -*-
'''
Created on 2016.11.25

@author: 杨立凯
'''
import datetime
import json
import os
import random
import subprocess

import fcntl
import traceback

import requests
from bs4 import BeautifulSoup

import CONST
from aw import *
from jira_utils import jira_source
from jira_utils.jira_helper import JiraHelper
from logger import Logger

rootPath = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))

USBDEVFS_RESET = ord('U') << (4 * 2) | 20


def get_teensy():
    """
        Gets the devfs path to a Teensy microcontroller by scraping the output
        of the lsusb command

        The lsusb command outputs a list of USB devices attached to a computer
        in the format:
            Bus 002 Device 009: ID 16c0:0483 Van Ooijen Technische Informatica Teensyduino Serial
        The devfs path to these devices is:
            /dev/bus/usb/<busnum>/<devnum>
        So for the above device, it would be:
            /dev/bus/usb/002/009
        This function generates that path.
    """
    proc = subprocess.Popen(['lsusb'], stdout=subprocess.PIPE)
    out = proc.communicate()[0].decode("utf8")
    lines = out.split('\n')
    dev_lst = []
    for line in lines:
        parts = line.split()
        if len(parts) == 6:
            bus = parts[1]
            dev = parts[3][:3]
            dev_lst.append('/dev/bus/usb/%s/%s' % (bus, dev))
            # print('/dev/bus/usb/%s/%s' % (bus, dev))
    return dev_lst


def send_reset(dev_path):
    """
        Sends the USBDEVFS_RESET IOCTL to a USB device.

        dev_path - The devfs path to the USB device (under /dev/bus/usb/)
                   See get_teensy for example of how to obtain this.
    """
    # print(dev_path)
    fd = os.open(dev_path, os.O_WRONLY)
    try:
        fcntl.ioctl(fd, USBDEVFS_RESET, 0)
        print("USB已重新链接")
    finally:
        os.close(fd)


def reset_teensy():
    """
        Finds a teensy and reset it.
    """
    for dp in get_teensy():
        send_reset(dp)


def usb_reset(func):  # 处理adb异常状态,脚本需sudo下运行方才生效
    def wraper(*args, **kwargs):
        startTime = time.time()
        res = func(*args, **kwargs)
        if (time.time() - startTime >= CONST.TIMEOUT) and (
                ":" not in CONFIG["device"]["DUT"]["sn"]):  # 命令执行超时且非无线adb连接的情况下执行usb状态重置
            Logger.info("USB连接异常，正在尝试重新连接")
            try:
                reset_teensy()
                time.sleep(5)
                Common(DUT).adb("root")  # 重新设置adb root权限
            except Exception as e:
                Logger.error(str(e))
            time.sleep(1)
            if res[0] == b"adb connected exception":
                res = func(*args, **kwargs)  # 重试
            time.sleep(1)
        return res

    return wraper


def step(func):
    def wraper(*args, **kwargs):
        func(*args, **kwargs)
        time.sleep(0.5)
        try:
            _screenShot()
        except Exception as e:
            Logger.error(str(e))

    return wraper


@usb_reset
def _screenShot():
    with open(os.path.join(rootPath, "project.log"), "r") as f:
        savePath = f.readline().strip()
    if CONFIG["log_config"]["screencap"] == "yes":
        record = time.strftime("%Y-%m-%d_%H-%M-%S")
        imagepath = "/data/local/tmp/" + record + ".png"
        sn = CONFIG["device"]["DUT"]["sn"]
        if sn == "None" or sn == "":
            subprocess.Popen("adb shell screencap -p " + imagepath, shell=True).wait()
            subprocess.Popen("adb pull " + imagepath + " " + os.path.join(savePath, record + ".png"), shell=True,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate(timeout=CONST.TIMEOUT)
            print(record + ".png")
            # print("<a href=\"" + savePath + "\\" + record + ".png\"" + " target=\"_blank\">点击查看截图</a>")
            subprocess.Popen("adb shell rm " + imagepath).wait()
        else:
            subprocess.Popen("adb -s %s shell screencap -p " % sn + imagepath, shell=True).wait()
            subprocess.Popen("adb -s %s pull " % sn + imagepath + " " + os.path.join(savePath, record + ".png"),
                             shell=True,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate(timeout=CONST.TIMEOUT)
            print(record + ".png")
            subprocess.Popen("adb -s %s shell rm " % sn + imagepath, shell=True).wait()


class Common(object):
    def __init__(self, sn=None):
        self.sn = sn
        self.record = time.strftime("%Y-%m-%d_%H-%M-%S")

    @usb_reset
    def _screenShot(self):
        with open(os.path.join(rootPath, "project.log"), "r") as f:
            savePath = f.readline().strip()
        if CONFIG["log_config"]["screencap"] == "yes":
            record = time.strftime("%Y-%m-%d_%H-%M-%S")
            imagepath = "/data/local/tmp/" + record + ".png"
            sn = CONFIG["device"]["DUT"]["sn"]
            if sn == "None" or sn == "":
                subprocess.Popen("adb shell screencap -p " + imagepath, shell=True).wait()
                subprocess.Popen("adb pull " + imagepath + " " + os.path.join(savePath, record + ".png"), shell=True,
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate(CONST.TIMEOUT)
                print(record + ".png")
                subprocess.Popen("adb shell rm " + imagepath, shell=True).wait()
                with open(os.path.join(rootPath, "link.log"), "w") as f:
                    f.write(os.path.join(savePath, record + ".png"))
                # with open(os.path.join(rootPath, "link.log"), "w") as f:
                #     f.write(os.path.join(savePath, record + ".png"))
                # web_link = f.write(savePath.replace("/home/yanglikai/uwsgi_env/mysite", "10.231.55.238")+"/"+record + ".png")

                return os.path.join(savePath, record + ".png")
            else:
                subprocess.Popen("adb -s %s shell screencap -p " % sn + imagepath, shell=True).wait()
                subprocess.Popen("adb -s %s pull " % sn + imagepath + " " + os.path.join(savePath, record + ".png"),
                                 shell=True,
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate(CONST.TIMEOUT)
                print(record + ".png")
                subprocess.Popen("adb -s %s shell rm " % sn + imagepath, shell=True).wait()
                with open(os.path.join(rootPath, "link.log"), "w") as f:
                    f.write(os.path.join(savePath, record + ".png"))
                # with open(os.path.join(rootPath, "link.log"), "w") as f:
                #     f.write(os.path.join(savePath, record + ".png"))
                # web_link = f.write(savePath.replace("/home/yanglikai/uwsgi_env/mysite", "10.231.55.238")+"/"+record + ".png")
                return os.path.join(savePath, record + ".png")

    def reboot(self):
        self.adbCmd("reboot")
        time.sleep(30)

    def shell(self, cmd):
        return self.adbCmd("shell " + cmd)

    @usb_reset
    def adbCmd(self, cmd, timeout=CONST.TIMEOUT):
        CONST.TIMEOUT = timeout
        try:
            if self.sn == None:
                # Logger.info("adb " + cmd)
                res = subprocess.Popen("adb " + cmd, shell=True, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE).communicate(timeout=timeout)

            else:
                # Logger.info("adb -s %s " % self.sn + cmd)
                res = subprocess.Popen("adb -s %s " % self.sn + cmd, shell=True, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE).communicate(timeout=timeout)
            if "error: device" in res[1].decode("utf-8") and ":5555" in CONFIG["device"]["DUT"]["sn"]:  # 无线adb重连机制
                subprocess.Popen("adb connect " + CONFIG["device"]["DUT"]["sn"].split(":")[0], shell=True,
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE).communicate(timeout=timeout)
                res = self.adbCmd(cmd, timeout=CONST.TIMEOUT)
            return res
        except Exception as e:
            Logger.error(str(e))
            Logger.error("adb 执行超时")
            return (b"adb connected exception", b"")

    def adb(self, cmd):
        try:
            if self.sn == None:
                # Logger.info("adb " + cmd)
                return subprocess.Popen("adb " + cmd, shell=True, stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE).communicate()

            else:
                # Logger.info("adb -s %s " % self.sn + cmd)
                return subprocess.Popen("adb -s %s " % self.sn + cmd, shell=True, stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE).communicate()
        except Exception as e:
            Logger.error(str(e))

    def device_state(self):
        res = self.adb("get-state")[0].decode("utf-8").strip()
        print(res)

    @step
    def startActivity(self, activity_name, timeout=3):
        self.shell("am start -n " + activity_name)
        time.sleep(timeout)
        Logger.info("启动 activity：" + activity_name)

    def launchApp(self, activity_name, timeout=2):
        self.shell("am start -n " + activity_name)
        Logger.info("启动 activity：" + activity_name)
        time.sleep(timeout)

    def goBack(self, num=1):
        for i in range(num):
            self.shell("input keyevent 4")
            time.sleep(1)

    def goBackHome(self):
        for i in range(3):
            self.shell("input keyevent 4")
            time.sleep(0.5)

        self.shell("input keyevent 3")
        current_act = self.getActivity()
        # 强杀前台应用
        if "com.miui.home/.launcher.Launcher" not in current_act:
            pack_name = current_act.split("}}}")[0].split("{")[-1].split("/")[0].split(" ")[-1]
            # print(pack_name)
            self.killApp(pack_name)

    def press(self, key):
        if key == "home":
            self.shell("input keyevent 3")
        elif key == "back":
            self.shell("input keyevent 4")
        elif key == "recent":
            self.shell("input keyevent KEYCODE_MENU")

    def getActivity(self):
        activity = self.shell("\"dumpsys input |grep FocusedApplication\"")[0]
        return activity.decode("utf8")

    def click(self, x, y):
        self.shell("input tap " + str(x) + " " + str(y))

    def swipe(self, start_x, start_y, stop_x, stop_y, steps=100):
        self.shell("input swipe %s %s %s %s %s" % (str(start_x), str(start_y), str(stop_x), str(stop_y), str(steps)))

    def long_click(self, x, y):
        self.swipe(x, y, x + 1, y + 1)

    def open_notification(self):
        x, y = self.getScreenSize()
        self.swipe(0.5 * x, 0.01 * y, 0.5 * x, 0.8 * y, 500)
        Logger.info("打开通知栏")

    def open_negscreen(self):
        self.goBackHome()
        x, y = self.getScreenSize()
        self.swipe(0.01 * x, 0.5 * y, 0.8 * x, 0.5 * y, 500)
        Logger.info("打开负一屏")

    def open_voiceassist(self):
        self.shell(
            "am startservice -n com.miui.voiceassist/com.xiaomi.voiceassistant.VoiceService -a android.intent.action.ASSIST")

    def close_wifi(self):
        self.shell("svc wifi disable")

    def open_wifi(self):
        self.shell("svc wifi enable")

    def close_data(self):
        self.shell("svc data disable")

    def open_data(self):
        self.shell("svc data enable")

    def clearRecentApp(self):
        '''
        1.清理后台应用
        '''
        self.shell("input keyevent KEYCODE_HOME")
        time.sleep(0.5)
        self.shell("input keyevent KEYCODE_MENU")
        time.sleep(1)
        self.click_element(id="com.android.systemui:id/clearAnimView")
        time.sleep(2)

    def click_element(self, index=0, refresh=True, long=False, nex=0, **keyargs):
        '''
        usage：Common(DUT).click_element(text="设置", index=1)
        :param refresh: 是否重新获取页面XML
        :param index: 指定控件的index， 主要用于多个相同控件在同一界面，0 为第一个，以此类推
        :param keyargs: 界面控件的属性及其对应的值 example： text=“设置”
        :return:
        '''
        if refresh:
            retry = CONST.RETRY_MAX
            if not self.get_window_dump(retry):
                return None
        with open(os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")), "r", encoding="utf-8") as f:
            content = f.read()
        soup = BeautifulSoup(content, "lxml")
        nodes = soup.find_all("node")
        bounds_lst = []
        key = list(keyargs.keys())[0]
        mask_key = key
        for i, node in enumerate(nodes):
            if key == "id":  # 解决resource-id不能作为key值的问题
                mask_key = "resource-id"
            elif key == "clazz":
                mask_key = "class"
            elif key == "index":
                mask_key = "index"
            elif key == "content":
                mask_key = "content-desc"

            if node.get(mask_key)[:] == keyargs[key]:
                if nex != 0:
                    node = nodes[i + nex]
                    bounds = node.get("bounds").replace("[", "").replace("]", ",").split(",")
                    bounds_lst.append(bounds)
                else:
                    bounds = node.get("bounds").replace("[", "").replace("]", ",").split(",")
                    bounds_lst.append(bounds)
        if len(bounds_lst) > index:
            target_bounds = bounds_lst[index]

            x, y = (int(target_bounds[0]) + int(target_bounds[2])) / 2, (
                    int(target_bounds[1]) + int(target_bounds[3])) / 2

            self.long_click(x, y) if long else self.click(x, y)
            time.sleep(0.5)

            # self.shell("input tap " + str(x) + " " + str(y))
            print(x, y)
            print("完成点击-->" + str(mask_key) + ":" + str(keyargs[key]))
        else:
            print("没有找到-->" + str(mask_key) + ":" + str(keyargs[key]))

    def putSettings(self, field, modul, mode):
        self.shell("settings put " + field + " " + modul + " " + mode)

    def installApk(self, name, mode=None):
        '''
        1.安装应用
        '''
        path = rootPath + "\\resource\\apks\\" + name
        if mode == None:
            path = rootPath + "\\resource\\apks\\" + name
            self.adbCmd("install " + path)
        else:
            self.adbCmd("install " + mode + " install " + path)

    def uninstallApp(self, pkgName):
        '''
        1.卸载应用
        '''

        self.adbCmd("uninstall " + pkgName)
        Logger.info("卸载应用：" + pkgName)

    def isScreenON(self):
        result = self.shell("dumpsys window policy|grep mAwake")[0].decode("utf8")
        result = result.strip().split("=")[-1]
        # print(result)
        if result == "true":
            return True
        else:
            return False

    def isScreenLocked(self):
        result = self.shell("dumpsys window policy|grep mDreamingLockscreen")[0].decode("utf8")
        result = result.strip().split("mDreamingLockscreen=")[-1].split(" ")[0]
        # print(result)
        if result == "true":
            print("锁屏状态")
            return True
        else:
            return False

    def wakeup(self):
        if not self.isScreenON():
            self.shell("input keyevent 26")
        time.sleep(0.5)

    def unlockScreen(self, password=""):
        x, y = self.getScreenSize()

        if len(password) > 0 and self.isScreenLocked():
            # from aw.checkpoint import Checkpoint
            # if Checkpoint(self.sn).checkIfExist(id="com.miui.voiceassist:id/fm_idle_state_view"):
            self.click(0.6 * x, 0.85 * y)
            self.click_element(text=password[0])
            for w in password[1:]:
                self.click_element(text=w, refresh=False)
        else:
            self.wakeup()
            self.swipe(0.5 * x, 0.9 * y, 0.5 * x, 0.1 * y, 500)
            time.sleep(0.5)

    # @step
    def lockScreen(self):
        '''
        1.按power键锁定屏幕
        '''
        self.shell("input keyevent 26")
        Logger.info("锁屏")

    def inputText(self, text):
        '''
        1.输入文本（中文除外）
        '''
        self.shell("input text " + text)
        self.shell("input keyevent 66")
        Logger.info("输入文本："+text)

    def deleteText(self, text):
        for i in range(len(text)):
            self.shell("input keyevent 67")

        Logger.info("删除文本：" + text)

    def setDefaultIme(self, ime):
        '''
        1.设置默认输入法
        '''
        # adb shell ime list -s 可查看当前手机的输入法列表
        self.shell("ime set " + ime)

    def clearUserData(self, pkgName):
        '''
        1.清除应用数据
        '''
        self.shell("pm clear " + pkgName)

    def getprop(self, pram):

        res = self.shell("getprop " + pram)[0].strip()
        return res.decode("utf-8")

    def getScreenSize(self):
        '''
        1.获取屏幕大小
        '''
        try:
            SS = self.shell("\"dumpsys window displays |grep init=\"")[0].decode("utf8")
            # print(SS)
            SS = SS.strip().split(" ")
            SS = SS[0].split("=")
            SS = SS[1].split("x")
            X = SS[0]
            Y = SS[1]
            return int(X), int(Y)
        except Exception as e:
            traceback.print_exc()
            return 1280, 1920

    def setAirplaneMode(self, mode):
        '''
        1, 设置飞行模式, True为开启,False为关闭
        '''
        mode_dic = {
            "开启": True,
            "关闭": False
        }
        #         self.launchSettings()
        #         self.clickByText("更多连接")
        #         self.switchWidget(mode_dic[mode], "amigo:id/amigo_switchWidget")
        #         self.goBackHome()
        if mode_dic[mode] == True:
            self.shell("settings put global airplane_mode_on 1")
            self.shell("am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true")
        if mode_dic[mode] == False:
            self.shell("settings put global airplane_mode_on 0")
            self.shell("am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false")

    def setScreenTimeout(self, timeout):
        '''
        1,设置屏幕休眠时间
        '''
        _dic = {
            "30min": 1800000,
            "10min": 600000,
            "5min": 300000,
            "2min": 120000,
            "1min": 60000,
            "30sec": 30000,
            "15sec": 15000
        }
        self.shell("settings put system screen_off_timeout " + str(_dic[timeout]))

    def nohupTest(self, jarFile, testCase):
        self.uninstallApp("com.github.uiautomator")
        self.pushFile("jar\\" + jarFile, "/data/local/tmp/" + jarFile)
        if self.sn == None:
            cmd = "adb shell uiautomator runtest " + jarFile + " --nohup -c com.power.test.testCase#" + testCase
        else:
            cmd = "adb -s %s " % self.sn + "shell uiautomator runtest " + jarFile + " --nohup -c com.power.test.testCase#" + testCase
        print(cmd)
        subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        time.sleep(2)

    def execute_nodelist(self, name):
        cmd = "am startservice -a com.xiaomi.voiceassistant.ACTION_TEST_NODELIST_FROM_NETWORK --es  \"nodeId\" \"" + name + "\""
        print(cmd)
        self.shell(cmd)

    def execute_xa(self, query, islite=0, offline=False):
        self.adbCmd("root")
        if isinstance(query, dict):
            key = list(query.keys())[0]
            if key == "text":
                self.click_element(text=query[key])
            elif key == "id":
                self.click_element(id=query[key], index=0)
            elif key == "content":
                self.click_element(content=query[key], index=0)
            elif key == "clazz":
                self.click_element(clazz=query[key], index=0)
            elif key == "id_lc":  # 长按某控件
                self.click_element(id=query[key], long=True)
            elif key == "activity":
                self.launchApp(query[key])
            elif key == "kill":
                self.killApp(query[key])
            elif key == "uninstall":
                self.uninstallApp(query[key])
            elif key == "notification":
                self.open_notification()
            elif key == "negscreen":
                self.open_negscreen()
            elif key == "voiceassist":
                self.open_voiceassist()
            elif key == "lock":
                self.lockScreen()
            elif key == "unlock":
                self.unlockScreen(query[key])
            elif key == "press":
                self.press(query[key])
            elif key == "offline":
                self.close_wifi()
            elif key == "online":
                self.open_wifi()
            elif key == "clear":
                self.clearUserData(query[key])
            elif key == "swipe":
                x, y = self.getScreenSize()
                [start_x, start_y, stop_x, stop_y] = query[key].split(",") if "," in query[key] else [0.5, 0.7, 0.5,
                                                                                                      0.4]
                self.swipe(float(start_x) * x, float(start_y) * y, float(stop_x) * x, float(stop_y) * y)

            elif key == "focus":
                _dict = {
                    "true": True,
                    "false": False
                }
                self.switch_card_window_focus(_dict[query[key]])
        elif islite == 0:

            if "|" in query:
                _query_rd = query.split("|")
                query = _query_rd[random.randint(0, len(_query_rd) - 1)]  # 多句式query随机执行

            if offline == True:
                cmd = "am startservice -n com.miui.voiceassist/com.xiaomi.voiceassistant.VoiceService -a android.intent.action.query.ASSIST --ei use_offline_nlp 2 --es assist_query " + query
                self.shell(cmd)  # 第一次调用接口完成离线功能初始化
                time.sleep(4)
            else:
                cmd = "am startservice -n com.miui.voiceassist/com.xiaomi.voiceassistant.VoiceService -a android.intent.action.query.ASSIST --ei use_offline_nlp 1 --es assist_query " + query
            Logger.info("跟小爱说：" + query)
            # with open("querys.txt", "a+") as q:
            #     q.write(query + "\n")
            self.shell(cmd)
        else:
            cmd = "am startservice -n com.xiaomi.xiaoailite/com.xiaomi.voiceassistant.VoiceService -a android.intent.action.query.ASSIST --es assist_query " + query
            Logger.info("跟小爱说：" + query)
            # with open("querys.txt", "a+") as q:
            #     q.write(query + "\n")
            self.shell(cmd)

    def killUiautomator(self):
        pass
        # try:
        #     pid = self.adbCmd("shell \"ps |grep uiautomator\"")[0].strip().split(b" ")[5]
        # except Exception as e:
        #     pid = None
        # if pid:
        #     self.adbCmd("shell kill " + pid.decode())
        #     # print("uiautomator进程终止")
        # else:
        #     pass
        # print("无uiautomator进程")

    def killXA(self):
        self.shell("am force-stop com.miui.voiceassist")

    def killApp(self, pkgName):
        self.shell("am force-stop " + pkgName)
        time.sleep(2)

    def getAppVersionCode(self, pkgName):
        try:
            version_code = self.shell("\"dumpsys package " + pkgName + " |grep versionCode\"")[0]
            version_code = version_code.strip().split(b" ")[0].split(b"=")[1].decode("utf8")
            return version_code.strip()
        except Exception as e:
            print("获取version_code 失败")
            return ""

    def getAppVersionName(self, pkgName):
        try:
            version_code = self.shell("\"dumpsys package " + pkgName + " |grep versionName\"")[0]
            version_code = version_code.strip().split(b" ")[0].split(b"=")[1].decode("utf8")
            return version_code.strip()
        except Exception as e:
            print("获取version_name 失败")
            return ""

    def post_result(self, param_dic):
        # return
        '''
        param_dic = {
                "NodeId": NodeId,
                "feature": self.app_name,
                "third_app": self.app_name,
                "app_version": self.app_ver,
                "query": test_case["query"],
                "action": test_case["action"],
                "setup": test_case["setup"],
                "result": result_alias[result][0],
                "message": result_alias[result][1]
            }
        '''
        _case = []
        for text in param_dic["query"]:
            if isinstance(text, str):
                _case.append(text)
        query = " | ".join(_case)
        _label = CONFIG["label"]
        _branch = CONFIG["xiaoai_branch"]
        _xiaoai_ver = CONFIG["xiaoai_ver"] if len(CONFIG["xiaoai_ver"]) != 0 else self.getAppVersionName(
            "com.miui.voiceassist")
        # _miui_v = self.getprop("ro.miui.ui.version.name")
        # _miui_ver = self.getprop("ro.build.version.incremental")
        # _miui = CONFIG["miui"] if len(CONFIG["miui"]) != 0 else "%s_%s " % (self.getprop("ro.miui.ui.version.name"), self.getprop("ro.build.version.incremental"))
        _miui = CONFIG["miui"] if len(CONFIG["miui"]) != 0 else "MIUI%s" % self.getprop("ro.build.version.incremental")
        _dev_name = CONFIG["device"]["DUT"]["name"] if len(CONFIG["device"]["DUT"]["name"]) != 0 else self.getprop(
            "ro.product.model")  # self.getprop("ro.build.product")
        # _hard_ver = self.getprop("ro.build.hardware.version")
        if CONFIG["result_config"]["post_result"] == "yes":
            if param_dic["result"] != "Pass":
                with open(os.path.join(os.path.dirname(__file__), os.path.pardir, os.path.pardir, "link.log"),
                          "r") as f:
                    _file_path = f.read().strip()
            else:
                _file_path = ""

            data = {
                "branch": "APP-"+_branch,  # 小爱同学
                "query": query,
                "attach_file": _file_path,
                "manager": CONST.MANAGER.setdefault(param_dic["domain"], "韩伟(hanwei)"),
                "result": param_dic["result"],
                "message": param_dic["message"],
                "dimensions": {
                    "action": param_dic["action"],
                    "hardware": _dev_name,
                    "miui": _miui,
                    "xiaoai": _xiaoai_ver + _label,
                    "third_app": param_dic["third_app"] + "_" + param_dic["app_version"],
                    "domain": param_dic["domain"],
                    "feature": param_dic["feature"],
                    "time": datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "setup": param_dic["setup"]
                }
            }

            # data = {
            #     "id": _xiaoai_ver.replace(".", "").replace("-", "") + "-" + param_dic["NodeId"],
            #     "time": datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
            #     "hardware": {
            #         "name": _dev_name,  # 测试设备名
            #         "version": _hard_ver  # 设备硬件版本
            #     },
            #     "os": {
            #         "name": "miui " + _miui_v,  # MIUI名（MIUI 10）
            #         "version": _miui_ver,  # MIUI 版本
            #     },
            #     "xiaoai_app": {
            #         "name": "小爱同学",  # 小爱同学
            #         "version": _xiaoai_ver  # 小爱版本号
            #     },
            #     "feature": {
            #         "name": param_dic["feature"]},  # 测试用例所属模块
            #     "third_app": {
            #         "name": param_dic["third_app"],  # 测试三方app名
            #         "version": param_dic["app_version"]  # 测试三方app版本号
            #     },
            #     "case": {"action": param_dic["action"], "setup": param_dic["setup"], "query_word": query},  # 测试用例信息（action：功能点，setup：测试条件，query_word:测试query）
            #     "result": param_dic["result"],  # 测试结果
            #     "message": param_dic["message"],  # 备注信息
            #     "domain": {"name": param_dic["domain"]},  # 测试用例所属domain
            #     "jira_url": _file_path,  # 创建jira所需附件路径
            #     "manager": CONST.MANAGER.setdefault(param_dic["domain"], "韩伟(hanwei)")  # 功能点负责人
            # }
            # print(data)
            url = "http://tj-op-mon-web01.kscn:9998/v1/xiaoai/testcase"
            url2 = "http://qp.ai.srv/v1/xiaoai/testcase"
            headers = {'Content-Type': 'application/json'}
            try:
                response = requests.post(url=url, headers=headers, data=json.dumps(data))

                print(response.status_code)

            except Exception as e:
                print("测试环境数据上传失败:" + str(e))

            try:
                response2 = requests.post(url=url2, headers=headers, data=json.dumps(data))
                print(response2.status_code)

            except Exception as e:
                print("正式环境数据上传失败:" + str(e))

    def get_jira(self, data):
        source = jira_source.JiraSource(data["summary"], data["label"], data["package"], data["app_version"],
                                        data["desc"], data["affected_version"], data["android_version"],
                                        data["file_path"])
        return JiraHelper().start_jira(source)

    def common_execute(self, query, wait_time, check_point, Common_DUT, check_point_DUT, offline=False):
        if not isinstance(query, list):
            raise RuntimeError("query 格式错误，应为list格式")
        for i, q in enumerate(query):
            Common_DUT.execute_xa(q, offline=offline)
            if not isinstance(wait_time, list):
                time.sleep(wait_time)
            else:
                try:
                    time.sleep(wait_time[i])
                except Exception as e:
                    time.sleep(wait_time[0])
        return check_point_DUT.muti_check(check_point_DUT, query, check_point)

    def common_execute_offline(self, query, wait_time, to_check, Common_DUT, check_point_DUT, offline=True):
        result = []
        check_point = {}
        if not isinstance(query, list):
            raise RuntimeError("query 格式错误，应为list格式")
        for i, q in enumerate(query):
            Common_DUT.execute_xa(q, offline=offline)
            if not isinstance(wait_time, list):
                time.sleep(wait_time)
            else:
                try:
                    time.sleep(wait_time[i])
                except Exception as e:
                    time.sleep(wait_time[0])
            if to_check == "app_management.open_app.common.open":
                app_name = q.split("打开")[-1]
                check_point = {"activity": CONST.APP.get(app_name, ""), "to_speak": "你还没有安装", "text": "应用商店",
                               "or": "true"}

            elif to_check == "device_control.smart_device.mobile.flashlight":
                if "关" in q:
                    check_point = {"text": ["设置", "手电筒"], "resource-id": "com.miui.voiceassist:id/mobile_control_radio",
                                   "status": {"checked": "false"}}
                if "开" in q:
                    check_point = {"text": ["设置", "手电筒"], "resource-id": "com.miui.voiceassist:id/mobile_control_radio",
                                   "status": {"checked": "true"}}
            # elif to_check == "device_control.internet.mobile.mobile_hot_spot":


        return check_point_DUT.muti_check(check_point_DUT, q, check_point)


    def switch_card_window_focus(self, flag=True):
        if flag:
            res = self.shell("mkdir -p /sdcard/aisdk/float_focus_on")[0].decode("utf8")
            self.killXA()
            Logger.info("卡片切换到可focus状态" + str(res))

        else:
            res = self.shell("rm -rf /sdcard/aisdk/float_focus_on")[0].decode("utf8")
            self.killXA()
            Logger.info("卡片切换到非focus状态" + str(res))

    def end_call(self):
        self.shell("input keyevent KEYCODE_ENDCALL")

    def switch_button(self, expected={}, nex=0, **keyargs):
        '''
        usage：Common(DUT).switch_button(id="xxx", expected={"checked":"true"})
        :param nex:
        :param expected:
        :param keyargs: 界面控件的属性及其对应的值 example： id=“xxx”
        :return:
        '''
        Logger.info("检查控件状态：")
        res = self.shell("uiautomator dump")[0].decode("utf8")
        if "UI hierchary dumped to: /sdcard/window_dump.xml" not in res:
            print(res)
            return None
        self.adbCmd(
            "pull /sdcard/window_dump.xml " + os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")))
        with open(os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")), "r", encoding="utf-8") as f:
            content = f.read()
        soup = BeautifulSoup(content, "lxml")
        nodes = soup.find_all("node")
        key = list(keyargs.keys())[0]
        mask_key = key
        for i, node in enumerate(nodes):
            if key == "id":  # 解决resource-id不能作为key值的问题
                mask_key = "resource-id"

            if key == "content":
                mask_key = "content-desc"

            if node.get(mask_key) == keyargs[key]:
                if nex != 0:
                    node = nodes[i + nex]
                _keey = list(expected.keys())[0]
                status = node.get(list(expected.keys())[0])
                if status == expected[_keey]:
                    Logger.info("控件状态 %s 为 %s " % (_keey, status))
                    return
                else:
                    Common(DUT).click_element(nex=nex, **keyargs)
                    Logger.info("控件状态 %s 已切换为 %s" % (_keey, status))
                    return
                # value = expected
        else:
            print("没有找到对应的控件")

    def litecommon_execute(self, query, wait_time, check_point, Common_DUT, check_point_DUT, retry_time):
        if not isinstance(query, list):
            raise RuntimeError("query 格式错误，应为list格式")
        for i, q in enumerate(query):
            Common_DUT.execute_xa(q, 1)
            if not isinstance(wait_time, list):
                time.sleep(wait_time)
            else:
                try:
                    time.sleep(wait_time[i])
                except Exception as e:
                    time.sleep(wait_time[0])
        return check_point_DUT.muti_check(check_point_DUT, query, check_point)

    def AIkey(self, click_type, query):
        click_types = {"single": "ai_task_single_click", "double": "ai_task_double_click"}
        self.shell(
            "am startservice -n com.miui.voiceassist/com.xiaomi.voiceassistant.SpeechQueryService -a com.miui.voiceassist.query --ei assist_text_shown 2 --es assist_query " + query + " --es voice_assist_start_from_key " +
            click_types[click_type])

    def get_window_dump(self, retry=3):
        while retry:
            res = self.shell("uiautomator dump")[0].decode("utf8")
            if "UI hierchary dumped to: /sdcard/window_dump.xml" not in res:
                Logger.info("获取界面信息失败：" + res)
                retry -= 1
                time.sleep(2)
                continue
            else:
                self.adbCmd(
                    "pull /sdcard/window_dump.xml " + os.path.abspath(
                        os.path.join(os.path.dirname(__file__), "dump.xml")))
                return True
        else:
            return False

    def get_elements(self, name, refresh=True):
        '''
        usage：Common(DUT).click_element(text="设置", index=1)
        :param refresh: 是否重新获取页面XML
        :param index: 指定控件的index， 主要用于多个相同控件在同一界面，0 为第一个，以此类推
        :param keyargs: 界面控件的属性及其对应的值 example： text=“设置”
        :return:
        '''
        if refresh:
            retry = CONST.RETRY_MAX
            if not self.get_window_dump(retry):
                return None
        with open(os.path.abspath(os.path.join(os.path.dirname(__file__), "dump.xml")), "r", encoding="utf-8") as f:
            content = f.read()
        soup = BeautifulSoup(content, "lxml")
        nodes = soup.find_all("node")
        result_lst = []
        for i, node in enumerate(nodes):
            if name == "id":  # 解决resource-id不能作为key值的问题
                name = "resource-id"
            elif name == "clazz":
                name = "class"
            elif name == "index":
                name = "index"
            elif name == "content":
                name = "content-desc"

            if len(node.get(name)) > 0:
                result_lst.append(node)

        return result_lst

    def voice_wakeup(self):
        self.shell("rm /sdcard/last_voice_trigger.txt")
        self.shell("am startservice -a com.miui.voicetrigger.ACTION_VOICE_TRIGGER_START_VOICEASSIST")
        time.sleep(3)
        res = self.shell("cat /sdcard/last_voice_trigger.txt")[0].decode("utf8")

        if len(res) > 0:
            return True
        else:
            return False

    @staticmethod
    def get_guide_queries():
        queries = []
        rq_url = "http://admin.ai.srv/api/functionGuide/online/test"
        result = requests.get(rq_url).text
        # print(result)
        rq = json.loads(result)
        for q in rq["queries"]:
            queries.append(q["query"])

        return queries

    @staticmethod
    def generate_query_to_case(root_dir):
        '''
        :param root_dir: test case 根目录
        :return: 根目录下所有用例的 query :[case id] 对应
        '''
        case_set = dict()
        # root_dir = os.path.join(os.path.dirname(__file__), "test", "test_mp")
        print(root_dir)
        for root, dirs, files in os.walk(root_dir):
            _root = os.path.split(root)[-1]
            # print(_root)
            for file in files:

                if "__" not in file:
                    if file.endswith(".py") and "out_query" not in file:
                        file_path = os.path.join(root, file)
                        # print(file_path)
                        for _root, _dirs, _files in os.walk(os.path.dirname(file_path)):
                            for json_file in _files:

                                if json_file.endswith(".json"):
                                    # print(json_file)
                                    json_file_path = os.path.join(_root, json_file)
                                    # print(json_file_path)
                                    with open(json_file_path, "r", encoding="utf-8") as jf:
                                        test_cases = json.load(jf)
                                        for i, test_case in enumerate(test_cases):
                                            try:
                                                case_id = test_case["id"]
                                                case_query = test_case["case"]["query"]
                                                if isinstance(case_query, list):
                                                    for q in case_query:
                                                        if isinstance(q, str):

                                                            case_query = q
                                                            break
                                                _file = file.replace(".py", "")
                                                # print(_file)
                                                test_id = file_path.split("test/")[-1][:-2].replace("/",
                                                                                                    ".") + _file + "_" + str(i) + "_" + case_id
                                                # print(test_id)
                                                if case_query in case_set.keys():
                                                    # print(case_query)
                                                    _value = case_set[case_query] + [test_id]
                                                    case_set[case_query] = _value
                                                    # print(case_set[case_query])

                                                else:
                                                    case_set[case_query] = [test_id]
                                                    # print(case_set[case_query])
                                            except Exception as e:
                                                continue

        json_obj = json.dumps(case_set, ensure_ascii=False)
        with open(os.path.join(root_dir, "query_to_case.json"), "w", encoding="utf-8") as f:
            f.write(json_obj)
            return os.path.join(root_dir, "query_to_case.json")

    def open_xiaoai_debug_on(self):
        xfolder = "/sdcard/MIUI/debug_log/com.miui.voiceassist/debug/"
        self.shell("mkdir -p " + xfolder + "debug_on")
        self.shell("touch " + xfolder + "resource.properties")
        self.killXA()

    def open_xiaoai_setting(self):
        '''
        打开小爱同学设置页面
        '''
        self.startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MiuiVoiceSettingActivity")

    def open_xiaoai_main(self):
        '''
        打开小爱同学设置页面
        '''
        self.startActivity("com.miui.voiceassist/com.xiaomi.voiceassistant.MainActivity")
        self.click_element(text="同意并继续")
        self.click_element(text="跳过")


if __name__ == "__main__":
    Common().get_guide_queries()
