#coding=utf-8
# from appium import webdriver
# import time
#
# desired_caps = {}
# desired_caps['platformName'] = 'Android'
# desired_caps['platformVersion'] = '7.1.1'
# desired_caps['deviceName'] = '123'
# desired_caps['appPackage'] = 'com.android.settings'
# desired_caps['appActivity'] = '.GnSettingsTabActivity'
#
# driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps)
# print("start")

# driver.find_element_by_id("amigo:id/amigo_button1").click()
# time.sleep(2)
# 
# driver.find_element_by_android_uiautomator('text(\"更多连接\")').click()
 
# driver.find_element_by_name("delete").click()
#  
# driver.find_element_by_name("9").click()
#  
# driver.find_element_by_name("5").click()
#  
# driver.find_element_by_name("+").click()
#  
# driver.find_element_by_name("6").click()
#  
# driver.find_element_by_name("=").click()
# 
# driver.quit()